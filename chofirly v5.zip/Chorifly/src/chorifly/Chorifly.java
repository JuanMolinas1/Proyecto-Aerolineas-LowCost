package chorifly;

public class Chorifly {

    public static void main(String[] args) {
        Aerolinea chorifly = new Aerolinea("Chorily Airlines");
        
        ConexionSQL conexion = new ConexionSQL();
        if (conexion != null) {
            System.out.println("Conexión Exitosa.");
        } else {
            System.out.println("Error de Conexión.");
        }
        
    }
    
}
