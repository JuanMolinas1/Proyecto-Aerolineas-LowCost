package chorifly;

import java.sql.Connection;

public class Chorifly {

    public static void main(String[] args) {
        com.formdev.flatlaf.FlatLightLaf.setup();
        
        Aerolinea chorifly = new Aerolinea("Chorily Airlines");
        Connection con = ConexionSQL.conectar();
        
        if (con != null) {
            System.out.println("Conexión Exitosa.");
        } else {
            System.out.println("Error de Conexión.");
        }
        
        V_InicioSesion ventana = new V_InicioSesion();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
}