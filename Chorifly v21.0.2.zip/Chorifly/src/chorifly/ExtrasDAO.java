package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ExtrasDAO {
    private Utilidades uti = new Utilidades();
    
    public Asiento buscarAsientoPorId(String id) {
        Asiento asiento = null;
        String consulta_sql = "{CALL Buscar_Asiento_Por_Id(?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            sentencia_sql.setString(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                asiento = new Asiento();
                asiento.setIdAsiento(resultado.getString("IDAsiento"));
                asiento.setCodigo(resultado.getString("codigo"));

                String idAvion = resultado.getString("avion_id");
                asiento.setAvion(buscarAvionPorId(idAvion));

                asiento.setTipo(resultado.getString("tipo"));
                asiento.setDisponible(resultado.getBoolean("disponible"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Asiento): " + ex.getMessage(), "Error - Buscar Asiento Por ID", JOptionPane.ERROR_MESSAGE);
        }
        return asiento;
    }

    public Avion buscarAvionPorId(String id) {
        Avion avion = null;
        String consulta_sql = "{CALL Buscar_Avion(?)}"; 
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            sentencia_sql.setString(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                avion = new Avion();
                avion.setIdAvion(resultado.getString("IDAvion"));
                avion.setModelo(resultado.getString("modelo"));
                avion.setCapacidad(resultado.getInt("capacidad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Avión): " + ex.getMessage(), "Error - Buscar Avión Por ID", JOptionPane.ERROR_MESSAGE);
        }
        return avion;
    }

    public Aeropuerto buscarAeropuertoPorId(int id) {
        Aeropuerto aero = null;
        String consulta_sql = "{CALL Buscar_Aeropuerto(?)}";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                aero = new Aeropuerto();
                aero.setId_aeropuerto(resultado.getInt("IDAeropuerto"));
                aero.setNombre(resultado.getString("nombre"));
                aero.setPais(resultado.getString("pais"));
                aero.setCiudad(resultado.getString("ciudad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Aeropuerto): " + ex.getMessage(), "Error - Buscar Aeropuerto Por ID", JOptionPane.ERROR_MESSAGE);
        }
        return aero;
    }
    
    public Aeropuerto buscarAeropuertoPorNombre(String nombre) {
        Aeropuerto aero = null;
        String consulta_sql = "{CALL Buscar_Aeropuerto_Por_Nombre(?)}";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            sentencia_sql.setString(1, nombre);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                aero = new Aeropuerto();
                aero.setId_aeropuerto(resultado.getInt("IDAeropuerto"));
                aero.setNombre(resultado.getString("nombre"));
                aero.setPais(resultado.getString("pais"));
                aero.setCiudad(resultado.getString("ciudad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Aeropuerto): " + ex.getMessage(), "Error - Buscar Aeropuerto Por ID", JOptionPane.ERROR_MESSAGE);
        }
        return aero;
    }

    public Departamento buscarDepartamentoPorId(int id) {
        Departamento d = null;
        String consulta_sql = "{CALL Buscar_Departamento(?)}";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                d = new Departamento();
                d.setIdDepartamento(resultado.getInt("IDDepartamento"));
                d.setNombre(resultado.getString("nombre"));
                d.setTipo(resultado.getString("tipo"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Departamento): " + ex.getMessage(), "Error - Buscar Departamento Por ID", JOptionPane.ERROR_MESSAGE);
        }
        return d;
    }
    
    public Pago buscarPagoPorBoletoId(int idBoletoBusqueda) {
        PasajeroDAO pdao = new PasajeroDAO();
        BoletoDAO bdao = new BoletoDAO();
        Pago p = null;
        String consulta_sql = "{CALL Buscar_Pago_Por_Boleto_Id(?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            sentencia_sql.setInt(1, idBoletoBusqueda);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                p = new Pago();
                p.setIdPago(resultado.getInt("IDPago"));
                p.setCostoServicios(resultado.getDouble("costo_servicios"));
                p.setCostoTotal(resultado.getDouble("costo_total"));
                p.setEstado(resultado.getString("estado"));

                int idPasajero = resultado.getInt("pasajero_id");
                p.setPasajero(pdao.buscarPasajero(idPasajero).get(0));

                int idBoleto = resultado.getInt("boleto_id");
                p.setBoleto(bdao.buscarBoleto(idBoleto).get(0));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Pago): " + ex.getMessage(), "Error - Buscar Pago Por Boleto ID", JOptionPane.ERROR_MESSAGE);
        }
        return p;
    }
    
    public Usuario buscarUsuarioPorId(int id) {
        Usuario usuario = null;
        String consulta_sql = "{CALL Buscar_Usuario(?)}"; 
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                usuario = new Usuario();
                
                usuario.setIdUsuario(resultado.getInt("IDUsuario"));
                usuario.setUsuario(resultado.getString("nombre_usuario"));
                usuario.setEmail(resultado.getString("email"));
                usuario.setContraseña(resultado.getString("contraseña_usuario"));
                usuario.setPrivilegiosEmpleado(resultado.getBoolean("privilegios_empleado"));
                usuario.setPreguntaSeguridad(resultado.getString("pregunta_seguridad"));
                usuario.setRespuestaSeguridad(resultado.getString("respuesta_seguridad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Usuario): " + ex.getMessage(), "Error - Buscar Usuario Por ID", JOptionPane.ERROR_MESSAGE);
        }
        return usuario;
    }

    public Vuelo buscarVueloPorId(int id) {
        Vuelo vuelo = null;
        String consulta_sql = "{CALL Buscar_Vuelo_Por_Id(?)}"; 
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                vuelo = new Vuelo();
                vuelo.setIdVuelo(resultado.getInt("IDVuelo"));
                vuelo.setAvionUsado(buscarAvionPorId(resultado.getString("avion_id")));
                vuelo.setAeropuertoOrigen(buscarAeropuertoPorId(resultado.getInt("origen_id")));
                vuelo.setAeropuertoDestino(buscarAeropuertoPorId(resultado.getInt("destino_id")));
                vuelo.setFechaHoraSalida(resultado.getTimestamp("fecha_hora_salida").toLocalDateTime());
                vuelo.setFechaHoraLlegada(resultado.getTimestamp("fecha_hora_llegada").toLocalDateTime());
                vuelo.setEstado(resultado.getString("estado"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Vuelo): " + ex.getMessage(), "Error - Buscar Vuelo Por ID", JOptionPane.ERROR_MESSAGE);
        }
        return vuelo;
    }

    public ArrayList<Pago> buscarPagoPorEstado(String estado) {
        PagoDAO pdao = new PagoDAO();
        ArrayList<Pago> pagos = new ArrayList<>();
        String consulta_sql = "{CALL Buscar_Pago_Por_Estado(?)}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            sentencia_sql.setString(1, estado); 
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                pagos.add(pdao.selectPago(resultado));
            }
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null, "Error " + ex.getMessage(), "Listado de Pagos", JOptionPane.ERROR_MESSAGE);
        }
        return pagos;
    }

    public ArrayList<Asiento> buscarAsientosPorAvion(String idAvion) {
        AsientoDAO adao = new AsientoDAO();
        ArrayList<Asiento> listaAsientos = new ArrayList<>();
        String consulta_sql = "{CALL Buscar_Asientos_Por_Avion(?)}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            sentencia_sql.setString(1, idAvion);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                listaAsientos.add(adao.selectAsiento(resultado));
            }

            if (listaAsientos.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No existen asientos registrados para el avión con ID: " + idAvion, "Buscar Asientos", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex.getMessage(), "Buscar Asientos", JOptionPane.ERROR_MESSAGE);
        }
        return listaAsientos;
    }
    
    public String[] listarAviones() {
        ArrayList<String> listaAviones = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_ID_Aviones()}";
        
        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            ResultSet resultado = sentencia_sql.executeQuery();
            while (resultado.next()){
                listaAviones.add(resultado.getString("IDAvion"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error - Listar Aviones", JOptionPane.ERROR_MESSAGE);
        }
        return listaAviones.toArray(new String[0]);
    }
    
    public String[] listarAeropuertos() {
        ArrayList<String> listaAeropuertos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Nombre_Aeropuertos()}";
        
        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            ResultSet resultado = sentencia_sql.executeQuery();
            while (resultado.next()){
                listaAeropuertos.add(resultado.getString("nombre"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error - Listar Aeropuertos", JOptionPane.ERROR_MESSAGE);
        }
        return listaAeropuertos.toArray(new String[0]);
    }
    
    public String[] listarAeropuertosExtras() {
        ArrayList<String> listaAeropuertos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Extras_Aeropuertos()}";
        
        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            ResultSet resultado = sentencia_sql.executeQuery();
            while (resultado.next()){
                listaAeropuertos.add(
                        resultado.getInt("IDAeropuerto") + " - " +
                        resultado.getString("nombre")
                );
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error - Listar Aeropuertos", JOptionPane.ERROR_MESSAGE);
        }
        return listaAeropuertos.toArray(new String[0]);
    }
    
    public String[] listarDepartamentos() {
        ArrayList<String> listaDepartamentos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Extras_Departamentos()}";
        
        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            
            ResultSet resultado = sentencia_sql.executeQuery();
            while (resultado.next()){
                listaDepartamentos.add(
                        resultado.getInt("IDDepartamento") + " - " +
                        resultado.getString("nombre")
                );
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error - Listar Departamentos", JOptionPane.ERROR_MESSAGE);
        }
        return listaDepartamentos.toArray(new String[0]);
    }
    
    public ArrayList<String> listarPasajeros() {
        ArrayList<String> listaPasajeros = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Extras_Pasajeros()}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            ResultSet resultado = sentencia_sql.executeQuery();
            while (resultado.next()) {
                listaPasajeros.add(
                        resultado.getInt("IDPasajero") + " - " +
                        resultado.getString("nombre_pasajero") + " " +
                        resultado.getString("apellido_pasajero"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error - Listar Pasajeros", JOptionPane.ERROR_MESSAGE);
        }
        return listaPasajeros;
    }
    
    public ArrayList<String> listarUsuariosSinPermisos() {
        ArrayList<String> listaUsuarios = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Usuarios_Sin_Permisos()}"; 

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
             ResultSet resultado = sentencia_sql.executeQuery()) {

            while (resultado.next()) {
                listaUsuarios.add(
                        resultado.getInt("IDUsuario") + " - " +
                        resultado.getString("nombre_usuario")
                );
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Listar Usuarios): " + ex.getMessage(), "Error - Listar Usuarios Sin Permisos", JOptionPane.ERROR_MESSAGE);
        }

        return listaUsuarios;
    }
    
    public ArrayList<String> listarUsuariosConPermisos() {
        ArrayList<String> listaUsuarios = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Usuarios_Con_Permisos()}"; 

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
             ResultSet resultado = sentencia_sql.executeQuery()) {

            while (resultado.next()) {
                listaUsuarios.add(
                        resultado.getInt("IDUsuario") + " - " +
                        resultado.getString("nombre_usuario")
                );
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Listar Usuarios): " + ex.getMessage(), "Error - Listar Usuarios Con Permisos", JOptionPane.ERROR_MESSAGE);
        }

        return listaUsuarios;
    }

    public ArrayList<String> listarVuelos() {
        ArrayList<String> listaVuelos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Vuelos_Programados()}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
             ResultSet resultado = sentencia_sql.executeQuery()) {

            while (resultado.next()) {
                listaVuelos.add(
                        resultado.getInt("IDVuelo") + " - " +
                        resultado.getString("avion_id") + " - " +
                        uti.borrarTextoExtraAeropuerto(buscarAeropuertoPorId(resultado.getInt("origen_id")).getNombre()) + " - " +
                        uti.borrarTextoExtraAeropuerto(buscarAeropuertoPorId(resultado.getInt("destino_id")).getNombre())
                );
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error - Listar Vuelos", JOptionPane.ERROR_MESSAGE);
        }
        return listaVuelos;
    }
    
    public ArrayList<Servicio> listarServicios() {
        ArrayList<Servicio> listaServicios = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Servicio()}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            ResultSet resultado = sentencia_sql.executeQuery();
            while (resultado.next()) {
                Servicio s = new Servicio();
                s.setIdServicio(resultado.getInt("IDServicio"));
                s.setNombreServicio(resultado.getString("nombre_servicio"));
                s.setPrecio(resultado.getDouble("precio"));
                s.setDescripcion(resultado.getString("descripcion"));
                listaServicios.add(s);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Error - Listar Services", JOptionPane.ERROR_MESSAGE);
        }
        return listaServicios;
    }

    public ArrayList<Boolean> asientosDisponiblesPorAvion(String idAvion) {
        ArrayList<Boolean> listaAsientos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Disponibilidad_Asientos_Por_Avion(?)}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            sentencia_sql.setString(1, idAvion);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                listaAsientos.add(resultado.getBoolean("disponible"));
            }

            if (listaAsientos.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No existen asientos registrados para el avión con ID: " + idAvion, "Buscar Asientos", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex.getMessage(), "Buscar Asientos", JOptionPane.ERROR_MESSAGE);
        }
        return listaAsientos;
    }
    
    public ArrayList<String> boletosParaCheckIn() {
        BoletoDAO bdao = new BoletoDAO();
        ArrayList<String> listaBoletos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Boletos_Para_Checkin()}";
        
        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            ResultSet resultado = sentencia_sql.executeQuery();
            while (resultado.next()) {
                Boleto b = bdao.buscarBoleto(resultado.getInt("IDBoleto")).get(0);
                listaBoletos.add(listarBoletosExtra(b));
            }

            if (listaBoletos.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No existen boletos registrados.", "Listar Boletos", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error " + ex.getMessage(), "Listar Boletos", JOptionPane.ERROR_MESSAGE);
        }
        return listaBoletos;
    }
    
    public String listarBoletosExtra(Boleto b) {
        return b.getIdBoleto() + " - " +
               b.getVuelo().getIdVuelo() + " - " +
               b.getPasajero().getNombre() + " " +
               b.getPasajero().getApellido();
    }

    public String[] listarEstadosVuelos() {
        ArrayList<String> listaEstados = new ArrayList<>();
        listaEstados.add("Completado");
        listaEstados.add("Volando");
        listaEstados.add("Programado");
        listaEstados.add("A Tiempo");
        listaEstados.add("Atrasado");
        listaEstados.add("Cancelado");
        listaEstados.add("Choco");
        listaEstados.add("Exploto");
        listaEstados.add("Perdido");
        return listaEstados.toArray(new String[0]);
    }
    
    public String[] listarEstadosPagos() {
        ArrayList<String> listaEstados = new ArrayList<>();
        listaEstados.add("Pagado");
        listaEstados.add("Pendiente");
        listaEstados.add("Cancelado");
        listaEstados.add("Robado");
        listaEstados.add("Fiado");
        listaEstados.add("Reducido");
        listaEstados.add("Detenido");
        listaEstados.add("Devuelto");
        return listaEstados.toArray(new String[0]);
    }
    
    public String[] listarPuertasEmbarque() {
        ArrayList<String> listaPuertas = new ArrayList<>();
        listaPuertas.add("A-04");
        listaPuertas.add("B-12");
        listaPuertas.add("C-67");
        listaPuertas.add("D-25");
        listaPuertas.add("E-01");
        listaPuertas.add("F-18");
        return listaPuertas.toArray(new String[0]);
    }
    
    public String[] listarPaisEmision() {
        ArrayList<String> listaPaises = new ArrayList<>();
        listaPaises.add("ARG");
        listaPaises.add("BRA");
        listaPaises.add("CHL");
        listaPaises.add("COL");
        listaPaises.add("MEX");
        listaPaises.add("PER");
        return listaPaises.toArray(new String[0]);
    }
}