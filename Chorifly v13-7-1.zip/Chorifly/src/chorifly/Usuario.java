package chorifly;

import javax.swing.JOptionPane;

public class Usuario {
    private int idUsuario;
    private String usuario;
    private String email;
    private String contraseña;
    private boolean privilegiosEmpleado;
    private String preguntaSeguridad;
    private String respuestaSeguridad;

    public Usuario() {
        
    }

    public Usuario(String usuario, String email, String contraseña, boolean privilegiosEmpleado, String preguntaSeguridad, String respuestaSeguridad) {
        this.usuario = usuario;
        this.email = email;
        this.contraseña = contraseña;
        this.privilegiosEmpleado = privilegiosEmpleado;
        this.preguntaSeguridad = preguntaSeguridad;
        this.respuestaSeguridad = respuestaSeguridad;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public boolean isPrivilegiosEmpleado() {
        return privilegiosEmpleado;
    }

    public void setPrivilegiosEmpleado(boolean privilegiosEmpleado) {
        this.privilegiosEmpleado = privilegiosEmpleado;
    }

    public String getPreguntaSeguridad() {
        return preguntaSeguridad;
    }

    public void setPreguntaSeguridad(String preguntaSeguridad) {
        this.preguntaSeguridad = preguntaSeguridad;
    }

    public String getRespuestaSeguridad() {
        return respuestaSeguridad;
    }

    public void setRespuestaSeguridad(String respuestaSeguridad) {
        this.respuestaSeguridad = respuestaSeguridad;
    }

    
    
    public void mostrarUsuario() {
        JOptionPane.showMessageDialog(null, "-- Mostrar : Usuario --"
                + "\nID Usuario: " + idUsuario
                + "\nUsuario: " + usuario
                + "\nEmail: " + email
                + "\nContraseña: " + contraseña
                + "\nPrivilegios: " + privilegiosEmpleado);
    }
}
