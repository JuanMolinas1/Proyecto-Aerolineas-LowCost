package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class UsuarioDAO {

    public void insertUsuario(PreparedStatement sentencia_sql, Usuario u) throws SQLException {
        sentencia_sql.setString(1, u.getUsuario());
        sentencia_sql.setString(2, u.getEmail());
        sentencia_sql.setString(3, u.getContraseña());
        sentencia_sql.setBoolean(4, u.isPrivilegiosEmpleado());
        sentencia_sql.setString(5, u.getPreguntaSeguridad());
        sentencia_sql.setString(6, u.getRespuestaSeguridad());
    }
    
    public Usuario selectUsuario(ResultSet resultado) throws SQLException {
        Usuario u = new Usuario();
        
        u.setIdUsuario(resultado.getInt("IDUsuario"));
        u.setUsuario(resultado.getString("nombre_usuario"));
        u.setEmail(resultado.getString("email"));
        u.setContraseña(resultado.getString("contraseña_usuario"));
        u.setPrivilegiosEmpleado(resultado.getBoolean("privilegios_empleado"));
        u.setPreguntaSeguridad(resultado.getString("pregunta_seguridad"));
        u.setRespuestaSeguridad(resultado.getString("respuesta_seguridad"));
        return u;
    }
    
    public void agregarUsuario(Usuario u) {
        String consulta_sql = "INSERT INTO Usuario (nombre_usuario, email, contraseña_usuario, privilegios_empleado, pregunta_seguridad, respuesta_seguridad) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertUsuario(sentencia_sql, u);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Usuario Guardado Exitosamente",
                    "Creación de Usuario",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public ArrayList<Usuario> mostrarUsuario() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Usuario";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                usuarios.add(selectUsuario(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Usuarios",
                    JOptionPane.ERROR_MESSAGE);
        }
        return usuarios;
    }

    public ArrayList<Usuario> buscarUsuario(int id) {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Usuario WHERE IDUsuario = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                usuarios.add(selectUsuario(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un usuario con el ID: " + id,
                    "Buscar Usuario",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
        return usuarios;
    }

    public void editarUsuario(Usuario u) {
        String consulta_sql = "UPDATE Usuario SET nombre_usuario = ?, email = ?, contraseña_usuario = ?, privilegios_empleado = ? WHERE IDUsuario = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertUsuario(sentencia_sql, u);
            sentencia_sql.setInt(5, u.getIdUsuario());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Usuario Actualizado Exitosamente",
                    "Edición de Usuario",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void eliminarUsuario(int id) {
        String consulta_sql = "DELETE FROM Usuario WHERE IDUsuario = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            
            JOptionPane.showMessageDialog(null,
                    "Usuario Eliminado Exitosamente",
                    "Eliminar Usuario",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public ArrayList<Usuario> buscarUsuarioEmpleado() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Usuario WHERE privilegios_empleado = TRUE";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                usuarios.add(selectUsuario(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Usuarios",
                    JOptionPane.ERROR_MESSAGE);
        }
        return usuarios;
    }
    
    public boolean existeUsuario(String usuario) {
        boolean existe = false;
        String consulta_sql = "SELECT COUNT(*) FROM Usuario WHERE nombre_usuario = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, usuario);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                existe = resultado.getInt(1) > 0;
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error al validar usuario: " + ex.getMessage(),
                    "Validar Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
        return existe;
    }

    public boolean existeEmail(String email) {
        boolean existe = false;
        String consulta_sql = "SELECT COUNT(*) FROM Usuario WHERE email = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, email);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                existe = resultado.getInt(1) > 0;
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error al validar correo: " + ex.getMessage(),
                    "Validar Correo",
                    JOptionPane.ERROR_MESSAGE);
        }
        return existe;
    }

}