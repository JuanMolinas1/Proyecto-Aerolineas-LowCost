package chorifly;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.text.SimpleDateFormat;

public class VentanaCrudAsientos extends javax.swing.JFrame {
    private boolean vieneDeAdmin;
    private ExtrasDAO edao = new ExtrasDAO();
    SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
    
    public VentanaCrudAsientos(boolean vieneDeAdmin) {
        this.vieneDeAdmin = vieneDeAdmin;
        initComponents();
        
        // No editables
        txtDisponible.setText("Seleccionar Estado");
        
        txtBuscar.putClientProperty("JTextField.placeholderText", "Disponible");
        
        // Comodidad, evita la selección azul
        txtDisponible.setFocusable(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaAsientos = new javax.swing.JTable();
        txtDisponible = new javax.swing.JTextField();
        btnVolver = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Asientos");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Disponible");

        tablaAsientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Asiento", "Código", "Avión", "Tipo", "Disponible"
            }
        ));
        tablaAsientos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaAsientosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaAsientos);

        txtDisponible.setEditable(false);
        txtDisponible.setBackground(new java.awt.Color(255, 255, 255));
        txtDisponible.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtDisponible.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDisponibleMouseClicked(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnMostrar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtBuscar.setEditable(false);
        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        txtBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtBuscarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(txtBuscar))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtDisponible)
                            .addComponent(btnMostrar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtDisponible, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(103, 103, 103)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(25, 25, 25)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDisponibleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDisponibleMouseClicked
        String[] opciones = {"Sí", "No"};

        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona disponibilidad:",
            "Menú Disponibilidad",
            JOptionPane.DEFAULT_OPTION,
            null,
            opciones,
            opciones[0]
        );

        if (seleccion != null) {
            txtDisponible.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(
                null,
                "Cancelaste la Operación",
                "Menú Disponibilidad",
                JOptionPane.WARNING_MESSAGE
            );
        }
    }//GEN-LAST:event_txtDisponibleMouseClicked

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaMenuPrincipalAdmin menuPrincipalAdmin = new VentanaMenuPrincipalAdmin();
        VentanaMenuPrincipal menuPrincipal = new VentanaMenuPrincipal();
        if (vieneDeAdmin) {
            menuPrincipalAdmin.setVisible(true);
            menuPrincipalAdmin.setLocationRelativeTo(null);
            this.dispose();
        } else {
            menuPrincipal.setVisible(true);
            menuPrincipal.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        actualizarTabla();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void tablaAsientosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaAsientosMouseClicked
        int fila = tablaAsientos.getSelectedRow();

        if (fila == -1) {
            return;
        }

        String estado = tablaAsientos.getValueAt(fila, 4).toString();

        txtDisponible.setText(estado);
    }//GEN-LAST:event_tablaAsientosMouseClicked

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int fila = tablaAsientos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un asiento.",
                "Edición de Asiento",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String id = tablaAsientos.getValueAt(fila, 0).toString();

        boolean disponible = txtDisponible.getText().equals("Sí");

        AsientoDAO adao = new AsientoDAO();
        Asiento asiento = edao.buscarAsientoPorId(id);

        if (asiento != null) {
            asiento.setDisponible(disponible);
            adao.editarAsiento(asiento);
        }

        actualizarTabla();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        boolean disponible = txtBuscar.getText().equals("Sí");

        AsientoDAO adao = new AsientoDAO();

        ArrayList<Asiento> asientos = adao.buscarAsiento(disponible);

        DefaultTableModel modelo = (DefaultTableModel) tablaAsientos.getModel();

        modelo.setRowCount(0);

        for (Asiento a : asientos) {
            modelo.addRow(new Object[]{
                a.getIdAsiento(),
                a.getCodigo(),
                a.getAvion().getIdAvion(),
                a.getTipo(),
                a.isDisponible() ? "Sí" : "No"
            });
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtBuscarMouseClicked
        String[] opciones = {"Sí", "No"};

        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona disponibilidad:",
            "Menú Disponibilidad",
            JOptionPane.DEFAULT_OPTION,
            null,
            opciones,
            opciones[0]
        );

        if (seleccion != null) {
            txtBuscar.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(
                null,
                "Cancelaste la Operación",
                "Menú Disponibilidad",
                JOptionPane.WARNING_MESSAGE
            );
        }
    }//GEN-LAST:event_txtBuscarMouseClicked

    public void listarAeropuertos(javax.swing.JTextField txtAeropuerto, String textoAExcluir) {
        String[] todosLosAeropuertos = edao.listarAeropuertos();
        ArrayList<String> listaModificable = new ArrayList<>(Arrays.asList(todosLosAeropuertos));

        if (!textoAExcluir.equals("Seleccionar Aeropuerto")) {
            listaModificable.remove(textoAExcluir);
        }

        String[] opcionesDisponibles = listaModificable.toArray(new String[0]);
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Aeropuerto:",
            "Menú Aeropuertos",
            JOptionPane.DEFAULT_OPTION,
            null,
            opcionesDisponibles,
            opcionesDisponibles[0]
        );

        if (seleccion != null) {
            txtAeropuerto.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Aeropuertos", JOptionPane.WARNING_MESSAGE);
            txtAeropuerto.setText("Seleccionar Aeropuerto");
        }
    }
    
    public void actualizarTabla() {
        AsientoDAO adao = new AsientoDAO();

        ArrayList<Asiento> listaAsientos = adao.mostrarAsiento();

        DefaultTableModel modelo = (DefaultTableModel) tablaAsientos.getModel();

        modelo.setRowCount(0);

        for (Asiento a : listaAsientos) {
            modelo.addRow(new Object[]{
                a.getIdAsiento(),
                a.getCodigo(),
                a.getAvion().getIdAvion(),
                a.getTipo(),
                a.isDisponible() ? "Sí" : "No"
            });
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaAsientos;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDisponible;
    // End of variables declaration//GEN-END:variables
}
