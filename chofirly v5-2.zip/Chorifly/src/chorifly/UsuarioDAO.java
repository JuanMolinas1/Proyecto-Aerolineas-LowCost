package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UsuarioDAO {
    public void insertar(Usuario u) {
        String insert_sql = "INSERT INTO Usuario (nombre_usuario, email, contraseña_usuario, privilegios_empleado) VALUES (?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, u.getUsuario());
            sentencia_sql.setString(2, u.getEmail());
            sentencia_sql.setString(3, u.getContraseña());
            sentencia_sql.setBoolean(4, u.isPrivilegios_empleado());
            
            sentencia_sql.executeUpdate();
            System.out.println("Usuario Guardado Exitosamente");
        } catch (SQLException ex){
            System.out.println("Error " + ex.getMessage());
        }
    }
}