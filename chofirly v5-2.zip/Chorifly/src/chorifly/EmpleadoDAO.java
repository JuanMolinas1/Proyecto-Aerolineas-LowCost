package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmpleadoDAO {
    public void insertar(Empleado e) {
        String insert_sql = "INSERT INTO Empleado (nombre_empleado, apellido_empleado, dni_empleado, sueldo, departamento_id, aeropuerto_id, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, e.getNombre());
            sentencia_sql.setString(2, e.getApellido());
            sentencia_sql.setString(3, e.getDni());
            sentencia_sql.setDouble(4, e.getSueldo());
            sentencia_sql.setInt(5, e.getDepartamento().getId_departamento());
            sentencia_sql.setInt(6, e.getAeropuertoTrabajo().getId_aeropuerto());
            sentencia_sql.setInt(7, e.getUsuario().getId_usuario());
            
            sentencia_sql.executeUpdate();
            System.out.println("Empleado Guardado Exitosamente");
        } catch (SQLException ex){
            System.out.println("Error " + ex.getMessage());
        }
    }
}
