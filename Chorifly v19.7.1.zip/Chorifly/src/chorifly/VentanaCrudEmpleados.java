package chorifly;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentanaCrudEmpleados extends javax.swing.JFrame {
    private ExtrasDAO edao = new ExtrasDAO();
    private Utilidades uti = new Utilidades();
    private Validaciones valid = new Validaciones();
    
    public VentanaCrudEmpleados() {
        initComponents();
        // No editables
        txtUsuario.setText("Seleccionar Usuario");
        txtDepartamento.setText("Seleccionar Departamento");
        txtAeropuerto.setText("Seleccionar Aeropuerto");
        
        // Editables
        txtNombre.putClientProperty("JTextField.placeholderText", "Ingresar Nombre");
        txtApellido.putClientProperty("JTextField.placeholderText", "Ingresar Apellido");
        txtDni.putClientProperty("JTextField.placeholderText", "Ingresar DNI (Sin Puntos)");
        txtTelefono.putClientProperty("JTextField.placeholderText", "Ingresar Nro. de Teléfono");
        txtSueldo.putClientProperty("JTextField.placeholdetText", "Ingresar Sueldo");
        
        txtBuscar.putClientProperty("JTextField.placeholderText", "ID Pasajero");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaEmpleados = new javax.swing.JTable();
        txtApellido = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        txtSueldo = new javax.swing.JTextField();
        btnVolver = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtDepartamento = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtAeropuerto = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chorifly - Menú Pasajeros");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Vuelos");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Apellido");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("DNI");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Teléfono");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Sueldo");

        tablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Empleado", "Nombre", "Apellido", "Dni", "Teléfono", "Sueldo", "Departameto_id", "Aeropuerto_id", "Usuario"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaEmpleadosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaEmpleados);
        if (tablaEmpleados.getColumnModel().getColumnCount() > 0) {
            tablaEmpleados.getColumnModel().getColumn(0).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(1).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(2).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(3).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(4).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(5).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(6).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(7).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(8).setResizable(false);
        }

        txtApellido.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        txtDni.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        txtSueldo.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnMostrar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N

        txtTelefono.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Departamento");

        txtDepartamento.setEditable(false);
        txtDepartamento.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtDepartamento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDepartamentoMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Aeropuerto");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Usuario");

        txtUsuario.setEditable(false);
        txtUsuario.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtUsuarioMouseClicked(evt);
            }
        });

        txtNombre.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        txtAeropuerto.setEditable(false);
        txtAeropuerto.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtAeropuerto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtAeropuertoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(txtBuscar)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtSueldo)
                            .addComponent(txtApellido, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDni, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnMostrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(txtDepartamento, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefono)
                            .addComponent(txtUsuario, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtAeropuerto, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(txtNombre))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtApellido))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtDni))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtSueldo))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDepartamento)
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(txtAeropuerto))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(txtUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1))
                .addGap(24, 24, 24)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaMenuPrincipalAdmin menuPrincipalAdmin = new VentanaMenuPrincipalAdmin();
        menuPrincipalAdmin.setVisible(true);
        menuPrincipalAdmin.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tablaEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaEmpleadosMouseClicked
        int fila = tablaEmpleados.getSelectedRow();

        String idEmpleado = tablaEmpleados.getValueAt(fila, 0).toString();
        String nombre = tablaEmpleados.getValueAt(fila, 1).toString();
        String apellido = tablaEmpleados.getValueAt(fila, 2).toString();
        String dni = tablaEmpleados.getValueAt(fila, 3).toString();
        String telefono = tablaEmpleados.getValueAt(fila, 4).toString();
        String sueldo = tablaEmpleados.getValueAt(fila, 5).toString();
        String departamento = tablaEmpleados.getValueAt(fila, 6).toString();
        String aeropuerto = tablaEmpleados.getValueAt(fila, 7).toString();
        String usuario = tablaEmpleados.getValueAt(fila, 8).toString();
            
        txtNombre.setText(nombre);
        txtApellido.setText(apellido);
        txtDni.setText(dni);
        txtTelefono.setText(telefono);
        txtSueldo.setText(sueldo);
        txtDepartamento.setText(departamento);
        txtAeropuerto.setText(aeropuerto);
        txtUsuario.setText(usuario);
    }//GEN-LAST:event_tablaEmpleadosMouseClicked

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        EmpleadoDAO emdao = new EmpleadoDAO();
        
        // Normales
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String dni = txtDni.getText();
        String telefono = txtTelefono.getText();
        String sueldoText = txtSueldo.getText();
        
        // Menús desplegables
        String departamentoText = txtDepartamento.getText();
        String aeropuertoText = txtAeropuerto.getText();
        String usuarioText = txtUsuario.getText();
        
        if (!valid.validarEmpleado(nombre, apellido, dni, telefono, sueldoText, departamentoText, aeropuertoText, usuarioText)) {
            return;
        }
        
        Double sueldo = Double.parseDouble(sueldoText);
        
        Departamento departamento;
        Aeropuerto aeropuerto;
        Usuario usuario;
        try {
            departamento = edao.buscarDepartamentoPorId(Integer.parseInt(uti.borrarDesdeEspacio(departamentoText)));
            aeropuerto = edao.buscarAeropuertoPorId(Integer.parseInt(uti.borrarDesdeEspacio(aeropuertoText)));
            usuario = edao.buscarUsuarioPorId(Integer.parseInt(uti.borrarDesdeEspacio(usuarioText)));
            
            if (departamento == null) {
                JOptionPane.showMessageDialog(
                        null,
                        "Debe seleccionar un departamento válido.",
                        "Gestión de Empleados",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
            
            if (aeropuerto == null) {
                JOptionPane.showMessageDialog(
                        null,
                        "Debe seleccionar un aeropuerto válido.",
                        "Gestión de Empleados",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
            
            if (usuario == null) {
                JOptionPane.showMessageDialog(
                        null,
                        "Debe seleccionar un usuario válido.",
                        "Gestión de Empleados",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
            
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Debe completar todos los menús desplegables.",
                    "Gestión de Empleados",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        Empleado e = new Empleado(
                nombre,
                apellido,
                dni,
                telefono,
                sueldo,
                departamento
        );
        
        e.setAeropuertoTrabajo(aeropuerto);
        e.setUsuario(usuario);
        
        emdao.agregarEmpleado(e);
        actualizarTabla();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        actualizarTabla();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int fila = tablaEmpleados.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un empleado de la tabla.", "Edición de Empleado", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = Integer.parseInt(tablaEmpleados.getValueAt(fila, 0).toString());
        EmpleadoDAO emdao = new EmpleadoDAO();

        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String dni = txtDni.getText();
        String telefono = txtTelefono.getText();
        String sueldoText = txtSueldo.getText();
        String departamentoText = txtDepartamento.getText();
        String aeropuertoText = txtAeropuerto.getText();
        String usuarioText = txtUsuario.getText();

        if (!valid.validarEmpleado(nombre, apellido, dni, telefono, sueldoText, departamentoText, aeropuertoText, usuarioText)) {
            return;
        }

        try {
            Double sueldo = Double.parseDouble(sueldoText);
            Departamento departamento = edao.buscarDepartamentoPorId(Integer.parseInt(uti.borrarDesdeEspacio(departamentoText)));
            Aeropuerto aeropuerto = edao.buscarAeropuertoPorId(Integer.parseInt(uti.borrarDesdeEspacio(aeropuertoText)));
            Usuario usuario = edao.buscarUsuarioPorId(Integer.parseInt(uti.borrarDesdeEspacio(usuarioText)));

            Empleado e = new Empleado(nombre, apellido, dni, telefono, sueldo, departamento);
            e.setIdEmpleado(id);
            e.setAeropuertoTrabajo(aeropuerto);
            e.setUsuario(usuario);

            emdao.editarEmpleado(e);
            actualizarTabla();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al editar el empleado.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tablaEmpleados.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un empleado.", "Eliminar Empleado", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = Integer.parseInt(tablaEmpleados.getValueAt(fila, 0).toString());
        EmpleadoDAO emdao = new EmpleadoDAO();
        emdao.eliminarEmpleado(id);
        actualizarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        EmpleadoDAO emdao = new EmpleadoDAO();
        if (txtBuscar.getText() != null && !txtBuscar.getText().trim().isEmpty()) {
            try {
                int id = Integer.parseInt(txtBuscar.getText().trim());
                ArrayList<Empleado> empleados = emdao.buscarEmpleado(id); // Cambiado a Empleado
                DefaultTableModel modelo = (DefaultTableModel) tablaEmpleados.getModel();
                modelo.setRowCount(0);

                for (Empleado e : empleados) {
                    modelo.addRow(new Object[]{
                        e.getIdEmpleado(),
                        e.getNombre(),
                        e.getApellido(),
                        e.getDni(),
                        e.getTelefono(),
                        e.getSueldo(),
                        e.getDepartamento().getIdDepartamento(),
                        e.getAeropuertoTrabajo().getIdAeropuerto(),
                        e.getUsuario().getIdUsuario()
                    });
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "El ID debe ser un número entero válido.", "Buscar Empleado", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "El campo de ID Empleado no debe estar vacío", "Buscar Empleado", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtUsuarioMouseClicked
        String[] listaUsuariosEmpleado = edao.listarUsuariosConPermisos().toArray(new String[0]);

        if (listaUsuariosEmpleado.length == 0) {
            JOptionPane.showMessageDialog(
                null,
                "No hay usuarios disponibles.",
                "Menú Usuarios",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Usuario:",
            "Menú Usuarios",
            JOptionPane.DEFAULT_OPTION,
            null,
            listaUsuariosEmpleado,
            listaUsuariosEmpleado[0]
        );

        if (seleccion != null) {
            txtUsuario.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Usuarios", JOptionPane.WARNING_MESSAGE);
            txtUsuario.setText("Seleccionar Usuario");
        }
    }//GEN-LAST:event_txtUsuarioMouseClicked

    private void txtDepartamentoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDepartamentoMouseClicked
	String[] listaDepartamentos = edao.listarDepartamentos();

        if (listaDepartamentos.length == 0) {
            JOptionPane.showMessageDialog(
                null,
                "No hay departamentos disponibles.",
                "Menú Departamentos",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Departamento:",
            "Menú Departamentos",
            JOptionPane.DEFAULT_OPTION,
            null,
            listaDepartamentos,
            listaDepartamentos[0]
        );

        if (seleccion != null) {
            txtDepartamento.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Departamentos", JOptionPane.WARNING_MESSAGE);
            txtDepartamento.setText("Seleccionar Departamento");
        }
    }//GEN-LAST:event_txtDepartamentoMouseClicked

    private void txtAeropuertoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtAeropuertoMouseClicked
        String[] listaAeropuertos = edao.listarAeropuertosExtras();

        if (listaAeropuertos.length == 0) {
            JOptionPane.showMessageDialog(
                null,
                "No hay aeropuertos disponibles.",
                "Menú Aeropuertos",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Aeropuerto:",
            "Menú Aeropuertos",
            JOptionPane.DEFAULT_OPTION,
            null,
            listaAeropuertos,
            listaAeropuertos[0]
        );

        if (seleccion != null) {
            txtAeropuerto.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Aeropuertos", JOptionPane.WARNING_MESSAGE);
            txtAeropuerto.setText("Seleccionar Aeropuerto");
        }
    }//GEN-LAST:event_txtAeropuertoMouseClicked

    public void actualizarTabla() {
        EmpleadoDAO emdao = new EmpleadoDAO();
        ArrayList<Empleado> listaEmpleados = emdao.mostrarEmpleado();
        DefaultTableModel modelo = (DefaultTableModel)tablaEmpleados.getModel();
        
        modelo.setRowCount(0);
        
        for (Empleado e : listaEmpleados) {
            modelo.addRow(new Object []{
                e.getIdEmpleado(),
                e.getNombre(),
                e.getApellido(),
                e.getDni(),
                e.getTelefono(),
                e.getSueldo(),
                e.getDepartamento().getIdDepartamento(),
                e.getAeropuertoTrabajo().getIdAeropuerto(),
                e.getUsuario().getIdUsuario()
            });
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaEmpleados;
    private javax.swing.JTextField txtAeropuerto;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDepartamento;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtSueldo;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
