document.addEventListener("DOMContentLoaded", function () {
    const usuario = document.getElementById("nombreUsuario");
    const contraseña = document.getElementById("contraUsuario");
    const boton = document.getElementById("IniciarSesion");
    const mensaje = document.getElementById("mensaje");

    boton.addEventListener("click", async function () {
        const nombreUsuario = usuario.value.trim();
        const contrasena = contraseña.value;

        mensaje.textContent = "";

        if (nombreUsuario === "" || contrasena === "") {
            mensaje.textContent = "Completá el usuario y la contraseña.";
            return;
        }

        boton.disabled = true;

        try {
            const respuesta = await fetch("/iniciarSesion", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                },
                body: new URLSearchParams({
                    usuario: nombreUsuario,
                    contraseña: contrasena
                })
            });

            const resultado = (await respuesta.text()).trim();

            if (!respuesta.ok) {
                mensaje.textContent = resultado;
                return;
            }

            if (resultado === "pasajero") {
                window.location.href = "/Chorifly.html";
            } else if (resultado === "empleado") {
                window.location.href = "/Chorifly(EMPLEADO).html";
            } else if (resultado === "incorrecto") {
                mensaje.textContent = "Usuario o contraseña incorrectos.";
            } else {
                mensaje.textContent = resultado ||
                    "No se pudo completar el inicio de sesión.";
            }

        } catch (error) {
            console.error(error);
            mensaje.textContent = "No se pudo conectar con el servidor.";
        } finally {
            boton.disabled = false;
        }
    });
});