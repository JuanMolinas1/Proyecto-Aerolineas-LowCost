document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("formularioRegistro");
    const botonRegistro = document.getElementById("registrarse");
    const mensaje = document.getElementById("mensajeRegistro");

    formulario.addEventListener("submit", registrar);
    botonRegistro.addEventListener("click", registrar);

    async function registrar(evento) {
        evento.preventDefault();

        if (!formulario.reportValidity()) {
            return;
        }

        const datos = new FormData(formulario);
        const usuario = datos.get("usuario").trim();
        const email = datos.get("email").trim();
        const contrasena = datos.get("contraseña");
        const repetirContrasena = datos.get("repetirContraseña");

        mensaje.textContent = "";

        if (contrasena !== repetirContrasena) {
            mensaje.textContent = "Las contraseñas no coinciden.";
            return;
        }

        botonRegistro.disabled = true;

        try {
            const verificacion = await fetch(
                "/verificarUsuario?usuario=" +
                encodeURIComponent(usuario) +
                "&email=" +
                encodeURIComponent(email)
            );

            const resultadoVerificacion = await verificacion.text();

            if (!verificacion.ok) {
                throw new Error(resultadoVerificacion);
            }

            if (resultadoVerificacion.trim() === "true") {
                mensaje.textContent =
                    "El nombre de usuario o el correo ya están registrados.";
                return;
            }

            const respuesta = await fetch("/registrarUsuario", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                },
                body: new URLSearchParams(datos)
            });

            const resultado = await respuesta.text();

            if (!respuesta.ok) {
                mensaje.textContent = resultado;
                return;
            }

            mensaje.textContent =
                "¡Cuenta creada correctamente! Ya podés iniciar sesión.";

            formulario.reset();

        } catch (error) {
            console.error(error);
            mensaje.textContent =
                "No se pudo completar el registro. Revisá la conexión con el servidor.";
        } finally {
            botonRegistro.disabled = false;
        }
    }
});