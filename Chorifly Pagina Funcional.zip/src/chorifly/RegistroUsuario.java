
package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;

public class RegistroUsuario {

    public static boolean existeUsuario(String usuario, String email) {

        String sql = "SELECT IDUsuario FROM Usuario "
                   + "WHERE nombre_usuario = ? OR email = ? LIMIT 1";

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new RuntimeException("No se pudo conectar a MySQL");
        }

        try {
            PreparedStatement consulta = conexion.prepareStatement(sql);

            consulta.setString(1, usuario);
            consulta.setString(2, email);

            ResultSet resultado = consulta.executeQuery();

            return resultado.next();

        } catch (SQLException ex) {
            throw new RuntimeException("Error al consultar Usuario", ex);
        }
    }

    public static void registrarPasajero(
            String usuario,
            String email,
            String contrasena,
            String pregunta,
            String respuesta,
            String nombre,
            String apellido,
            String dni,
            String telefono,
            String fechaNacimiento,
            String pasaporte,
            String paisEmision,
            String vencimientoPasaporte
    ) throws SQLException {

        String sqlUsuario = "INSERT INTO Usuario "
                + "(nombre_usuario, email, contraseña_usuario, "
                + "privilegios_empleado, pregunta_seguridad, respuesta_seguridad) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        String sqlPasajero = "INSERT INTO Pasajero "
                + "(nombre_pasajero, apellido_pasajero, dni_pasajero, "
                + "telefono, fecha_nacimiento, nro_pasaporte, pais_emision, "
                + "vencimiento_pasaporte, usuario_id) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new SQLException("No se pudo conectar a MySQL.");
        }

        boolean autocommitOriginal = conexion.getAutoCommit();

        try {
            conexion.setAutoCommit(false);

            int idUsuario;

            try (PreparedStatement consultaUsuario =
                    conexion.prepareStatement(
                            sqlUsuario, Statement.RETURN_GENERATED_KEYS)) {

                consultaUsuario.setString(1, usuario);
                consultaUsuario.setString(2, email);
                consultaUsuario.setString(3, contrasena);
                consultaUsuario.setBoolean(4, false);
                consultaUsuario.setString(5, pregunta);
                consultaUsuario.setString(6, respuesta);

                consultaUsuario.executeUpdate();

                try (ResultSet claves = consultaUsuario.getGeneratedKeys()) {
                    if (!claves.next()) {
                        throw new SQLException(
                                "No se pudo obtener el ID del usuario.");
                    }

                    idUsuario = claves.getInt(1);
                }
            }

            try (PreparedStatement consultaPasajero =
                    conexion.prepareStatement(sqlPasajero)) {

                consultaPasajero.setString(1, nombre);
                consultaPasajero.setString(2, apellido);
                consultaPasajero.setString(3, dni);
                consultaPasajero.setString(4, telefono);
                consultaPasajero.setDate(
                        5, Date.valueOf(fechaNacimiento));
                consultaPasajero.setString(6, pasaporte);
                consultaPasajero.setString(7, paisEmision);
                consultaPasajero.setDate(
                        8, Date.valueOf(vencimientoPasaporte));
                consultaPasajero.setInt(9, idUsuario);

                consultaPasajero.executeUpdate();
            }

            conexion.commit();

        } catch (SQLException | RuntimeException error) {
            try {
                conexion.rollback();
            } catch (SQLException errorRollback) {
                error.addSuppressed(errorRollback);
            }

            throw error;

        } finally {
            try {
                conexion.setAutoCommit(autocommitOriginal);
            } catch (SQLException error) {
                error.printStackTrace();
            }
        }
    }
}
