package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class PagoDAO {
    public void insertarPago(Pago p) {
        String insert_sql = "INSERT INTO Pago (pasajero_id, boleto_id, costo_servicios, costo_total) VALUES (?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setInt(1, p.getPasajero().getId_pasajero());
            sentencia_sql.setInt(2, p.getBoleto().getId_boleto());
            sentencia_sql.setDouble(3, p.getCosto_servicios());
            sentencia_sql.setDouble(4, p.getCosto_total());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Pago Guardado Exitosamente",
                    "Creación de Pago",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Pago",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
