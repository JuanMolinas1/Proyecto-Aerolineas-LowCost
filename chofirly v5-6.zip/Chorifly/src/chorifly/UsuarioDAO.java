package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UsuarioDAO {
    public void insertarUsuario(Usuario u) {
        String insert_sql = "INSERT INTO Usuario (nombre_usuario, email, contraseña_usuario, privilegios_empleado) VALUES (?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, u.getUsuario());
            sentencia_sql.setString(2, u.getEmail());
            sentencia_sql.setString(3, u.getContraseña());
            sentencia_sql.setBoolean(4, u.isPrivilegios_empleado());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Usuario Guardado Exitosamente",
                    "Creación de Usuario",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Usuario",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}