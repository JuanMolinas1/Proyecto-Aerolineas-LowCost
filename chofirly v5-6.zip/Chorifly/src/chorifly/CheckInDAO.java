package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CheckInDAO {
    public void insertarCheckIn(CheckIn c) {
        String insert_sql = "INSERT INTO CheckIn (pasajero_id, boleto_id, vuelo_id, pago_id, puerta_embarque) VALUES (?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setInt(1, c.getPasajero().getId_pasajero());
            sentencia_sql.setInt(2, c.getBoleto().getId_boleto());
            sentencia_sql.setInt(3, c.getVuelo().getId_vuelo());
            sentencia_sql.setInt(4, c.getPago().getId_pago());
            sentencia_sql.setString(5, c.getPuerta_embarque());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Check-In Guardado Exitosamente",
                    "Creación de Check-In",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Check-In",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
