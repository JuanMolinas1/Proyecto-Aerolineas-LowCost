package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class BoletoDAO {
    public void insertarBoleto(Boleto b) {
        String insert_sql = "INSERT INTO Boleto (pasajero_id, vuelo_id, asiento_id, fecha, precio_base) VALUES (?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setInt(1, b.getPasajero().getId_pasajero());
            sentencia_sql.setInt(2, b.getVuelo().getId_vuelo());
            sentencia_sql.setString(3, b.getAsiento().getId_asiento());
            sentencia_sql.setObject(4, b.getFecha());
            sentencia_sql.setDouble(5, b.getPrecio_base());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Boleto Guardado Exitosamente",
                    "Creación de Boleto",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Boleto",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public String mostrarBoleto(ResultSet resultado) throws SQLException {
        return "-- Mostrar : Boleto --"
                + "\nID Boleto: " + resultado.getInt("IDBoleto")
                + "\nPasajero: " + resultado.getInt("pasajero_id")
                + "\nVuelo: " + resultado.getInt("vuelo_id")
                + "\nAsiento: " + resultado.getString("asiento_id")
                + "\nFecha: " + resultado.getTimestamp("fecha")
                + "\nPrecio Base: " + resultado.getDouble("precio_base");
    }
    
    public void listarBoleto() {
        String consulta_sql = "SELECT * FROM Boleto";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    mostrarBoleto(resultado),
                    "Listado de Boletos",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Boletos",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void buscarBoleto(int id) {
        String consulta_sql = "SELECT * FROM Boleto WHERE IDBoleto = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);

            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    mostrarBoleto(resultado),
                    "Buscar Boleto",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un boleto con el ID: " + id,
                    "Buscar Boleto",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Boleto",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}