package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class CheckInDAO {
    public void insertarCheckIn(CheckIn c) {
        String insert_sql = "INSERT INTO CheckIn (pasajero_id, boleto_id, vuelo_id, pago_id, puerta_embarque) VALUES (?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setInt(1, c.getPasajero().getId_pasajero());
            sentencia_sql.setInt(2, c.getBoleto().getId_boleto());
            sentencia_sql.setInt(3, c.getVuelo().getId_vuelo());
            sentencia_sql.setInt(4, c.getPago().getId_pago());
            sentencia_sql.setString(5, c.getPuerta_embarque());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Check-In Guardado Exitosamente",
                    "Creación de Check-In",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Check-In",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
        public String mostrarCheckIn(ResultSet resultado) throws SQLException {
        return "-- Mostrar : Check-In --"
                + "\nID Check-In: " + resultado.getInt("IDCheckin")
                + "\nPasajero: " + resultado.getInt("pasajero_id")
                + "\nBoleto: " + resultado.getInt("boleto_id")
                + "\nVuelo: " + resultado.getInt("vuelo_id")
                + "\nPago: " + resultado.getInt("pago_id")
                + "\nPuerta de Embarque: " + resultado.getString("puerta_embarque");
    }

    public void listarCheckIn() {
        String consulta_sql = "SELECT * FROM CheckIn";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    mostrarCheckIn(resultado),
                    "Listado de Check-Ins",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Check-Ins",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarCheckIn(int id) {
        String consulta_sql = "SELECT * FROM CheckIn WHERE IDCheckin = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);

            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    mostrarCheckIn(resultado),
                    "Buscar Check-In",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un Check-In con el ID: " + id,
                    "Buscar Check-In",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Check-In",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
