package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ExtrasDAO {

    public Avion buscarAvionPorId(String id) {
        Avion avion = null;
        String consulta_sql = "SELECT * FROM Avion WHERE IDAvion = ?"; 
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                avion = new Avion();
                avion.setId_avion(resultado.getString("IDAvion"));
                avion.setModelo(resultado.getString("modelo"));
                avion.setCapacidad(resultado.getInt("capacidad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Avión): " + ex.getMessage(), 
                    "Error - Buscar Avión Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return avion;
    }

    public Aeropuerto buscarAeropuertoPorId(int id) {
        Aeropuerto aero = null;
        String consulta_sql = "SELECT * FROM Aeropuerto WHERE IDAeropuerto = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                aero = new Aeropuerto();
                aero.setId_aeropuerto(resultado.getInt("IDAeropuerto"));
                aero.setNombre(resultado.getString("nombre"));
                aero.setPais(resultado.getString("pais"));
                aero.setCiudad(resultado.getString("ciudad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Aeropuerto): " + ex.getMessage(), 
                    "Error - Buscar Aeropuerto Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return aero;
    }

    public Departamento buscarDepartamentoPorId(int id) {
        Departamento d = null;
        String consulta_sql = "SELECT * FROM Departamento WHERE IDDepartamento = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                d = new Departamento();
                d.setId_departamento(resultado.getInt("IDDepartamento"));
                d.setNombre(resultado.getString("nombre"));
                d.setTipo(resultado.getString("tipo"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Departamento): " + ex.getMessage(), 
                    "Error - Buscar Departamento Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return d;
    }

    public Usuario buscarUsuarioPorId(int id) {
        Usuario u = null;
        String consulta_sql = "SELECT * FROM Usuario WHERE IDUsuario = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                u = new Usuario();
                u.setId_usuario(resultado.getInt("IDUsuario"));
                u.setNombre_usuario(resultado.getString("nombre_usuario"));
                u.setEmail(resultado.getString("email"));
                u.setContraseña_usuario(resultado.getString("contraseña_usuario"));
                u.setPrivilegios_empleado(resultado.getBoolean("privilegios_empleado"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Usuario): " + ex.getMessage(), 
                    "Error - Buscar Usuario Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return u;
    }

    public Pasajero buscarPasajeroPorId(int id) {
        Pasajero p = null;
        String consulta_sql = "SELECT * FROM Pasajero WHERE IDPasajero = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                p = new Pasajero();
                p.setId_pasajero(resultado.getInt("IDPasajero"));
                p.setNombre(resultado.getString("nombre_pasajero"));
                p.setApellido(resultado.getString("apellido_pasajero"));
                p.setDni(resultado.getString("dni_pasajero"));
                p.setTelefono(resultado.getString("telefono"));
                p.setFecha_nacimiento(resultado.getDate("fecha_nacimiento").toLocalDate());
                p.setNroPasaporte(resultado.getString("nro_pasaporte"));
                p.setPaisEmision(resultado.getString("pais_emision"));
                p.setVencimientoPasaporte(resultado.getDate("vencimiento_pasaporte").toLocalDate());
                
                int idUsuario = resultado.getInt("usuario_id");
                p.setUsuario(buscarUsuarioPorId(idUsuario));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Pasajero): " + ex.getMessage(), 
                    "Error - Buscar Pasajero Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return p;
    }

    public Boleto buscarBoletoPorId(int id) {
        Boleto b = null;
        String consulta_sql = "SELECT * FROM Boleto WHERE IDBoleto = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                b = new Boleto();
                b.setId_boleto(resultado.getInt("IDBoleto"));
                b.setFecha(resultado.getTimestamp("fecha").toLocalDateTime());
                b.setPrecio_base(resultado.getDouble("precio_base"));

                int idPasajero = resultado.getInt("pasajero_id");
                b.setPasajero(buscarPasajeroPorId(idPasajero));

                int idVuelo = resultado.getInt("vuelo_id");
                VueloDAO vDAO = new VueloDAO();
                b.setVuelo(vDAO.buscarVuelo(idVuelo).get(0)); 

                Asiento asiento = new Asiento();
                asiento.setId_asiento(resultado.getString("asiento_id"));
                b.setAsiento(asiento);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Boleto): " + ex.getMessage(), 
                    "Error - Buscar Boleto Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return b;
    }
}