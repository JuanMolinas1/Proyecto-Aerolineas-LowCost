package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.time.LocalDate;
import javax.swing.JOptionPane;

public class PasajeroDAO {

    public void insertPasajero(PreparedStatement sentencia_sql, Pasajero p) throws SQLException {
        sentencia_sql.setString(1, p.getNombre());
        sentencia_sql.setString(2, p.getApellido());
        sentencia_sql.setString(3, p.getDni());
        sentencia_sql.setString(4, p.getTelefono());
        sentencia_sql.setObject(5, p.getFecha_nacimiento());
        sentencia_sql.setString(6, p.getNroPasaporte());
        sentencia_sql.setString(7, p.getPaisEmision());
        sentencia_sql.setObject(8, p.getVencimientoPasaporte());
        sentencia_sql.setInt(9, p.getUsuario().getId_usuario());
    }

    public Pasajero selectPasajero(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        Pasajero p = new Pasajero();
        
        p.setId_pasajero(resultado.getInt("IDPasajero"));
        p.setNombre(resultado.getString("nombre_pasajero"));
        p.setApellido(resultado.getString("apellido_pasajero"));
        p.setDni(resultado.getString("dni_pasajero"));
        p.setTelefono(resultado.getString("telefono"));
        
        if (resultado.getDate("fecha_nacimiento") != null) {
            p.setFecha_nacimiento(resultado.getDate("fecha_nacimiento").toLocalDate());
        }
        
        p.setNroPasaporte(resultado.getString("nro_pasaporte"));
        p.setPaisEmision(resultado.getString("pais_emision"));
        
        if (resultado.getDate("vencimiento_pasaporte") != null) {
            p.setVencimientoPasaporte(resultado.getDate("vencimiento_pasaporte").toLocalDate());
        }
        
        int idUsuario = resultado.getInt("usuario_id");
        Usuario u = exDAO.buscarUsuarioPorId(idUsuario);
        p.setUsuario(u);
        
        return p;
    }

    public void agregarPasajero(Pasajero p) {
        String consulta_sql = "INSERT INTO Pasajero (nombre_pasajero, apellido_pasajero, dni_pasajero, telefono, fecha_nacimiento, nro_pasaporte, pais_emision, vencimiento_pasaporte, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertPasajero(sentencia_sql, p);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Pasajero Guardado Exitosamente",
                    "Creación de Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Pasajero",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public ArrayList<Pasajero> mostrarPasajero() {
        ArrayList<Pasajero> l_pasajeros = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Pasajero";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                l_pasajeros.add(selectPasajero(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Pasajeros",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_pasajeros;
    }

    public ArrayList<Pasajero> buscarPasajero(int id) {
        ArrayList<Pasajero> l_pasajeros = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Pasajero WHERE IDPasajero = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                l_pasajeros.add(selectPasajero(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un pasajero con el ID: " + id,
                    "Buscar Pasajero",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Pasajero",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_pasajeros;
    }

    public void editarPasajero(Pasajero p) {
        String consulta_sql = "UPDATE Pasajero SET nombre_pasajero = ?, apellido_pasajero = ?, dni_pasajero = ?, telefono = ?, fecha_nacimiento = ?, nro_pasaporte = ?, pais_emision = ?, vencimiento_pasaporte = ?, usuario_id = ? WHERE IDPasajero = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, p.getNombre());
            sentencia_sql.setString(2, p.getApellido());
            sentencia_sql.setString(3, p.getDni());
            sentencia_sql.setString(4, p.getTelefono());
            sentencia_sql.setObject(5, p.getFecha_nacimiento());
            sentencia_sql.setString(6, p.getNroPasaporte());
            sentencia_sql.setString(7, p.getPaisEmision());
            sentencia_sql.setObject(8, p.getVencimientoPasaporte());
            sentencia_sql.setInt(9, p.getUsuario().getId_usuario());
            sentencia_sql.setInt(10, p.getId_pasajero());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Pasajero Actualizado Exitosamente",
                    "Edición de Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Pasajero",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void eliminarPasajero(int id) {
        String consulta_sql = "DELETE FROM Pasajero WHERE IDPasajero = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Pasajero Eliminado Exitosamente",
                    "Eliminar Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar Pasajero",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}