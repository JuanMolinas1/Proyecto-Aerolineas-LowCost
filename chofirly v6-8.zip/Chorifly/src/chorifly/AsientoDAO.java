package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class AsientoDAO {
    public void listarAsiento(){
        String consulta_sql = "SELECT * FROM Asiento";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Asiento --"
                + "\nID Asiento: " + resultado.getString("IDAsiento")
                + "\nCódigo: " + resultado.getString("codigo")
                + "\nAvión: " + resultado.getString("avion_id")
                + "\nTipo: " + resultado.getString("tipo")
                + "\nDisponible: " + resultado.getBoolean("disponible"),
                "Listado de Asientos",
                JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Asientos",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
