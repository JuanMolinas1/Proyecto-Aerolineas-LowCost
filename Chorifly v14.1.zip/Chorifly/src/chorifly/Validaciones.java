package chorifly;

import javax.swing.JOptionPane;

public class Validaciones {
    public boolean validarCuenta(String usuario, String email, String contraseña, String repetirContraseña, String pregunta, String respuesta) {
        UsuarioDAO udao = new UsuarioDAO();

        if (usuario.isEmpty()){
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario no puede estar vacío.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            
            return false;
        }
        
        // Modificado para aceptar letras y guion bajo (_) únicamente
        if (!usuario.matches("^[a-zA-ZñÑáéíóúÁÉÍÓÚ_]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario solo puede contener letras y guiones bajos (sin números ni espacios).",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El correo electrónico no puede estar vacío.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña no puede estar vacía.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (!contraseña.matches("^[a-zA-ZñÑ0-9!\"#$%]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña solo puede contener letras, números y caracteres.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (repetirContraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debe repetir la contraseña.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        String regexGmail = "(?i)^[a-zA-Z0-9._%+-]+@gmail\\.com$";
        if (!email.matches(regexGmail)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debes ingresar un correo válido con formato @gmail.com.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (!contraseña.equals(repetirContraseña)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Las contraseñas no son iguales.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (pregunta.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debe ingresar una pregunta de seguridad.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (respuesta.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La respuesta de seguridad no puede estar vacía.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (udao.existeUsuario(usuario)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario ya está en uso.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (udao.existeEmail(email)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El correo electrónico ya está registrado.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        return true;
    }
    
    public boolean validarContraseña(String contraseña, String repetirContraseña) {
        UsuarioDAO udao = new UsuarioDAO();
        
        if (contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña no puede estar vacía.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (!contraseña.matches("^[a-zA-ZñÑ0-9!\"#$%]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña solo puede contener letras, números y caracteres especiales.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if(!(contraseña.length()>=8)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña debe al menos 8 caracteres.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if(!(contraseña.equals(repetirContraseña))) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Las contraseñas deben ser iguales.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        return true;
    }
}
