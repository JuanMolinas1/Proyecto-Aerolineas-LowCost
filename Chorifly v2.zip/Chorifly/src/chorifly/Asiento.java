package chorifly;

public class Asiento {
    private String id_asiento;
    private String codigo;
    private Avion avion;
    private String tipo;
    private boolean disponible;

    public Asiento(String codigo, String tipo, boolean disponible) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.disponible = disponible;
    }

    public String getId_asiento() {
        return id_asiento;
    }

    public void setId_asiento(String id_asiento) {
        this.id_asiento = id_asiento;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Avion getAvion() {
        return avion;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
}
