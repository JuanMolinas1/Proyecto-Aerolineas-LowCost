package chorifly;

import java.util.ArrayList;

public class Aerolinea {
    private String nombre;
    private ArrayList<Persona>      l_empleados     = new ArrayList<>();
    private ArrayList<Persona>      l_pasajeros     = new ArrayList<>();
    private ArrayList<Departamento> l_departamentos = new ArrayList<>();
    private ArrayList<Usuario>      l_usuario       = new ArrayList<>();
    private ArrayList<Aeropuerto>   l_aeropuertos   = new ArrayList<>();
    private ArrayList<Avion>        l_aviones       = new ArrayList<>();
    private ArrayList<Asiento>      l_asiento       = new ArrayList<>();
    private ArrayList<a> a = new ArrayList<>();
    private ArrayList<a> a = new ArrayList<>();
    private ArrayList<a> a = new ArrayList<>();
    private ArrayList<a> a = new ArrayList<>();
}
