package chorifly;

public class Empleado extends Persona{
    private int id_empleado;
    private double sueldo;
    private Departamento departamento;
    private Aeropuerto aeropuertoTrabajo;

    public Empleado(double sueldo, Departamento departamento, Aeropuerto aeropuertoTrabajo, String nombre, String apellido, String dni, String telefono) {
        super(nombre, apellido, dni, telefono);
        this.sueldo = sueldo;
        this.departamento = departamento;
        this.aeropuertoTrabajo = aeropuertoTrabajo;
    }

    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public Aeropuerto getAeropuertoTrabajo() {
        return aeropuertoTrabajo;
    }

    public void setAeropuertoTrabajo(Aeropuerto aeropuertoTrabajo) {
        this.aeropuertoTrabajo = aeropuertoTrabajo;
    }
}
