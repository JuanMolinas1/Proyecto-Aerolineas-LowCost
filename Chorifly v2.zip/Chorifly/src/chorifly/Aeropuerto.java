package chorifly;

import java.util.ArrayList;

public class Aeropuerto {
    private int id_aeropuerto;
    private String nombre;
    private String pais;
    private String ciudad;
    private ArrayList<Persona> empleados = new ArrayList<>();

    public Aeropuerto(String nombre, String pais, String ciudad) {
        this.nombre = nombre;
        this.pais = pais;
        this.ciudad = ciudad;
    }

    public int getId_aeropuerto() {
        return id_aeropuerto;
    }

    public void setId_aeropuerto(int id_aeropuerto) {
        this.id_aeropuerto = id_aeropuerto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public ArrayList<Persona> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Persona> empleados) {
        this.empleados = empleados;
    }
}
