package chorifly;

public class Departamento {
    private String nombre;
    private boolean aereo;

    public Departamento(String nombre, boolean aereo) {
        this.nombre = nombre;
        this.aereo = aereo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isAereo() {
        return aereo;
    }

    public void setAereo(boolean aereo) {
        this.aereo = aereo;
    }
}
