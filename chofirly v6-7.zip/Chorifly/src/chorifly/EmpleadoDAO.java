package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class EmpleadoDAO {
    public void insertarEmpleado(Empleado e) {
        String insert_sql = "INSERT INTO Empleado (nombre_empleado, apellido_empleado, dni_empleado, sueldo, departamento_id, aeropuerto_id, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, e.getNombre());
            sentencia_sql.setString(2, e.getApellido());
            sentencia_sql.setString(3, e.getDni());
            sentencia_sql.setDouble(4, e.getSueldo());
            sentencia_sql.setInt(5, e.getDepartamento().getId_departamento());
            sentencia_sql.setInt(6, e.getAeropuertoTrabajo().getId_aeropuerto());
            sentencia_sql.setInt(7, e.getUsuario().getId_usuario());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Empleado Guardado Exitosamente",
                    "Creación de Empleado",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    public void listarEmpleado(){
        String consulta_sql = "SELECT * FROM Empleado";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Empleado --"
                + "\nID Empleado: " + resultado.getInt("IDEmpleado")
                + "\nNombre: " + resultado.getString("nombre_empleado")
                + "\nApellido: " + resultado.getString("apellido_empleado")
                + "\nDNI: " + resultado.getString("dni_empleado")
                + "\nSueldo: " + resultado.getDouble("sueldo")
                + "\nDepartamento: " + resultado.getInt("departamento_id")
                + "\nAeropuerto: " + resultado.getInt("aeropuerto_id")
                + "\nUsuario Vinculado: " + resultado.getInt("usuario_id"),
                "Listado de Empleados",
                JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Empleados",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
