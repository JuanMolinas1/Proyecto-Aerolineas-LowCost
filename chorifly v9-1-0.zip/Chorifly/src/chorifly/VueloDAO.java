package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;

public class VueloDAO {
    public void insertVuelo(PreparedStatement sentencia_sql, Vuelo v) throws SQLException {
        sentencia_sql.setString(1, v.getAvionUsado().getId_avion());
        sentencia_sql.setInt(2, v.getAeropuertoOrigen().getId_aeropuerto());
        sentencia_sql.setInt(3, v.getAeropuertoDestino().getId_aeropuerto());
        sentencia_sql.setObject(4, v.getFechaHoraSalida());
        sentencia_sql.setObject(5, v.getFechaHoraLlegada());
        sentencia_sql.setString(6, v.getEstado());
    }
    
public Vuelo selectVuelo(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        
        String idAvion = resultado.getString("avion_id");
        int idOrigen = resultado.getInt("origen_id");
        int idDestino = resultado.getInt("destino_id");
        
        Avion avion = exDAO.buscarAvionPorId(idAvion);
        Aeropuerto origen = exDAO.buscarAeropuertoPorId(idOrigen);
        Aeropuerto destino = exDAO.buscarAeropuertoPorId(idDestino);
        
        LocalDateTime salida = resultado.getTimestamp("fecha_hora_salida").toLocalDateTime();
        LocalDateTime llegada = resultado.getTimestamp("fecha_hora_llegada").toLocalDateTime();
        
        Vuelo v = new Vuelo(
            avion, 
            origen, 
            destino, 
            salida, 
            llegada, 
            resultado.getString("estado")
        );
        
        v.setId_vuelo(resultado.getInt("IDVuelo"));
        
        return v;
    }
    
    public void agregarVuelo(Vuelo v) {
        String consulta_sql = "INSERT INTO Vuelo (avion_id, origen_id, destino_id, fecha_hora_salida, fecha_hora_llegada, estado) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertVuelo(sentencia_sql, v);

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Vuelo Guardado Exitosamente",
                    "Creación de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Vuelo",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public ArrayList<Vuelo> mostrarVuelo() {
        ArrayList<Vuelo> l_vuelos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Vuelo";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                l_vuelos.add(selectVuelo(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Vuelos",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_vuelos;
    }

    public ArrayList<Vuelo> buscarVuelo(int id) {
        ArrayList<Vuelo> l_vuelos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Vuelo WHERE IDVuelo = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);

            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                l_vuelos.add(selectVuelo(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un vuelo con el ID: " + id,
                    "Buscar Vuelo",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Vuelo",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_vuelos;
    }

    public void editarVuelo(Vuelo v) {
        String consulta_sql = "UPDATE Vuelo SET avion_id = ?, origen_id = ?, destino_id = ?, fecha_hora_salida = ?, fecha_hora_llegada = ?, estado = ? WHERE IDVuelo = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, v.getAvionUsado().getId_avion());
            sentencia_sql.setInt(2, v.getAeropuertoOrigen().getId_aeropuerto());
            sentencia_sql.setInt(3, v.getAeropuertoDestino().getId_aeropuerto());
            sentencia_sql.setObject(4, v.getFechaHoraSalida());
            sentencia_sql.setObject(5, v.getFechaHoraLlegada());
            sentencia_sql.setString(6, v.getEstado());
            sentencia_sql.setInt(7, v.getId_vuelo());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Vuelo Actualizado Exitosamente",
                    "Edición de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Vuelo",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void eliminarVuelo(int id) {
        String consulta_sql = "DELETE FROM Vuelo WHERE IDVuelo = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Vuelo Eliminado Exitosamente",
                    "Eliminar Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar Vuelo",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
