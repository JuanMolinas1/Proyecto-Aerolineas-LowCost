package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class AsientoDAO {
    public String selectAsiento(ResultSet resultado) throws SQLException {
        return "-- Mostrar : Asiento --"
                + "\nID Asiento: " + resultado.getString("IDAsiento")
                + "\nCódigo: " + resultado.getString("codigo")
                + "\nAvión: " + resultado.getString("avion_id")
                + "\nTipo: " + resultado.getString("tipo")
                + "\nDisponible: " + resultado.getBoolean("disponible");
    }

    public void mostrarAsiento() {
        String consulta_sql = "SELECT * FROM Asiento";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    selectAsiento(resultado),
                    "Listado de Asientos",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Asientos",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarAsiento(boolean disponible) {
        String consulta_sql = "SELECT * FROM Asiento WHERE disponible = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setBoolean(1, disponible);

            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                do {
                    JOptionPane.showMessageDialog(
                        null,
                        selectAsiento(resultado),
                        "Buscar Asientos",
                        JOptionPane.INFORMATION_MESSAGE);
                } while (resultado.next());

            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existen asientos con disponibilidad: " + disponible,
                    "Buscar Asientos",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Asientos",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void editarAsiento(Asiento a) {
        String consulta_sql = "UPDATE Asiento SET disponible = ? WHERE IDAsiento = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setBoolean(1, a.isDisponible());
            sentencia_sql.setString(2, a.getId_asiento());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Disponibilidad del Asiento Actualizada Exitosamente",
                    "Edición de Asiento",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Asiento",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
