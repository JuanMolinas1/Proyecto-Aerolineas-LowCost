package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;

public class ExtrasDAO {
    public Avion buscarAvionPorId(String id) {
        Avion avion = new Avion();
        String consulta_sql = "SELECT * FROM Avion WHERE id_avion = ?"; 

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1, id);
            
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                avion = new Avion();
                avion.setId_avion(resultado.getString("id_avion"));
                avion.setModelo(resultado.getString("modelo"));
                avion.setCapacidad(resultado.getInt("capacidad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error en BD (Avión): " + ex.getMessage(),
                    "Error - Buscar Avión Por ID",
                    JOptionPane.ERROR_MESSAGE);
        }
        return avion;
    }
    
    public Aeropuerto buscarAeropuertoPorId(int id) {
        Aeropuerto aeropuerto = new Aeropuerto();
        String consulta_sql = "SELECT * FROM Aeropuerto WHERE IDAeropuerto = ?"; 

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                aeropuerto = new Aeropuerto();
                aeropuerto.setId_aeropuerto(resultado.getInt("IDAeropuerto"));
                aeropuerto.setNombre(resultado.getString("nombre"));
                aeropuerto.setPais(resultado.getString("pais"));
                aeropuerto.setCiudad(resultado.getString("ciudad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error en BD (Aeropuerto): " + ex.getMessage(),
                    "Error - Buscar Aeropuerto Por ID",
                    JOptionPane.ERROR_MESSAGE);
        }
        return aeropuerto;
    }
}
