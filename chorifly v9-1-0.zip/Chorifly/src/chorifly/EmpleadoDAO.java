package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class EmpleadoDAO {
    public void insertEmpleado(PreparedStatement sentencia_sql, Empleado e) throws SQLException {
        sentencia_sql.setString(1, e.getNombre());
        sentencia_sql.setString(2, e.getApellido());
        sentencia_sql.setString(3, e.getDni());
        sentencia_sql.setDouble(4, e.getSueldo());
        sentencia_sql.setInt(5, e.getDepartamento().getId_departamento());
        sentencia_sql.setInt(6, e.getAeropuertoTrabajo().getId_aeropuerto());
        sentencia_sql.setInt(7, e.getUsuario().getId_usuario());
    }

    public String selectEmpleado(ResultSet resultado) throws SQLException {
        return "-- Mostrar : Empleado --"
                + "\nID Empleado: " + resultado.getInt("IDEmpleado")
                + "\nNombre: " + resultado.getString("nombre_empleado")
                + "\nApellido: " + resultado.getString("apellido_empleado")
                + "\nDNI: " + resultado.getString("dni_empleado")
                + "\nSueldo: " + resultado.getDouble("sueldo")
                + "\nDepartamento: " + resultado.getInt("departamento_id")
                + "\nAeropuerto: " + resultado.getInt("aeropuerto_id")
                + "\nUsuario Vinculado: " + resultado.getInt("usuario_id");
    }

    public void agregarEmpleado(Empleado e) {
        String consulta_sql = "INSERT INTO Empleado (nombre_empleado, apellido_empleado, dni_empleado, sueldo, departamento_id, aeropuerto_id, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertEmpleado(sentencia_sql, e);

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Empleado Guardado Exitosamente",
                    "Creación de Empleado",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void mostrarEmpleado() {
        String consulta_sql = "SELECT * FROM Empleado";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    selectEmpleado(resultado),
                    "Listado de Empleados",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Empleados",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarEmpleado(int id) {
        String consulta_sql = "SELECT * FROM Empleado WHERE IDEmpleado = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);

            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    selectEmpleado(resultado),
                    "Buscar Empleado",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un empleado con el ID: " + id,
                    "Buscar Empleado",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void editarEmpleado(Empleado e) {
        String consulta_sql = "UPDATE Empleado SET nombre_empleado = ?, apellido_empleado = ?, dni_empleado = ?, sueldo = ?, departamento_id = ?, aeropuerto_id = ?, usuario_id = ? WHERE IDEmpleado = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, e.getNombre());
            sentencia_sql.setString(2, e.getApellido());
            sentencia_sql.setString(3, e.getDni());
            sentencia_sql.setDouble(4, e.getSueldo());
            sentencia_sql.setInt(5, e.getDepartamento().getId_departamento());
            sentencia_sql.setInt(6, e.getAeropuertoTrabajo().getId_aeropuerto());
            sentencia_sql.setInt(7, e.getUsuario().getId_usuario());
            sentencia_sql.setInt(8, e.getId_empleado());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Empleado Actualizado Exitosamente",
                    "Edición de Empleado",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void eliminarEmpleado(int id) {
        String consulta_sql = "DELETE FROM Empleado WHERE IDEmpleado = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Empleado Eliminado Exitosamente",
                    "Eliminar Empleado",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
