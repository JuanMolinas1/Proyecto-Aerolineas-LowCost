package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;

public class ExtrasDAO {
    public Avion buscarAvionPorId(String id) {
        Avion avion = null;
        // Ajusta 'id_avion' al nombre real de la columna en tu tabla Avion
        String consulta_sql = "SELECT * FROM Avion WHERE id_avion = ?"; 

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setString(1, id);
            
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                avion = new Avion();
                avion.setId_avion(resultado.getString("id_avion"));
                // Si tu clase Avion tiene más campos (ej: modelo, capacidad), los agregas aquí:
                // avion.setModelo(resultado.getString("modelo"));
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró el avión con ID: " + id, "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error en BD (Avión): " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return avion;
    }
}
