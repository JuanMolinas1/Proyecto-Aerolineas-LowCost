package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class UsuarioDAO {
    public void insertUsuario(PreparedStatement sentencia_sql, Usuario u) throws SQLException {
        sentencia_sql.setString(1, u.getUsuario());
        sentencia_sql.setString(2, u.getEmail());
        sentencia_sql.setString(3, u.getContraseña());
        sentencia_sql.setBoolean(4, u.isPrivilegios_empleado());
    }

    public String selectUsuario(ResultSet resultado) throws SQLException {
        return "-- Mostrar : Usuario --"
                + "\nID Usuario: " + resultado.getInt("IDUsuario")
                + "\nNombre de Usuario: " + resultado.getString("nombre_usuario")
                + "\nEmail: " + resultado.getString("email")
                + "\nContraseña: " + resultado.getString("contraseña_usuario")
                + "\nPrivilegios de Empleado: " + resultado.getBoolean("privilegios_empleado");
    }

    public void agregarUsuario(Usuario u) {
        String insert_sql = "INSERT INTO Usuario (nombre_usuario, email, contraseña_usuario, privilegios_empleado) VALUES (?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(insert_sql);

            insertUsuario(sentencia_sql, u);

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Usuario Guardado Exitosamente",
                    "Creación de Usuario",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void mostrarUsuario() {
        String consulta_sql = "SELECT * FROM Usuario";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    selectUsuario(resultado),
                    "Listado de Usuarios",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Usuarios",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarUsuario(int id) {
        String consulta_sql = "SELECT * FROM Usuario WHERE IDUsuario = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);

            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    selectUsuario(resultado),
                    "Buscar Usuario",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un usuario con el ID: " + id,
                    "Buscar Usuario",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void editarUsuario(Usuario u) {
        String consulta_sql = "UPDATE Usuario SET nombre_usuario = ?, email = ?, contraseña_usuario = ?, privilegios_empleado = ? WHERE IDUsuario = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, u.getUsuario());
            sentencia_sql.setString(2, u.getEmail());
            sentencia_sql.setString(3, u.getContraseña());
            sentencia_sql.setBoolean(4, u.isPrivilegios_empleado());
            sentencia_sql.setInt(5, u.getId_usuario());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Usuario Actualizado Exitosamente",
                    "Edición de Usuario",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Usuario",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}