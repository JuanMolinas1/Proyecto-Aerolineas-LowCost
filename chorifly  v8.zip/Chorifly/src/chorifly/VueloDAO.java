package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class VueloDAO {
    public void insertVuelo(PreparedStatement sentencia_sql, Vuelo v) throws SQLException {
        sentencia_sql.setString(1, v.getAvionUsado().getId_avion());
        sentencia_sql.setInt(2, v.getAeropuertoOrigen().getId_aeropuerto());
        sentencia_sql.setInt(3, v.getAeropuertoDestino().getId_aeropuerto());
        sentencia_sql.setObject(4, v.getFechaHoraSalida());
        sentencia_sql.setObject(5, v.getFechaHoraLlegada());
        sentencia_sql.setString(6, v.getEstado());
    }
    
    public String selectVuelo(ResultSet resultado) throws SQLException {
        return "-- Mostrar : Vuelo --"
                + "\nID Vuelo: " + resultado.getInt("IDVuelo")
                + "\nAvión: " + resultado.getString("avion_id")
                + "\nOrigen: " + resultado.getInt("origen_id")
                + "\nDestino: " + resultado.getInt("destino_id")
                + "\nFecha y Hora de Salida: " + resultado.getTimestamp("fecha_hora_salida")
                + "\nFecha y Hora de Llegada: " + resultado.getTimestamp("fecha_hora_llegada")
                + "\nEstado: " + resultado.getString("estado");
    }
    
    public void agregarVuelo(Vuelo v) {
        String insert_sql = "INSERT INTO Vuelo (avion_id, origen_id, destino_id, fecha_hora_salida, fecha_hora_llegada, estado) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(insert_sql);

            insertVuelo(sentencia_sql, v);

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Vuelo Guardado Exitosamente",
                    "Creación de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Vuelo",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void mostrarVuelo() {
        String consulta_sql = "SELECT * FROM Vuelo";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    selectVuelo(resultado),
                    "Listado de Vuelos",
                    JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Vuelos",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void buscarVuelo(int id) {
        String consulta_sql = "SELECT * FROM Vuelo WHERE IDVuelo = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);

            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                JOptionPane.showMessageDialog(
                    null,
                    selectVuelo(resultado),
                    "Buscar Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un vuelo con el ID: " + id,
                    "Buscar Vuelo",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Vuelo",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void editarVuelo(Vuelo v) {
        String consulta_sql = "UPDATE Vuelo SET avion_id = ?, origen_id = ?, destino_id = ?, fecha_hora_salida = ?, fecha_hora_llegada = ?, estado = ? WHERE IDVuelo = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, v.getAvionUsado().getId_avion());
            sentencia_sql.setInt(2, v.getAeropuertoOrigen().getId_aeropuerto());
            sentencia_sql.setInt(3, v.getAeropuertoDestino().getId_aeropuerto());
            sentencia_sql.setObject(4, v.getFechaHoraSalida());
            sentencia_sql.setObject(5, v.getFechaHoraLlegada());
            sentencia_sql.setString(6, v.getEstado());
            sentencia_sql.setInt(7, v.getId_vuelo());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Vuelo Actualizado Exitosamente",
                    "Edición de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Vuelo",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
