package chorifly;

public class CheckIn {
    private int id_checkin;
    private Pasajero pasajero;
    private Boleto boleto;
    private Vuelo vuelo;
    private Pago pago;
    private String puertaEmbarque;

    public CheckIn(Pasajero pasajero, Boleto boleto, Vuelo vuelo, Pago pago, String puertaEmbarque) {
        this.pasajero = pasajero;
        this.boleto = boleto;
        this.vuelo = vuelo;
        this.pago = pago;
        this.puertaEmbarque = puertaEmbarque;
    }

    public int getId_checkin() {
        return id_checkin;
    }

    public void setId_checkin(int id_checkin) {
        this.id_checkin = id_checkin;
    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public Boleto getBoleto() {
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public String getPuertaEmbarque() {
        return puertaEmbarque;
    }

    public void setPuertaEmbarque(String puerta_embarque) {
        this.puertaEmbarque = puerta_embarque;
    }
}
