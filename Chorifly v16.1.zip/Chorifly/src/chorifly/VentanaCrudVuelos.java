package chorifly;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.DateTimeException;
import java.text.SimpleDateFormat;

public class VentanaCrudVuelos extends javax.swing.JFrame {
    private boolean vieneDeAdmin;
    private ExtrasDAO edao = new ExtrasDAO();
    SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
    
    public VentanaCrudVuelos(boolean vieneDeAdmin) {
        this.vieneDeAdmin = vieneDeAdmin;
        initComponents();
        
        // No editables
        txtAvion.setText("Seleccionar Avión");
        txtOrigen.setText("Seleccionar Aeropuerto");
        txtDestino.setText("Seleccionar Aeropuerto");
        txtEstado.setText("Seleccionar Estado");
        
        // Editables
        txtHoraSalida.putClientProperty("JTextField.placeholderText", "HH:MM:SS");
        txtHoraLlegada.putClientProperty("JTextField.placeholderText", "HH:MM:SS");
        txtBuscar.putClientProperty("JTextField.placeholderText", "ID Vuelo");
        
        // Comodidad, evita la selección azul
        txtAvion.setFocusable(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        dateSalida = new com.toedter.calendar.JDateChooser();
        dateLlegada = new com.toedter.calendar.JDateChooser();
        txtHoraSalida = new javax.swing.JTextField();
        txtHoraLlegada = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVuelos = new javax.swing.JTable();
        txtAvion = new javax.swing.JTextField();
        txtOrigen = new javax.swing.JTextField();
        txtDestino = new javax.swing.JTextField();
        txtEstado = new javax.swing.JTextField();
        btnVolver = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Vuelos");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Avion Usado");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Origen");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Destino");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Momento Salida");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Momento Llegada");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Estado");

        txtHoraSalida.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        txtHoraLlegada.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tablaVuelos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Vuelo", "Avion_id", "Origen_id", "Destino_id", "Salida", "Llegada", "Estado"
            }
        ));
        tablaVuelos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaVuelosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaVuelos);

        txtAvion.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtAvion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtAvionMouseClicked(evt);
            }
        });

        txtOrigen.setEditable(false);
        txtOrigen.setBackground(new java.awt.Color(255, 255, 255));
        txtOrigen.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtOrigen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtOrigenMouseClicked(evt);
            }
        });

        txtDestino.setEditable(false);
        txtDestino.setBackground(new java.awt.Color(255, 255, 255));
        txtDestino.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtDestino.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDestinoMouseClicked(evt);
            }
        });

        txtEstado.setEditable(false);
        txtEstado.setBackground(new java.awt.Color(255, 255, 255));
        txtEstado.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtEstado.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtEstadoMouseClicked(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnMostrar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtBuscar))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtEstado)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(dateSalida, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                                    .addComponent(dateLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtHoraLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                                    .addComponent(txtHoraSalida)))
                            .addComponent(txtAvion, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtOrigen, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDestino, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnMostrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtAvion)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtOrigen))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtDestino))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtHoraSalida)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dateSalida, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(dateLlegada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(txtHoraLlegada, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtEstado))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(25, 25, 25)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtAvionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtAvionMouseClicked
        String[] listaAviones = edao.listarAviones();

        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Avión:",
            "Menú Aviones",
            JOptionPane.DEFAULT_OPTION,
            null,
            listaAviones,
            listaAviones[0]
        );

        if (seleccion != null) {
            txtAvion.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Aviones", JOptionPane.WARNING_MESSAGE);
            txtAvion.setText("Seleccionar Avión");
        }
    }//GEN-LAST:event_txtAvionMouseClicked

    private void txtOrigenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtOrigenMouseClicked
        listarAeropuertos(txtOrigen, txtDestino.getText());
    }//GEN-LAST:event_txtOrigenMouseClicked

    private void txtDestinoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDestinoMouseClicked
        listarAeropuertos(txtDestino, txtOrigen.getText());
    }//GEN-LAST:event_txtDestinoMouseClicked

    private void txtEstadoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtEstadoMouseClicked
        String[] listaEstados = edao.listarEstadosVuelos();

        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Estado:",
            "Menú Estados",
            JOptionPane.DEFAULT_OPTION,
            null,
            listaEstados,
            listaEstados[0]
        );

        if (seleccion != null) {
            txtEstado.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Estados", JOptionPane.WARNING_MESSAGE);
            txtEstado.setText("Seleccionar Estado");
        }
    }//GEN-LAST:event_txtEstadoMouseClicked

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaMenuPrincipalAdmin menuPrincipalAdmin = new VentanaMenuPrincipalAdmin();
        VentanaMenuPrincipal menuPrincipal = new VentanaMenuPrincipal();
        if (vieneDeAdmin) {
            menuPrincipalAdmin.setVisible(true);
            menuPrincipalAdmin.setLocationRelativeTo(null);
            this.dispose();
        } else {
            menuPrincipal.setVisible(true);
            menuPrincipal.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        VueloDAO vdao = new VueloDAO();
        
        Avion avion = edao.buscarAvionPorId(txtAvion.getText());
        Aeropuerto origen = edao.buscarAeropuertoPorNombre(txtOrigen.getText());
        Aeropuerto destino = edao.buscarAeropuertoPorNombre(txtDestino.getText());
        
        try {
            String fechaSalida = formato.format(dateSalida.getDate()) + " " + txtHoraSalida.getText();
            String fechaLlegada = formato.format(dateLlegada.getDate()) + " " + txtHoraLlegada.getText();
            
            String estado = txtEstado.getText();

            LocalDateTime fechaHoraSalida = LocalDateTime.parse(
                    fechaSalida,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            );

            LocalDateTime fechaHoraLlegada = LocalDateTime.parse(
                    fechaLlegada,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            );

            Vuelo v = new Vuelo(avion, origen, destino, fechaHoraSalida, fechaHoraLlegada, estado);
            vdao.agregarVuelo(v);
            actualizarTabla();
        } catch (DateTimeException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex, "Creación de Vuelo", JOptionPane.ERROR_MESSAGE);
        }
        

        
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        actualizarTabla();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void tablaVuelosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaVuelosMouseClicked
        int fila = tablaVuelos.getSelectedRow();
        int id = (int) tablaVuelos.getValueAt(fila, 0);

        // Normales
        String avion = tablaVuelos.getValueAt(fila, 1).toString();
        int origen = (int) tablaVuelos.getValueAt(fila, 2);
        int destino = (int) tablaVuelos.getValueAt(fila, 3);
        String estado = tablaVuelos.getValueAt(fila, 6).toString();
        
        // Para fecha y hora
        String fechaHoraSalidaTexto = tablaVuelos.getValueAt(fila, 4).toString();
        String fechaHoraLlegadaTexto = tablaVuelos.getValueAt(fila, 5).toString();

        // Poner Normales
        txtAvion.setText(avion);
        txtOrigen.setText(edao.buscarAeropuertoPorId(origen).getNombre());
        txtDestino.setText(edao.buscarAeropuertoPorId(destino).getNombre());
        txtEstado.setText(estado);
        
        // Formato fecha/hora
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        // Asignar las fechas/horas
        LocalDateTime fechaHoraSalida = LocalDateTime.parse(fechaHoraSalidaTexto, formato);
        LocalDateTime fechaHoraLlegada = LocalDateTime.parse(fechaHoraLlegadaTexto, formato);

        Date fechaSalida = java.sql.Timestamp.valueOf(fechaHoraSalida);
        Date fechaLlegada = java.sql.Timestamp.valueOf(fechaHoraLlegada);

        Calendar calendarioSalida = Calendar.getInstance();
        calendarioSalida.setTime(fechaSalida);

        Calendar calendarioLlegada = Calendar.getInstance();
        calendarioLlegada.setTime(fechaLlegada);

        dateSalida.setCalendar(calendarioSalida);
        dateLlegada.setCalendar(calendarioLlegada);

        txtHoraSalida.setText(fechaHoraSalida.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        txtHoraLlegada.setText(fechaHoraLlegada.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
    }//GEN-LAST:event_tablaVuelosMouseClicked

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int fila = tablaVuelos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un vuelo.",
                "Edición de Vuelo",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaVuelos.getValueAt(fila, 0);

        VueloDAO vdao = new VueloDAO();

        Avion avion = edao.buscarAvionPorId(txtAvion.getText());
        Aeropuerto origen = edao.buscarAeropuertoPorNombre(txtOrigen.getText());
        Aeropuerto destino = edao.buscarAeropuertoPorNombre(txtDestino.getText());

        String fechaSalida = formato.format(dateSalida.getDate()) + " " + txtHoraSalida.getText();
        String fechaLlegada = formato.format(dateLlegada.getDate()) + " " + txtHoraLlegada.getText();

        String estado = txtEstado.getText();

        LocalDateTime fechaHoraSalida = LocalDateTime.parse(
                fechaSalida,
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        );

        LocalDateTime fechaHoraLlegada = LocalDateTime.parse(
                fechaLlegada,
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        );

        Vuelo v = new Vuelo(
                avion,
                origen,
                destino,
                fechaHoraSalida,
                fechaHoraLlegada,
                estado
        );

        v.setIdVuelo(id);
        vdao.editarVuelo(v);
        actualizarTabla();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tablaVuelos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un vuelo.",
                "Eliminar Vuelo",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaVuelos.getValueAt(fila, 0);
        VueloDAO vdao = new VueloDAO();
        vdao.eliminarVuelo(id);
        actualizarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        VueloDAO vdao = new VueloDAO();
        int id = Integer.parseInt(txtBuscar.getText());
        ArrayList<Vuelo> vuelos = vdao.buscarVuelo(id);
        DefaultTableModel modelo = (DefaultTableModel) tablaVuelos.getModel();

        modelo.setRowCount(0);

        for (Vuelo v : vuelos) {

            modelo.addRow(new Object[]{
                v.getId_vuelo(),
                v.getAvionUsado().getIdAvion(),
                v.getAeropuertoOrigen().getIdAeropuerto(),
                v.getAeropuertoDestino().getIdAeropuerto(),
                v.getFechaHoraSalida().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                v.getFechaHoraLlegada().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                v.getEstado()
            });
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    public void listarAeropuertos(javax.swing.JTextField txtAeropuerto, String textoAExcluir) {
        String[] todosLosAeropuertos = edao.listarAeropuertos();
        ArrayList<String> listaModificable = new ArrayList<>(Arrays.asList(todosLosAeropuertos));

        if (!textoAExcluir.equals("Seleccionar Aeropuerto")) {
            listaModificable.remove(textoAExcluir);
        }

        String[] opcionesDisponibles = listaModificable.toArray(new String[0]);
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Aeropuerto:",
            "Menú Aeropuertos",
            JOptionPane.DEFAULT_OPTION,
            null,
            opcionesDisponibles,
            opcionesDisponibles[0]
        );

        if (seleccion != null) {
            txtAeropuerto.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Aeropuertos", JOptionPane.WARNING_MESSAGE);
            txtAeropuerto.setText("Seleccionar Aeropuerto");
        }
    }
    
    public void actualizarTabla() {
        VueloDAO vdao = new VueloDAO();
        ArrayList<Vuelo> listaVuelos = vdao.mostrarVuelo();
        DefaultTableModel modelo = (DefaultTableModel)tablaVuelos.getModel();
        DateTimeFormatter formatoFechaHora = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        
        modelo.setRowCount(0);
        
        for (Vuelo v : listaVuelos) {
            modelo.addRow(new Object []{
                v.getId_vuelo(),
                v.getAvionUsado().getIdAvion(),
                v.getAeropuertoOrigen().getIdAeropuerto(),
                v.getAeropuertoDestino().getIdAeropuerto(),
                v.getFechaHoraSalida().format(formatoFechaHora),
                v.getFechaHoraLlegada().format(formatoFechaHora),
                v.getEstado()
            });
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private com.toedter.calendar.JDateChooser dateLlegada;
    private com.toedter.calendar.JDateChooser dateSalida;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaVuelos;
    private javax.swing.JTextField txtAvion;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDestino;
    private javax.swing.JTextField txtEstado;
    private javax.swing.JTextField txtHoraLlegada;
    private javax.swing.JTextField txtHoraSalida;
    private javax.swing.JTextField txtOrigen;
    // End of variables declaration//GEN-END:variables
}
