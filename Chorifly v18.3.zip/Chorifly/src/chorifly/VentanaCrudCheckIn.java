package chorifly;

import java.util.Arrays;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import java.time.format.DateTimeFormatter;

public class VentanaCrudCheckIn extends javax.swing.JFrame {
    private boolean vieneDeAdmin;
    private boolean seleccionAsientoVuelo = false;
    private boolean seleccionAsientoServicio = false;
    private boolean editandoBoleto = false;

    private ExtrasDAO edao = new ExtrasDAO();
    private Validaciones valid = new Validaciones();
    private Utilidades uti = new Utilidades();

    private Asiento asientoSeleccionado = null;
    private Vuelo vueloSeleccionado = null;

    private ArrayList<JCheckBox> listaChecksServicios = new ArrayList<>();
    private ArrayList<Servicio> listaServiciosBD = new ArrayList<>();
    
    public VentanaCrudCheckIn(boolean vieneDeAdmin) {
        this.vieneDeAdmin = vieneDeAdmin;
        initComponents();
        
        // No editables
        txtBoleto.setText("Seleccionar Boleto");
        txtPuertaEmbarque.setText("Seleccionar Puerta Embarque");
        
        // Editables
        txtBuscar.putClientProperty("JTextField.placeholderText", "ID Boleto");
        
        // Comodidad, evita la selección azul
        txtBoleto.setFocusable(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCheckIn = new javax.swing.JTable();
        txtBoleto = new javax.swing.JTextField();
        txtPuertaEmbarque = new javax.swing.JTextField();
        btnVolver = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chorifly - Menú Boletos");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Check In");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Boleto");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Puerta Embarque");

        tablaCheckIn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Check In", "Pasajero_id", "Boleto_id", "Vuelo_id", "Pago_id", "Puerta Embarque"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaCheckIn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCheckInMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCheckIn);
        if (tablaCheckIn.getColumnModel().getColumnCount() > 0) {
            tablaCheckIn.getColumnModel().getColumn(0).setResizable(false);
            tablaCheckIn.getColumnModel().getColumn(1).setResizable(false);
            tablaCheckIn.getColumnModel().getColumn(2).setResizable(false);
            tablaCheckIn.getColumnModel().getColumn(3).setResizable(false);
            tablaCheckIn.getColumnModel().getColumn(4).setResizable(false);
            tablaCheckIn.getColumnModel().getColumn(5).setResizable(false);
        }

        txtBoleto.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtBoleto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtBoletoMouseClicked(evt);
            }
        });

        txtPuertaEmbarque.setEditable(false);
        txtPuertaEmbarque.setBackground(new java.awt.Color(255, 255, 255));
        txtPuertaEmbarque.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtPuertaEmbarque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPuertaEmbarqueMouseClicked(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnMostrar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(txtBuscar))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtBoleto, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPuertaEmbarque, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnMostrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtBoleto)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtPuertaEmbarque))
                        .addGap(147, 147, 147)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(25, 25, 25)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyPressed

    }//GEN-LAST:event_txtBuscarKeyPressed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
    int fila = tablaCheckIn.getSelectedRow();

    if (fila == -1) {
        JOptionPane.showMessageDialog(
            null,
            "Debe seleccionar un registro de la tabla para editar el Check-In.",
            "Edición de Check-In",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    if (txtBoleto.getText().equals("Seleccionar Boleto") || txtPuertaEmbarque.getText().equals("Seleccionar Puerta Embarque")) {
        JOptionPane.showMessageDialog(
            null,
            "Los campos de Boleto y Puerta de Embarque no pueden estar vacíos.",
            "Edición de Check-In",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    try {
        int idCheckIn = Integer.parseInt(tablaCheckIn.getValueAt(fila, 0).toString());
        int idBoleto = Integer.parseInt(uti.borrarDesdeEspacio(txtBoleto.getText()));
        String puertaEmbarque = txtPuertaEmbarque.getText().trim();

        CheckInDAO cdao = new CheckInDAO();

        Pago pagoAsociado = edao.buscarPagoPorBoletoId(idBoleto);

        if (pagoAsociado == null) {
            JOptionPane.showMessageDialog(
                null,
                "No se encontró un pago válido registrado para este boleto.",
                "Error de Edición",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        
        CheckIn checkEditado = new CheckIn(pagoAsociado, puertaEmbarque);
        checkEditado.setIdCheckin(idCheckIn);

        cdao.editarCheckIn(checkEditado);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(
            null,
            "Ocurrió un error inesperado: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }

    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        CheckInDAO cdao = new CheckInDAO();
        int idBoleto = Integer.parseInt(uti.borrarDesdeEspacio(txtBoleto.getText()));
        String puertaEmbarque = txtPuertaEmbarque.getText();

        CheckIn c = new CheckIn(
                edao.buscarPagoPorBoletoId(idBoleto),
                puertaEmbarque
        );

        cdao.agregarCheckIn(c);
        actualizarTabla();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tablaCheckIn.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un registro de Check-In.",
                "Eliminar Check-In",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaCheckIn.getValueAt(fila, 0);

        CheckInDAO cdao = new CheckInDAO();
        cdao.eliminarCheckIn(id);

        actualizarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        actualizarTabla();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaMenuPrincipalAdmin menuPrincipalAdmin = new VentanaMenuPrincipalAdmin();
        VentanaMenuPrincipal menuPrincipal = new VentanaMenuPrincipal();
        if (vieneDeAdmin) {
            menuPrincipalAdmin.setVisible(true);
            menuPrincipalAdmin.setLocationRelativeTo(null);
            this.dispose();
        } else {
            menuPrincipal.setVisible(true);
            menuPrincipal.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btnVolverActionPerformed

    private void txtPuertaEmbarqueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPuertaEmbarqueMouseClicked
        String [] listaPuertasEmbarque = edao.listarPuertasEmbarque();
        
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona la puerta de embarque:",
            "Menú Puerta Embarque",
            JOptionPane.DEFAULT_OPTION,
            null,
            listaPuertasEmbarque,
            listaPuertasEmbarque[0]
        );
        
        if (seleccion != null) {
            txtPuertaEmbarque.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(
                null,
                "Cancelaste la Operación",
                "Menú Puerta Embarque",
                JOptionPane.WARNING_MESSAGE
            );
        }
    }//GEN-LAST:event_txtPuertaEmbarqueMouseClicked

    private void txtBoletoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtBoletoMouseClicked
        ArrayList<String> listaBoletos = edao.boletosParaCheckIn();

        if (listaBoletos == null || listaBoletos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay boletos registrados en la base de datos.", "Menú Boletos", JOptionPane.ERROR_MESSAGE);
            txtBoleto.setText("Seleccionar Boleto");
            return;
        }
        
        String [] nuevaListaBoletos = listaBoletos.toArray(new String[0]);
        
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Boleto:",
            "Menú Boletos",
            JOptionPane.DEFAULT_OPTION,
            null,
            nuevaListaBoletos,
            nuevaListaBoletos[0]
        );

        if (seleccion != null) {
            txtBoleto.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Boletos", JOptionPane.WARNING_MESSAGE);
            txtBoleto.setText("Seleccionar Boleto");
        }
    }//GEN-LAST:event_txtBoletoMouseClicked

    private void tablaCheckInMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaCheckInMouseClicked
        int fila = tablaCheckIn.getSelectedRow();
        int id = (int) tablaCheckIn.getValueAt(fila, 0);

        String boleto = edao.listarBoletosExtra(edao.buscarBoletoPorId(Integer.parseInt(tablaCheckIn.getValueAt(fila, 2).toString())));
        String puertaEmbarque = tablaCheckIn.getValueAt(fila, 5).toString();

        txtBoleto.setText(boleto);
        txtPuertaEmbarque.setText(puertaEmbarque);
    }//GEN-LAST:event_tablaCheckInMouseClicked

    public void actualizarTabla() {
        CheckInDAO cdao = new CheckInDAO();
        ArrayList<CheckIn> listaCheckIn = cdao.mostrarCheckIn();

        DefaultTableModel modelo = (DefaultTableModel) tablaCheckIn.getModel();

        modelo.setRowCount(0);

        for (CheckIn c : listaCheckIn) {
            modelo.addRow(new Object[]{
                c.getIdCheckin(),
                c.getPasajero().getIdPasajero(),
                c.getBoleto().getIdBoleto(),
                c.getVuelo().getIdVuelo(),
                c.getPago().getIdPago(),
                c.getPuertaEmbarque()
            });
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaCheckIn;
    private javax.swing.JTextField txtBoleto;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtPuertaEmbarque;
    // End of variables declaration//GEN-END:variables
}
