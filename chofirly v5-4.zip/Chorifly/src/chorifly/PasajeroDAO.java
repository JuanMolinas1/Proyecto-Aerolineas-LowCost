package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import javax.swing.JOptionPane;

public class PasajeroDAO {
    public void insertar(Pasajero p) {
        String insert_sql = "INSERT INTO Pasajero (nombre_pasajero, apellido_pasajero, dni_pasajero, telefono, fecha_nacimiento, nro_pasaporte, pais_emision, vencimiento_pasaporte, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, p.getNombre());
            sentencia_sql.setString(2, p.getApellido());
            sentencia_sql.setString(3, p.getDni());
            sentencia_sql.setString(4, p.getTelefono());
            sentencia_sql.setObject(5, p.getFecha_nacimiento());
            sentencia_sql.setString(6, p.getNroPasaporte());
            sentencia_sql.setString(7, p.getPaisEmision());
            sentencia_sql.setObject(8, p.getFechaVencimientoPasaporte());
            sentencia_sql.setInt(9, p.getUsuario().getId_usuario());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Pasajero Guardado Exitosamente",
                    "Creación de Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
