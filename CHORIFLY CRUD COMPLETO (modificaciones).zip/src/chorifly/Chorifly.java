package chorifly;

import java.sql.Connection;
import java.io.IOException;
public class Chorifly {

 public static void main(String[] args) throws IOException {
        com.formdev.flatlaf.FlatLightLaf.setup();
        ServidorWeb.iniciar();
        Aerolinea chorifly = new Aerolinea("Chorily Airlines");
        Connection con = ConexionSQL.conectar();
        
        if (con != null) {
            System.out.println("Conexión Exitosa.");
        } else {
            System.out.println("Error de Conexión.");
        }
        
        VentanaInicioSesion ventana = new VentanaInicioSesion();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
}