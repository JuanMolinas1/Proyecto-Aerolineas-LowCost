
package chorifly;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class ServidorWeb {

    public static void iniciar() throws IOException {

        HttpServer servidor = HttpServer.create(
                new InetSocketAddress(8080), 0);

        servidor.createContext("/crearVuelo", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);

                String avion = datos.get("avion");
                String origenTexto = datos.get("origen");
                String destinoTexto = datos.get("destino");
                String salida = datos.get("salida");
                String llegada = datos.get("llegada");
                String estado = datos.get("estado");

                if (faltaDato(avion) || faltaDato(origenTexto)
                        || faltaDato(destinoTexto) || faltaDato(salida)
                        || faltaDato(llegada) || faltaDato(estado)) {

                    enviarRespuesta(intercambio, 400,
                            "Completá todos los campos.");
                    return;
                }

                if (avion.length() > 30
                        || !origenTexto.matches("\\d+")
                        || !destinoTexto.matches("\\d+")) {

                    enviarRespuesta(intercambio, 400,
                            "Revisá el avión y los ID de los aeropuertos.");
                    return;
                }

                int origen = Integer.parseInt(origenTexto);
                int destino = Integer.parseInt(destinoTexto);

                if (origen < 1 || destino < 1) {
                    enviarRespuesta(intercambio, 400,
                            "Los ID de los aeropuertos deben ser positivos.");
                    return;
                }

                if (origen == destino) {
                    enviarRespuesta(intercambio, 400,
                            "El origen y el destino deben ser diferentes.");
                    return;
                }

                LocalDateTime fechaSalida = LocalDateTime.parse(salida);
                LocalDateTime fechaLlegada = LocalDateTime.parse(llegada);

                if (!fechaLlegada.isAfter(fechaSalida)) {
                    enviarRespuesta(intercambio, 400,
                            "La llegada debe ser posterior a la salida.");
                    return;
                }

                if (!estadoValido(estado)) {
                    enviarRespuesta(intercambio, 400,
                            "El estado seleccionado no es válido.");
                    return;
                }

                boolean creado = RegistroVuelo.crearVuelo(
                        avion, origen, destino, salida, llegada, estado);

                if (creado) {
                    enviarRespuesta(intercambio, 200,
                            "Vuelo creado correctamente.");
                } else {
                    enviarRespuesta(intercambio, 500,
                            "No se pudo crear el vuelo.");
                }

            } catch (NumberFormatException
                    | java.time.DateTimeException error) {

                enviarRespuesta(intercambio, 400,
                        "Revisá los números y las fechas ingresadas.");

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al guardar el vuelo en MySQL: "
                        + error.getMessage());

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al crear el vuelo.");
            }
        });

        servidor.createContext("/listarVuelos", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("GET")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere GET.");
                return;
            }

            try {
                String consulta =
                        intercambio.getRequestURI().getRawQuery();

                Map<String, String> parametros = new HashMap<>();

                if (consulta != null) {
                    parametros = leerParametrosTexto(consulta);
                }

                String idBuscado = parametros.get("id");

                if (idBuscado != null && !idBuscado.matches("\\d+")) {
                    enviarRespuesta(intercambio, 400,
                            "El ID debe ser un número.");
                    return;
                }

                String vuelos = RegistroVuelo.listarVuelos(idBuscado);
                enviarRespuestaJSON(intercambio, 200, vuelos);

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al consultar los vuelos.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al consultar los vuelos.");
            }
        });

        servidor.createContext("/editarVuelo", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);

                String idTexto = datos.get("id");
                String avion = datos.get("avion");
                String origenTexto = datos.get("origen");
                String destinoTexto = datos.get("destino");
                String salida = datos.get("salida");
                String llegada = datos.get("llegada");
                String estado = datos.get("estado");

                if (faltaDato(idTexto) || faltaDato(avion)
                        || faltaDato(origenTexto)
                        || faltaDato(destinoTexto)
                        || faltaDato(salida) || faltaDato(llegada)
                        || faltaDato(estado)) {

                    enviarRespuesta(intercambio, 400,
                            "Completá todos los campos.");
                    return;
                }

                if (!idTexto.matches("\\d+")
                        || !origenTexto.matches("\\d+")
                        || !destinoTexto.matches("\\d+")
                        || avion.length() > 30) {

                    enviarRespuesta(intercambio, 400,
                            "Revisá el ID, el avión y los aeropuertos.");
                    return;
                }

                int id = Integer.parseInt(idTexto);
                int origen = Integer.parseInt(origenTexto);
                int destino = Integer.parseInt(destinoTexto);

                if (id < 1 || origen < 1 || destino < 1) {
                    enviarRespuesta(intercambio, 400,
                            "Los ID deben ser positivos.");
                    return;
                }

                if (origen == destino) {
                    enviarRespuesta(intercambio, 400,
                            "El origen y el destino deben ser diferentes.");
                    return;
                }

                LocalDateTime fechaSalida = LocalDateTime.parse(salida);
                LocalDateTime fechaLlegada = LocalDateTime.parse(llegada);

                if (!fechaLlegada.isAfter(fechaSalida)) {
                    enviarRespuesta(intercambio, 400,
                            "La llegada debe ser posterior a la salida.");
                    return;
                }

                if (!estadoValido(estado)) {
                    enviarRespuesta(intercambio, 400,
                            "El estado seleccionado no es válido.");
                    return;
                }

                boolean actualizado = RegistroVuelo.editarVuelo(
                        id, avion, origen, destino, salida, llegada, estado);

                if (actualizado) {
                    enviarRespuesta(intercambio, 200,
                            "Vuelo actualizado correctamente.");
                } else {
                    enviarRespuesta(intercambio, 404,
                            "No se encontró el vuelo.");
                }

            } catch (NumberFormatException
                    | java.time.DateTimeException error) {

                enviarRespuesta(intercambio, 400,
                        "Revisá los ID y las fechas ingresadas.");

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al actualizar el vuelo: "
                        + error.getMessage());

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "No se pudo actualizar el vuelo.");
            }
        });

        servidor.createContext("/eliminarVuelo", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);
                String idTexto = datos.get("id");

                if (faltaDato(idTexto) || !idTexto.matches("\\d+")) {
                    enviarRespuesta(intercambio, 400,
                            "El ID del vuelo debe ser un número.");
                    return;
                }

                int id = Integer.parseInt(idTexto);

                if (id < 1) {
                    enviarRespuesta(intercambio, 400,
                            "El ID debe ser positivo.");
                    return;
                }

                boolean eliminado = RegistroVuelo.eliminarVuelo(id);

                if (eliminado) {
                    enviarRespuesta(intercambio, 200,
                            "Vuelo eliminado correctamente.");
                } else {
                    enviarRespuesta(intercambio, 404,
                            "No se encontró el vuelo.");
                }

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "No se pudo eliminar el vuelo. "
                        + "Puede tener registros asociados en la base de datos.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al eliminar el vuelo.");
            }
        });

        servidor.createContext("/verificarUsuario", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("GET")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere GET.");
                return;
            }

            try {
                String consulta =
                        intercambio.getRequestURI().getRawQuery();

                Map<String, String> parametros =
                        consulta == null
                        ? new HashMap<String, String>()
                        : leerParametrosTexto(consulta);

                String usuario = parametros.get("usuario");
                String email = parametros.get("email");

                if (faltaDato(usuario) || faltaDato(email)) {
                    enviarRespuesta(intercambio, 400,
                            "Faltan datos para verificar.");
                    return;
                }

                boolean existe =
                        RegistroUsuario.existeUsuario(usuario, email);

                enviarRespuesta(intercambio, 200,
                        String.valueOf(existe));

            } catch (RuntimeException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al verificar usuario.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al verificar el usuario.");
            }
        });

        servidor.createContext("/", intercambio -> {

            String ruta = intercambio.getRequestURI().getPath();

            if (ruta.equals("/")) {
                ruta = "/Chorifly.html";
            }

            Path archivo;

            if (ruta.endsWith(".html")) {
                archivo = Paths.get("HTMLs", ruta.substring(1));

            } else if (ruta.startsWith("/CCSs/")) {
                archivo = Paths.get(
                        "CCSs", ruta.substring("/CCSs/".length()));

            } else if (ruta.startsWith("/JS/")) {
                archivo = Paths.get(
                        "JS", ruta.substring("/JS/".length()));

            } else if (ruta.startsWith("/ImagenesChorifly/")) {
                archivo = Paths.get(
                        "ImagenesChorifly",
                        ruta.substring("/ImagenesChorifly/".length()));

            } else {
                archivo = Paths.get("archivo-inexistente");
            }

            if (!Files.exists(archivo) || !Files.isRegularFile(archivo)) {
                enviarRespuesta(intercambio, 404,
                        "No se encontró el archivo: " + ruta);
                return;
            }

            String tipo = Files.probeContentType(archivo);

            if (ruta.endsWith(".html")) {
                tipo = "text/html; charset=UTF-8";
            } else if (ruta.endsWith(".css")) {
                tipo = "text/css; charset=UTF-8";
            } else if (ruta.endsWith(".js")) {
                tipo = "text/javascript; charset=UTF-8";
            } else if (ruta.endsWith(".png")) {
                tipo = "image/png";
            } else if (ruta.endsWith(".jpg") || ruta.endsWith(".jpeg")) {
                tipo = "image/jpeg";
            } else if (ruta.endsWith(".webp")) {
                tipo = "image/webp";
            } else if (ruta.endsWith(".svg")) {
                tipo = "image/svg+xml";
            } else if (ruta.endsWith(".ico")) {
                tipo = "image/x-icon";
            }

            if (tipo == null) {
                tipo = "application/octet-stream";
            }

            try {
                byte[] contenido = Files.readAllBytes(archivo);

                intercambio.getResponseHeaders().set("Content-Type", tipo);
                intercambio.sendResponseHeaders(200, contenido.length);
                intercambio.getResponseBody().write(contenido);
                intercambio.close();

            } catch (IOException error) {

                error.printStackTrace();

                try {
                    enviarRespuesta(intercambio, 500,
                            "No se pudo leer el archivo solicitado.");
                } catch (IOException ignorado) {
                }
            }
        });

        servidor.start();

        System.out.println(
                "Servidor iniciado en http://localhost:8080");
    }

    private static Map<String, String> leerParametros(
            HttpExchange intercambio) throws IOException {

        String cuerpo = new String(
                intercambio.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8);

        return leerParametrosTexto(cuerpo);
    }

    private static Map<String, String> leerParametrosTexto(String texto) {

        Map<String, String> parametros = new HashMap<>();

        if (texto == null || texto.isEmpty()) {
            return parametros;
        }

        for (String parametro : texto.split("&")) {
            String[] partes = parametro.split("=", 2);

            try {
                String clave = URLDecoder.decode(
                        partes[0], StandardCharsets.UTF_8);

                String valor = partes.length > 1
                        ? URLDecoder.decode(
                                partes[1], StandardCharsets.UTF_8)
                        : "";

                parametros.put(clave, valor);

            } catch (IllegalArgumentException error) {
                parametros.put("", "");
            }
        }

        return parametros;
    }

    private static boolean faltaDato(String valor) {
        return valor == null || valor.trim().isEmpty();
    }

    private static boolean estadoValido(String estado) {
        return java.util.Arrays.asList(
                "Completado", "Volando", "Programado",
                "A Tiempo", "Atrasado", "Cancelado",
                "Choco", "Exploto", "Perdido"
        ).contains(estado);
    }

    private static void enviarRespuesta(
            HttpExchange intercambio, int codigo, String mensaje)
            throws IOException {

        byte[] contenido = mensaje.getBytes(StandardCharsets.UTF_8);

        intercambio.getResponseHeaders().set(
                "Content-Type", "text/plain; charset=UTF-8");

        intercambio.sendResponseHeaders(codigo, contenido.length);
        intercambio.getResponseBody().write(contenido);
        intercambio.close();
    }

    private static void enviarRespuestaJSON(
            HttpExchange intercambio, int codigo, String mensaje)
            throws IOException {

        byte[] contenido = mensaje.getBytes(StandardCharsets.UTF_8);

        intercambio.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8");

        intercambio.sendResponseHeaders(codigo, contenido.length);
        intercambio.getResponseBody().write(contenido);
        intercambio.close();
    }
}
