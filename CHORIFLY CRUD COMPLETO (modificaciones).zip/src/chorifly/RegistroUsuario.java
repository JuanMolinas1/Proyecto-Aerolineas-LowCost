
package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegistroUsuario {

    public static boolean existeUsuario(String usuario, String email) {

        String sql = "SELECT IDUsuario FROM Usuario "
                   + "WHERE nombre_usuario = ? OR email = ? LIMIT 1";

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new RuntimeException("No se pudo conectar a MySQL");
        }

        try {
            PreparedStatement consulta = conexion.prepareStatement(sql);

            consulta.setString(1, usuario);
            consulta.setString(2, email);

            ResultSet resultado = consulta.executeQuery();

            return resultado.next();

        } catch (SQLException ex) {
            throw new RuntimeException(
                    "Error al consultar Usuario", ex);
        }
    }
}
