package chorifly;

import javax.swing.JOptionPane;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

public class Validaciones {
    public boolean validarCuenta(String usuario, String email, String contraseña, String repetirContraseña, String pregunta, String respuesta) {
        UsuarioDAO udao = new UsuarioDAO();

        if (usuario.isEmpty()){
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario no puede estar vacío.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            
            return false;
        }
        
        if (!usuario.matches("^[a-zA-ZñÑáéíóúÁÉÍÓÚ_]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario solo puede contener letras y guiones bajos (sin números ni espacios).",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El correo electrónico no puede estar vacío.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña no puede estar vacía.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (!contraseña.matches("^[a-zA-ZñÑ0-9!\"#$%]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña solo puede contener letras, números y caracteres.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (repetirContraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debe repetir la contraseña.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        String choriflyEmail = "(?i)^[a-zA-Z0-9._%+-]+@chorifly\\.com$";
        String gmailEmail = "(?i)^[a-zA-Z0-9._%+-]+@gmail\\.com$";
        if (!email.matches(choriflyEmail) && !email.matches(gmailEmail)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debes ingresar un correo válido con formato usuario@gmail.com o usuario@chorifly.com",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (!contraseña.equals(repetirContraseña)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Las contraseñas no son iguales.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (pregunta.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debe ingresar una pregunta de seguridad.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (respuesta.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La respuesta de seguridad no puede estar vacía.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (udao.existeUsuario(usuario)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario ya está en uso.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (udao.existeEmail(email)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El correo electrónico ya está registrado.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        return true;
    }
    
    public boolean validarCuentaEditar(int idUsuario, String usuario, String email, String contraseña, String repetirContraseña, String pregunta, String respuesta) {
        UsuarioDAO udao = new UsuarioDAO();
        
        if (usuario.isEmpty()){
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario no puede estar vacío.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            
            return false;
        }
        
        if (!usuario.matches("^[a-zA-ZñÑáéíóúÁÉÍÓÚ_]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario solo puede contener letras y guiones bajos (sin números ni espacios).",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El correo electrónico no puede estar vacío.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña no puede estar vacía.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (!contraseña.matches("^[a-zA-ZñÑ0-9!\"#$%]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña solo puede contener letras, números y caracteres.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (repetirContraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debe repetir la contraseña.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        String choriflyEmail = "(?i)^[a-zA-Z0-9._%+-]+@chorifly\\.com$";
        String gmailEmail = "(?i)^[a-zA-Z0-9._%+-]+@gmail\\.com$";
        if (!email.matches(choriflyEmail) && !email.matches(gmailEmail)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debes ingresar un correo válido con formato usuario@gmail.com o usuario@chorifly.com",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (!contraseña.equals(repetirContraseña)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Las contraseñas no son iguales.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (pregunta.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Debe ingresar una pregunta de seguridad.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (respuesta.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La respuesta de seguridad no puede estar vacía.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (udao.existeUsuarioEditar(usuario, idUsuario)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El nombre de usuario ya está en uso.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if (udao.existeEmailEditar(email, idUsuario)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El correo electrónico ya está registrado.",
                    "Creación de Usuario",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        return true;
    }
    
    public boolean validarContraseña(String contraseña, String repetirContraseña) {
        UsuarioDAO udao = new UsuarioDAO();
        
        if (contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña no puede estar vacía.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if (!contraseña.matches("^[a-zA-ZñÑ0-9!\"#$%]+$")) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña solo puede contener letras, números y caracteres especiales.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }

        if(!(contraseña.length()>=8)) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - La contraseña debe al menos 8 caracteres.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        if(!(contraseña.equals(repetirContraseña))) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - Las contraseñas deben ser iguales.",
                    "Edición de Contraseña",
                    JOptionPane.ERROR_MESSAGE
                    );
            return false;
        }
        
        return true;
    }
    
    public boolean validarFecha(LocalDateTime fechaHora1, LocalDateTime fechaHora2) {
        if (fechaHora1.isAfter(fechaHora2)) {
            return false;
        }
        return true;
    }
    
    public boolean validarPasajero(String nombre, String apellido, String dni, String telefono, String nroPasaporte, String paisEmision, String usuario, Date fechaNacimiento, Date fechaVencimiento) {

        if (nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El nombre no puede estar vacío.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!nombre.matches("^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ\\s]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El nombre solo puede contener letras y espacios.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (apellido.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El apellido no puede estar vacío.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!apellido.matches("^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ\\s]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El apellido solo puede contener letras y espacios.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (dni.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El DNI no puede estar vacío.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!dni.matches("^[0-9]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El DNI solo puede contener números, sin puntos.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (telefono.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El teléfono no puede estar vacío.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!telefono.matches("^[0-9+\\-\\s()]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El teléfono contiene caracteres no válidos.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (paisEmision.equals("Seleccionar País de Emisión")) {
            JOptionPane.showMessageDialog(null, "Error - Debe seleccionar un país de emisión.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (usuario.equals("Seleccionar Usuario")) {
            JOptionPane.showMessageDialog(null, "Error - Debe seleccionar un usuario.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (nroPasaporte.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El número de pasaporte no puede estar vacío.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (fechaNacimiento == null || fechaVencimiento == null) {
            JOptionPane.showMessageDialog(null, "Error - Debe seleccionar las fechas de nacimiento y vencimiento del pasaporte.", "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }
    
    public boolean validarPasaporte(String paisEmision, String nroPasaporte) {

        if (nroPasaporte.trim().isEmpty()) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error - El número de pasaporte no puede estar vacío.",
                    "Gestión de Pasajeros",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        }

        switch (paisEmision) {

            case "ARG":
                if (!nroPasaporte.matches("^[A-Z]{3}[0-9]{6}$")) {
                    JOptionPane.showMessageDialog(null,
                            "El pasaporte argentino debe tener 3 letras y 6 números.\nEjemplo: ABC123456",
                            "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                break;

            case "CHL":
                if (!nroPasaporte.matches("^[A-Z0-9]{9}$")
                        && !nroPasaporte.matches("^[A-Z]{1,2}[0-9]{7,8}$")) {
                    JOptionPane.showMessageDialog(null,
                            "El pasaporte chileno debe tener 9 caracteres alfanuméricos o el formato anterior de 1-2 letras y 7-8 números.\nEjemplo: P12345678",
                            "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                break;

            case "BRA":
                if (!nroPasaporte.matches("^[A-Z]{2}[0-9]{6}$")) {
                    JOptionPane.showMessageDialog(null,
                            "El pasaporte brasileño debe tener 2 letras y 6 números.\nEjemplo: FA123456",
                            "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                break;

            case "COL":
                if (!nroPasaporte.matches("^[A-Z]{2}[0-9]{6}$")) {
                    JOptionPane.showMessageDialog(null,
                            "El pasaporte colombiano debe tener 2 letras y 6 números.\nEjemplo: PS123456",
                            "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                break;

            case "MEX":
                if (!nroPasaporte.matches("^[A-Z0-9]{10}$")) {
                    JOptionPane.showMessageDialog(null,
                            "El pasaporte mexicano debe tener 10 caracteres alfanuméricos.\nEjemplo: A123456789",
                            "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                break;

            case "PER":
                if (!nroPasaporte.matches("^[A-Z][0-9]{8}$")) {
                    JOptionPane.showMessageDialog(null,
                            "El pasaporte peruano debe tener 1 letra y 8 números.\nEjemplo: L12345678",
                            "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
                break;

            default:
                JOptionPane.showMessageDialog(null,
                        "Debe seleccionar un país de emisión válido.",
                        "Gestión de Pasajeros", JOptionPane.ERROR_MESSAGE);
                return false;
        }
        return true;
    }
    
    public boolean validarEmpleado(String nombre, String apellido, String dni, String telefono, String sueldo) {

        if (nombre.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El nombre no puede estar vacío.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!nombre.matches("^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ\\s]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El nombre solo puede contener letras y espacios.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (apellido.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El apellido no puede estar vacío.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!apellido.matches("^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ\\s]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El apellido solo puede contener letras y espacios.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (dni.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El DNI no puede estar vacío.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!dni.matches("^[0-9]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El DNI solo puede contener números, sin puntos.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (telefono.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El teléfono no puede estar vacío.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!telefono.matches("^[0-9+\\-\\s()]+$")) {
            JOptionPane.showMessageDialog(null, "Error - El teléfono contiene caracteres no válidos.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (sueldo.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error - El sueldo no puede estar vacío.", "Gestión de Empleados", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    
}
