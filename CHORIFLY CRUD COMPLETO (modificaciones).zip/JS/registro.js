
document.getElementById("registrarse").addEventListener("click", async function() {

    let email = document.getElementById("emailRegistro").value.trim();
    let usuario = document.getElementById("usuarioRegistro").value.trim();
    let contra = document.getElementById("contraRegistro").value;
    let repetirContra = document.getElementById("repetirContraRegistro").value;
    let pregunta = document.getElementById("preguntaSeguridad").value;
    let respuesta = document.getElementById("respuestaSeguridad").value.trim();
    let mensaje = document.getElementById("mensajeRegistro");

    if (!email || !usuario || !contra || !repetirContra || !pregunta || !respuesta) {
        mensaje.textContent = "Completá todos los campos.";
        return;
    }

    if (contra !== repetirContra) {
        mensaje.textContent = "Las contraseñas no coinciden.";
        return;
    }

    mensaje.textContent = "Verificando los datos...";
    mensaje.style.color = "black";

    try {
        let respuestaServidor = await fetch(
            "/verificarUsuario?usuario=" + encodeURIComponent(usuario) +
            "&email=" + encodeURIComponent(email)
        );

        let resultado = (await respuestaServidor.text()).trim();

        if (!respuestaServidor.ok) {
            mensaje.textContent = "Error al verificar los datos: " + resultado;
            mensaje.style.color = "red";
            return;
        }

        if (resultado === "true") {
            mensaje.textContent = "Ese usuario o correo ya está registrado.";
            mensaje.style.color = "red";
        } else if (resultado === "false") {
            mensaje.textContent = "Los datos están disponibles. Podemos continuar con el registro.";
            mensaje.style.color = "green";
        } else {
            mensaje.textContent = "El servidor devolvió una respuesta inesperada.";
            mensaje.style.color = "red";
        }

    } catch (error) {
        mensaje.textContent = "No se pudo conectar con el servidor Java.";
        mensaje.style.color = "red";
        console.error(error);
    }
});
