
document.getElementById("formularioVuelo").addEventListener("submit", async function (evento) {
    evento.preventDefault();

    const id = document.getElementById("idVuelo").value;

    const datos = new URLSearchParams({
        avion: document.getElementById("avion").value.trim(),
        origen: document.getElementById("origen").value,
        destino: document.getElementById("destino").value,
        salida: document.getElementById("salida").value,
        llegada: document.getElementById("llegada").value,
        estado: document.getElementById("estado").value
    });

    const editando = id !== "";

    if (editando) {
        datos.append("id", id);
    }

    try {
        const respuesta = await fetch(
            editando ? "/editarVuelo" : "/crearVuelo",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: datos.toString()
            }
        );

        const mensaje = await respuesta.text();

        if (!respuesta.ok) {
            alert("Error: " + mensaje);
            return;
        }

        alert(mensaje);
        limpiarFormulario();
        cargarVuelos();

    } catch (error) {
        alert("No se pudo conectar con el servidor.");
        console.error(error);
    }
});

async function cargarVuelos(id = "") {
    const lista = document.getElementById("listaVuelos");

    try {
        let url = "/listarVuelos";

        if (id !== "") {
            url += "?id=" + encodeURIComponent(id);
        }

        const respuesta = await fetch(url);

        if (!respuesta.ok) {
            throw new Error("Error al consultar los vuelos.");
        }

        const vuelos = await respuesta.json();
        lista.innerHTML = "";

        if (vuelos.length === 0) {
            lista.innerHTML = `
                <tr>
                    <td colspan="8">No se encontraron vuelos.</td>
                </tr>
            `;
            return;
        }

        vuelos.forEach(vuelo => {
            const fila = document.createElement("tr");

            fila.innerHTML = `
                <td>${vuelo.id}</td>
                <td>${vuelo.modelo} (${vuelo.avion})</td>
                <td>${vuelo.origen}</td>
                <td>${vuelo.destino}</td>
                <td>${vuelo.salida}</td>
                <td>${vuelo.llegada}</td>
                <td>${vuelo.estado}</td>
                <td>
                    <div class="accionesVuelo">
                        <button type="button" class="botonEditar"
                            onclick="editarVuelo(${vuelo.id})">
                            Editar
                        </button>
                        <button type="button" class="botonEliminar"
                            onclick="eliminarVuelo(${vuelo.id})">
                            Eliminar
                        </button>
                    </div>
                </td>
            `;

            lista.appendChild(fila);
        });

    } catch (error) {
        alert("No se pudieron cargar los vuelos.");
        console.error(error);
    }
}

async function editarVuelo(id) {
    try {
        const respuesta = await fetch(
            "/listarVuelos?id=" + encodeURIComponent(id)
        );

        if (!respuesta.ok) {
            throw new Error("No se pudo consultar el vuelo.");
        }

        const vuelos = await respuesta.json();

        if (vuelos.length === 0) {
            alert("No se encontró el vuelo.");
            return;
        }

        const vuelo = vuelos[0];

        document.getElementById("idVuelo").value = vuelo.id;
        document.getElementById("avion").value = vuelo.avion;
        document.getElementById("origen").value = vuelo.origenId;
        document.getElementById("destino").value = vuelo.destinoId;
        document.getElementById("salida").value =
            vuelo.salida.replace(" ", "T").slice(0, 16);
        document.getElementById("llegada").value =
            vuelo.llegada.replace(" ", "T").slice(0, 16);
        document.getElementById("estado").value = vuelo.estado;

        document.getElementById("guardarVuelo").textContent =
            "Guardar cambios";

        document.querySelector(".seccionReservas").scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    } catch (error) {
        alert("No se pudo cargar el vuelo para editar.");
        console.error(error);
    }
}

async function eliminarVuelo(id) {
    if (!confirm("¿Seguro que querés eliminar el vuelo " + id + "?")) {
        return;
    }

    try {
        const datos = new URLSearchParams({ id: String(id) });

        const respuesta = await fetch("/eliminarVuelo", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: datos.toString()
        });

        const mensaje = await respuesta.text();

        if (!respuesta.ok) {
            alert("Error: " + mensaje);
            return;
        }

        alert(mensaje);

        const idBuscado =
            document.getElementById("buscarIdVuelo").value.trim();

        cargarVuelos(idBuscado);

    } catch (error) {
        alert("No se pudo conectar con el servidor.");
        console.error(error);
    }
}

function limpiarFormulario() {
    document.getElementById("formularioVuelo").reset();
    document.getElementById("idVuelo").value = "";
    document.getElementById("guardarVuelo").textContent = "Crear vuelo";
}

document.getElementById("cancelarEdicion").addEventListener("click", function () {
    limpiarFormulario();
});

document.getElementById("botonBuscarVuelo").addEventListener("click", function () {
    const id = document.getElementById("buscarIdVuelo").value.trim();

    if (id === "") {
        alert("Ingresá el ID del vuelo que querés buscar.");
        return;
    }

    cargarVuelos(id);
});

document.getElementById("mostrarTodosVuelos").addEventListener("click", function () {
    document.getElementById("buscarIdVuelo").value = "";
    cargarVuelos();
});

document.addEventListener("DOMContentLoaded", function () {
    cargarVuelos();
});
