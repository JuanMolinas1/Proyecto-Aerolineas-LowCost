
document.getElementById("registrarse").addEventListener("click", async function() {

    let email = document.getElementById("emailRegistro").value.trim();
    let usuario = document.getElementById("usuarioRegistro").value.trim();
    let contra = document.getElementById("contraRegistro").value;
    let repetirContra = document.getElementById("repetirContraRegistro").value;
    let pregunta = document.getElementById("preguntaSeguridad").value;
    let respuesta = document.getElementById("respuestaSeguridad").value.trim();
    let mensaje = document.getElementById("mensajeRegistro");

    if (email === "" || usuario === "" || contra === "" ||
        repetirContra === "" || pregunta === "" || respuesta === "") {

        mensaje.textContent = "Completá todos los campos.";
        return;
    }

    if (contra !== repetirContra) {
        mensaje.textContent = "Las contraseñas no coinciden.";
        return;
    }

    mensaje.textContent = "Verificando los datos...";

    try {
        let respuestaServidor = await fetch(
            "/verificarUsuario?usuario=" + encodeURIComponent(usuario) +
            "&email=" + encodeURIComponent(email)
        );

        if (!respuestaServidor.ok) {
            mensaje.textContent = "No se pudieron verificar los datos.";
            return;
        }

        let resultado = (await respuestaServidor.text()).trim();

        if (resultado === "true") {
            mensaje.textContent = "Ese nombre de usuario o email ya está registrado.";
        } else if (resultado === "false") {
            mensaje.textContent = "Datos validados. Ya podemos preparar el registro.";
        } else {
            mensaje.textContent = "El servidor devolvió una respuesta inesperada.";
        }

    } catch (error) {
        mensaje.textContent = "No se pudo conectar con el servidor.";
        console.error(error);
    }
});
