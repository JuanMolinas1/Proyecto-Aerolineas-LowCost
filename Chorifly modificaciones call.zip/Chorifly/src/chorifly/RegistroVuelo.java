
package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class RegistroVuelo {

    public static boolean crearVuelo(
            String avion, int origen, int destino,
            String salida, String llegada, String estado)
            throws SQLException {

        LocalDateTime fechaSalida = LocalDateTime.parse(salida);
        LocalDateTime fechaLlegada = LocalDateTime.parse(llegada);

        if (!fechaLlegada.isAfter(fechaSalida)) {
            throw new SQLException(
                    "La llegada debe ser posterior a la salida.");
        }

        Timestamp inicio = Timestamp.valueOf(fechaSalida);
        Timestamp fin = Timestamp.valueOf(fechaLlegada);

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new SQLException("No se pudo conectar con MySQL.");
        }

        validarDisponibilidad(conexion, 0, avion, inicio, fin);

        String sql =
                "INSERT INTO Vuelo "
                + "(avion_id, origen_id, destino_id, "
                + "fecha_hora_salida, fecha_hora_llegada, estado) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement consulta =
                conexion.prepareStatement(sql)) {

            consulta.setString(1, avion);
            consulta.setInt(2, origen);
            consulta.setInt(3, destino);
            consulta.setTimestamp(4, inicio);
            consulta.setTimestamp(5, fin);
            consulta.setString(6, estado);

            return consulta.executeUpdate() == 1;
        }
    }

    public static boolean editarVuelo(
            int id, String avion, int origen, int destino,
            String salida, String llegada, String estado)
            throws SQLException {

        LocalDateTime fechaSalida = LocalDateTime.parse(salida);
        LocalDateTime fechaLlegada = LocalDateTime.parse(llegada);

        if (!fechaLlegada.isAfter(fechaSalida)) {
            throw new SQLException(
                    "La llegada debe ser posterior a la salida.");
        }

        Timestamp inicio = Timestamp.valueOf(fechaSalida);
        Timestamp fin = Timestamp.valueOf(fechaLlegada);

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new SQLException("No se pudo conectar con MySQL.");
        }

        validarDisponibilidad(conexion, id, avion, inicio, fin);

        String sql =
                "UPDATE Vuelo SET avion_id = ?, origen_id = ?, "
                + "destino_id = ?, fecha_hora_salida = ?, "
                + "fecha_hora_llegada = ?, estado = ? "
                + "WHERE IDVuelo = ?";

        try (PreparedStatement consulta =
                conexion.prepareStatement(sql)) {

            consulta.setString(1, avion);
            consulta.setInt(2, origen);
            consulta.setInt(3, destino);
            consulta.setTimestamp(4, inicio);
            consulta.setTimestamp(5, fin);
            consulta.setString(6, estado);
            consulta.setInt(7, id);

            return consulta.executeUpdate() == 1;
        }
    }

    private static void validarDisponibilidad(
            Connection conexion, int idExcluir, String avion,
            Timestamp inicio, Timestamp fin) throws SQLException {

        String estadosActivos =
                "'Volando', 'Programado', 'A Tiempo', 'Atrasado'";

      String sqlAvion = "{CALL Contar_Vuelos_Activos_Avion(?, ?, ?, ?)}";

        try (PreparedStatement consulta =
                conexion.prepareStatement(sqlAvion)) {

            consulta.setInt(1, idExcluir);
            consulta.setString(2, avion);
            consulta.setTimestamp(3, fin);
            consulta.setTimestamp(4, inicio);

            try (ResultSet resultado = consulta.executeQuery()) {
                resultado.next();

                if (resultado.getInt(1) > 0) {
                    throw new SQLException(
                            "El avión ya está asignado a otro vuelo "
                            + "durante ese horario.");
                }
            }
        }

        LocalDateTime fechaSalida = inicio.toLocalDateTime();
        LocalDateTime fechaLlegada = fin.toLocalDateTime();

        String sqlVuelos = "{CALL Obtener_Horarios_Vuelos_Activos(?, ?, ?)}";

        List<LocalDateTime[]> intervalos = new ArrayList<>();

        intervalos.add(new LocalDateTime[]{
            fechaSalida, fechaLlegada
        });

        try (PreparedStatement consulta =
                conexion.prepareStatement(sqlVuelos)) {

            consulta.setInt(1, idExcluir);
            consulta.setTimestamp(2, fin);
            consulta.setTimestamp(3, inicio);

            try (ResultSet resultado = consulta.executeQuery()) {
                while (resultado.next()) {

                    LocalDateTime salidaExistente =
                            resultado.getTimestamp(1).toLocalDateTime();

                    LocalDateTime llegadaExistente =
                            resultado.getTimestamp(2).toLocalDateTime();

                    if (salidaExistente.isBefore(fechaSalida)) {
                        salidaExistente = fechaSalida;
                    }

                    if (llegadaExistente.isAfter(fechaLlegada)) {
                        llegadaExistente = fechaLlegada;
                    }

                    intervalos.add(new LocalDateTime[]{
                        salidaExistente, llegadaExistente
                    });
                }
            }
        }

        class Evento {
            private final LocalDateTime momento;
            private final int cambio;

            Evento(LocalDateTime momento, int cambio) {
                this.momento = momento;
                this.cambio = cambio;
            }
        }

        List<Evento> eventos = new ArrayList<>();

        for (LocalDateTime[] intervalo : intervalos) {
            eventos.add(new Evento(intervalo[0], 1));
            eventos.add(new Evento(intervalo[1], -1));
        }

        eventos.sort(new Comparator<Evento>() {
            @Override
            public int compare(Evento a, Evento b) {
                int comparacion = a.momento.compareTo(b.momento);

                if (comparacion != 0) {
                    return comparacion;
                }

                return Integer.compare(a.cambio, b.cambio);
            }
        });

        int simultaneos = 0;

        for (Evento evento : eventos) {
            simultaneos += evento.cambio;

            if (simultaneos > 4) {
                throw new SQLException(
                        "No se pueden superar los 4 vuelos simultáneos.");
            }
        }
    }

    public static boolean eliminarVuelo(int id)
            throws SQLException {

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new SQLException("No se pudo conectar con MySQL.");
        }

        String sql = "DELETE FROM Vuelo WHERE IDVuelo = ?";

        try (PreparedStatement consulta =
                conexion.prepareStatement(sql)) {

            consulta.setInt(1, id);

            return consulta.executeUpdate() == 1;
        }
    }

    public static String listarVuelos(String idBuscado)
            throws SQLException {

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new SQLException("No se pudo conectar con MySQL.");
        }

        String sql = "{CALL Obtener_Detalle_Vuelos()}";

        boolean buscarPorId =
                idBuscado != null && !idBuscado.trim().isEmpty();

        if (buscarPorId) {
            sql += " WHERE V.IDVuelo = ?";
        }

        sql += " ORDER BY V.IDVuelo";

        StringBuilder json = new StringBuilder("[");
        boolean primero = true;

        try (PreparedStatement consulta =
                conexion.prepareStatement(sql)) {

            if (buscarPorId) {
                try {
                    consulta.setInt(
                            1, Integer.parseInt(idBuscado.trim()));
                } catch (NumberFormatException e) {
                    return "[]";
                }
            }

            try (ResultSet resultado = consulta.executeQuery()) {
                while (resultado.next()) {

                    if (!primero) {
                        json.append(",");
                    }

                    json.append("{")
                            .append("\"id\":").append(resultado.getInt("IDVuelo")).append(",")
                            .append("\"avion\":\"").append(escaparJSON(resultado.getString("avion_id"))).append("\",")
                            .append("\"modelo\":\"").append(escaparJSON(resultado.getString("modelo"))).append("\",")
                            .append("\"origenId\":").append(resultado.getInt("origen_id")).append(",")
                            .append("\"destinoId\":").append(resultado.getInt("destino_id")).append(",")
                            .append("\"origen\":\"").append(escaparJSON(resultado.getString("paisOrigen") + " - " + resultado.getString("origen"))).append("\",")
                            .append("\"destino\":\"").append(escaparJSON(resultado.getString("paisDestino") + " - " + resultado.getString("destino"))).append("\",")
                            .append("\"salida\":\"").append(escaparJSON(resultado.getString("fecha_hora_salida"))).append("\",")
                            .append("\"llegada\":\"").append(escaparJSON(resultado.getString("fecha_hora_llegada"))).append("\",")
                            .append("\"estado\":\"").append(escaparJSON(resultado.getString("estado"))).append("\"")
                            .append("}");

                    primero = false;
                }
            }
        }

        return json.append("]").toString();
    }

    private static String escaparJSON(String texto) {
        if (texto == null) {
            return "";
        }

        return texto.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
