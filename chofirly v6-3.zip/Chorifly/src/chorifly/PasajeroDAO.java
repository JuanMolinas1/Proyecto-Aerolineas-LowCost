package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class PasajeroDAO {
    public void insertarPasajero(Pasajero p) {
        String insert_sql = "INSERT INTO Pasajero (nombre_pasajero, apellido_pasajero, dni_pasajero, telefono, fecha_nacimiento, nro_pasaporte, pais_emision, vencimiento_pasaporte, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, p.getNombre());
            sentencia_sql.setString(2, p.getApellido());
            sentencia_sql.setString(3, p.getDni());
            sentencia_sql.setString(4, p.getTelefono());
            sentencia_sql.setObject(5, p.getFecha_nacimiento());
            sentencia_sql.setString(6, p.getNroPasaporte());
            sentencia_sql.setString(7, p.getPaisEmision());
            sentencia_sql.setObject(8, p.getFechaVencimientoPasaporte());
            sentencia_sql.setInt(9, p.getUsuario().getId_usuario());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Pasajero Guardado Exitosamente",
                    "Creación de Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Pasajero",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void listarPasajero(){
        String consulta_sql = "SELECT * FROM Pasajero";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Pasajero --"
                + "\nID Pasajero: " + resultado.getInt("IDPasajero")
                + "\nNombre: " + resultado.getString("nombre_pasajero")
                + "\nApellido: " + resultado.getString("apellido_pasajero")
                + "\nDNI: " + resultado.getString("dni_pasajero")
                + "\nTeléfono: " + resultado.getString("telefono")
                + "\nFecha de Nacimiento: " + resultado.getDate("fecha_nacimiento")
                + "\nNro. Pasaporte: " + resultado.getString("nro_pasaporte")
                + "\nPais de Emisión: " + resultado.getString("pais_emision")
                + "\nVencimiento Pasaporte: " + resultado.getDate("vencimiento_pasaporte")
                + "\nID Usuario Vinculado: " + resultado.getInt("usuario_id"),
                "Listado de Pasajeros",
                JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Pasajeros",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
