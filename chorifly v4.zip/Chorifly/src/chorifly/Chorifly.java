package chorifly;

public class Chorifly {

    public static void main(String[] args) {
        Aerolinea chorifly = new Aerolinea("Chorily Airlines");
    }
    
}
