package chorifly;

import javax.swing.JOptionPane;

public class Departamento {
    private String nombre;
    private boolean aereo;

    public Departamento(String nombre, boolean aereo) {
        this.nombre = nombre;
        this.aereo = aereo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isAereo() {
        return aereo;
    }

    public void setAereo(boolean aereo) {
        this.aereo = aereo;
    }
    
    public void mostrarDepartamento() {
        JOptionPane.showMessageDialog(null, "-- Mostrar : Departamento --"
                + "\nNombre: " + nombre
                + "\nTipo: " + (aereo ? "Aéreo" : "Terrestre"),
                //Segun el gran chat esto es un if que se puede usar en concatenación si aéreo es true imprime aereo y si es falso imprime terrestre
                "Información del Departamento",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
