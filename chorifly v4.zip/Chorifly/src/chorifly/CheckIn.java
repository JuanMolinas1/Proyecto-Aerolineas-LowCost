package chorifly;

public class CheckIn {
    private int id_checkin;
    private Persona pasajero;
    private Boleto boleto;
    private Vuelo vuelo;
    private Pago pago;
    private String puerta_embarque;

    public CheckIn(Persona pasajero, Boleto boleto, Vuelo vuelo, Pago pago, String puerta_embarque) {
        this.pasajero = pasajero;
        this.boleto = boleto;
        this.vuelo = vuelo;
        this.pago = pago;
        this.puerta_embarque = puerta_embarque;
    }

    public int getId_checkin() {
        return id_checkin;
    }

    public void setId_checkin(int id_checkin) {
        this.id_checkin = id_checkin;
    }

    public Persona getPasajero() {
        return pasajero;
    }

    public void setPasajero(Persona pasajero) {
        this.pasajero = pasajero;
    }

    public Boleto getBoleto() {
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public Pago getPago() {
        return pago;
    }

    public void setPago(Pago pago) {
        this.pago = pago;
    }

    public String getPuerta_embarque() {
        return puerta_embarque;
    }

    public void setPuerta_embarque(String puerta_embarque) {
        this.puerta_embarque = puerta_embarque;
    }
}
