package chorifly;

public class Utilidades {
    public String borrarTextoExtraAeropuerto(String nombreAeropuerto) {
        return nombreAeropuerto.replace("Aeropuerto Internacional", "");
    }
    
    public String borrarDesdeEspacio(String texto) {
        int indice = texto.indexOf(" ");

        if (indice != -1) {
            texto = texto.substring(0, indice);
        }

        return texto;
    }
}
