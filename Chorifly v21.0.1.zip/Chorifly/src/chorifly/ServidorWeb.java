package chorifly;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ServidorWeb {

    private static class DatosSesion {
        private final int idUsuario;
        private final boolean empleado;

        public DatosSesion(int idUsuario, boolean empleado) {
            this.idUsuario = idUsuario;
            this.empleado = empleado;
        }

        public int getIdUsuario() {
            return idUsuario;
        }

        public boolean esEmpleado() {
            return empleado;
        }
    }

    private static final Map<String, DatosSesion> sesiones =
            new ConcurrentHashMap<>();

    public static void iniciar() throws IOException {

        HttpServer servidor = HttpServer.create(
                new InetSocketAddress(8080), 0);

        servidor.createContext("/crearVuelo", intercambio -> {

            if (!esEmpleado(intercambio)) {
                enviarRespuesta(intercambio, 403,
                        "Acceso denegado. Solo los empleados pueden realizar esta operación.");
                return;
            }

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);

                String avion = datos.get("avion");
                String origenTexto = datos.get("origen");
                String destinoTexto = datos.get("destino");
                String salida = datos.get("salida");
                String llegada = datos.get("llegada");
                String estado = datos.get("estado");

                if (faltaDato(avion) || faltaDato(origenTexto)
                        || faltaDato(destinoTexto) || faltaDato(salida)
                        || faltaDato(llegada) || faltaDato(estado)) {

                    enviarRespuesta(intercambio, 400,
                            "Completá todos los campos.");
                    return;
                }

                if (avion.length() > 30
                        || !origenTexto.matches("\\d+")
                        || !destinoTexto.matches("\\d+")) {

                    enviarRespuesta(intercambio, 400,
                            "Revisá el avión y los ID de los aeropuertos.");
                    return;
                }

                int origen = Integer.parseInt(origenTexto);
                int destino = Integer.parseInt(destinoTexto);

                if (origen < 1 || destino < 1 || origen == destino) {
                    enviarRespuesta(intercambio, 400,
                            "Los aeropuertos seleccionados no son válidos.");
                    return;
                }

                LocalDateTime fechaSalida = LocalDateTime.parse(salida);
                LocalDateTime fechaLlegada = LocalDateTime.parse(llegada);

                if (!fechaLlegada.isAfter(fechaSalida)) {
                    enviarRespuesta(intercambio, 400,
                            "La llegada debe ser posterior a la salida.");
                    return;
                }

                if (!estadoValido(estado)) {
                    enviarRespuesta(intercambio, 400,
                            "El estado seleccionado no es válido.");
                    return;
                }

                boolean creado = RegistroVuelo.crearVuelo(
                        avion, origen, destino, salida, llegada, estado);

                if (creado) {
                    enviarRespuesta(intercambio, 200,
                            "Vuelo creado correctamente.");
                } else {
                    enviarRespuesta(intercambio, 500,
                            "No se pudo crear el vuelo.");
                }

            } catch (NumberFormatException
                    | java.time.DateTimeException error) {

                enviarRespuesta(intercambio, 400,
                        "Revisá los números y las fechas ingresadas.");

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al guardar el vuelo en MySQL: "
                        + error.getMessage());

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al crear el vuelo.");
            }
        });

        servidor.createContext("/listarVuelos", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("GET")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere GET.");
                return;
            }

            try {
                String consulta =
                        intercambio.getRequestURI().getRawQuery();

                Map<String, String> parametros =
                        consulta == null
                        ? new HashMap<>()
                        : leerParametrosTexto(consulta);

                String idBuscado = parametros.get("id");

                if (idBuscado != null && !idBuscado.matches("\\d+")) {
                    enviarRespuesta(intercambio, 400,
                            "El ID debe ser un número.");
                    return;
                }

                String vuelos = RegistroVuelo.listarVuelos(idBuscado);
                enviarRespuestaJSON(intercambio, 200, vuelos);

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al consultar los vuelos.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al consultar los vuelos.");
            }
        });

        servidor.createContext("/listarAsientos", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("GET")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere GET.");
                return;
            }

            try {
                String consulta =
                        intercambio.getRequestURI().getRawQuery();

                Map<String, String> parametros =
                        consulta == null
                        ? new HashMap<>()
                        : leerParametrosTexto(consulta);

                String idTexto = parametros.get("idVuelo");

                if (faltaDato(idTexto) || !idTexto.matches("\\d+")) {
                    enviarRespuesta(intercambio, 400,
                            "El ID del vuelo no es válido.");
                    return;
                }

                int idVuelo = Integer.parseInt(idTexto);

                if (idVuelo < 1) {
                    enviarRespuesta(intercambio, 400,
                            "El ID del vuelo debe ser positivo.");
                    return;
                }

                String asientos =
                        RegistroBoleto.listarAsientos(idVuelo);

                enviarRespuestaJSON(intercambio, 200, asientos);

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al consultar los asientos.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al consultar los asientos.");
            }
        });

        servidor.createContext("/editarVuelo", intercambio -> {

            if (!esEmpleado(intercambio)) {
                enviarRespuesta(intercambio, 403,
                        "Acceso denegado. Solo los empleados pueden realizar esta operación.");
                return;
            }

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);

                String idTexto = datos.get("id");
                String avion = datos.get("avion");
                String origenTexto = datos.get("origen");
                String destinoTexto = datos.get("destino");
                String salida = datos.get("salida");
                String llegada = datos.get("llegada");
                String estado = datos.get("estado");

                if (faltaDato(idTexto) || faltaDato(avion)
                        || faltaDato(origenTexto)
                        || faltaDato(destinoTexto)
                        || faltaDato(salida) || faltaDato(llegada)
                        || faltaDato(estado)) {

                    enviarRespuesta(intercambio, 400,
                            "Completá todos los campos.");
                    return;
                }

                if (!idTexto.matches("\\d+")
                        || !origenTexto.matches("\\d+")
                        || !destinoTexto.matches("\\d+")
                        || avion.length() > 30) {

                    enviarRespuesta(intercambio, 400,
                            "Revisá el ID, el avión y los aeropuertos.");
                    return;
                }

                int id = Integer.parseInt(idTexto);
                int origen = Integer.parseInt(origenTexto);
                int destino = Integer.parseInt(destinoTexto);

                if (id < 1 || origen < 1 || destino < 1
                        || origen == destino) {

                    enviarRespuesta(intercambio, 400,
                            "Los datos del vuelo no son válidos.");
                    return;
                }

                LocalDateTime fechaSalida = LocalDateTime.parse(salida);
                LocalDateTime fechaLlegada = LocalDateTime.parse(llegada);

                if (!fechaLlegada.isAfter(fechaSalida)) {
                    enviarRespuesta(intercambio, 400,
                            "La llegada debe ser posterior a la salida.");
                    return;
                }

                if (!estadoValido(estado)) {
                    enviarRespuesta(intercambio, 400,
                            "El estado seleccionado no es válido.");
                    return;
                }

                boolean actualizado = RegistroVuelo.editarVuelo(
                        id, avion, origen, destino, salida, llegada, estado);

                if (actualizado) {
                    enviarRespuesta(intercambio, 200,
                            "Vuelo actualizado correctamente.");
                } else {
                    enviarRespuesta(intercambio, 404,
                            "No se encontró el vuelo.");
                }

            } catch (NumberFormatException
                    | java.time.DateTimeException error) {

                enviarRespuesta(intercambio, 400,
                        "Revisá los ID y las fechas ingresadas.");

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al actualizar el vuelo: "
                        + error.getMessage());

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "No se pudo actualizar el vuelo.");
            }
        });

        servidor.createContext("/eliminarVuelo", intercambio -> {

            if (!esEmpleado(intercambio)) {
                enviarRespuesta(intercambio, 403,
                        "Acceso denegado. Solo los empleados pueden realizar esta operación.");
                return;
            }

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);
                String idTexto = datos.get("id");

                if (faltaDato(idTexto) || !idTexto.matches("\\d+")) {
                    enviarRespuesta(intercambio, 400,
                            "El ID del vuelo debe ser un número.");
                    return;
                }

                int id = Integer.parseInt(idTexto);

                if (id < 1) {
                    enviarRespuesta(intercambio, 400,
                            "El ID debe ser positivo.");
                    return;
                }

                boolean eliminado = RegistroVuelo.eliminarVuelo(id);

                if (eliminado) {
                    enviarRespuesta(intercambio, 200,
                            "Vuelo eliminado correctamente.");
                } else {
                    enviarRespuesta(intercambio, 404,
                            "No se encontró el vuelo.");
                }

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "No se pudo eliminar el vuelo. Puede tener registros asociados.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al eliminar el vuelo.");
            }
        });

        servidor.createContext("/verificarUsuario", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("GET")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere GET.");
                return;
            }

            try {
                String consulta =
                        intercambio.getRequestURI().getRawQuery();

                Map<String, String> parametros =
                        consulta == null
                        ? new HashMap<>()
                        : leerParametrosTexto(consulta);

                String usuario = parametros.get("usuario");
                String email = parametros.get("email");

                if (faltaDato(usuario) || faltaDato(email)) {
                    enviarRespuesta(intercambio, 400,
                            "Faltan datos para verificar.");
                    return;
                }

                boolean existe =
                        RegistroUsuario.existeUsuario(usuario, email);

                enviarRespuesta(intercambio, 200,
                        String.valueOf(existe));

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al verificar el usuario.");
            }
        });

        servidor.createContext("/registrarUsuario", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);

                String usuario = datos.get("usuario");
                String email = datos.get("email");
                String contrasena = datos.get("contraseña");
                String repetirContrasena = datos.get("repetirContraseña");
                String pregunta = datos.get("preguntaSeguridad");
                String respuesta = datos.get("respuestaSeguridad");

                String nombre = datos.get("nombre");
                String apellido = datos.get("apellido");
                String dni = datos.get("dni");
                String telefono = datos.get("telefono");
                String fechaNacimiento = datos.get("fechaNacimiento");
                String pasaporte = datos.get("pasaporte");
                String paisEmision = datos.get("paisEmision");
                String vencimientoPasaporte = datos.get("vencimientoPasaporte");

                if (faltaDato(usuario) || faltaDato(email)
                        || faltaDato(contrasena) || faltaDato(repetirContrasena)
                        || faltaDato(pregunta) || faltaDato(respuesta)
                        || faltaDato(nombre) || faltaDato(apellido)
                        || faltaDato(dni) || faltaDato(telefono)
                        || faltaDato(fechaNacimiento) || faltaDato(pasaporte)
                        || faltaDato(paisEmision) || faltaDato(vencimientoPasaporte)) {

                    enviarRespuesta(intercambio, 400,
                            "Completá todos los campos.");
                    return;
                }

                if (!contrasena.equals(repetirContrasena)) {
                    enviarRespuesta(intercambio, 400,
                            "Las contraseñas no coinciden.");
                    return;
                }

                if (usuario.length() > 30 || email.length() > 40
                        || contrasena.length() > 30 || pregunta.length() > 100
                        || respuesta.length() > 100 || nombre.length() > 50
                        || apellido.length() > 50 || dni.length() > 15
                        || telefono.length() > 20 || pasaporte.length() > 20
                        || paisEmision.length() != 3) {

                    enviarRespuesta(intercambio, 400,
                            "Uno o más campos superan el límite permitido.");
                    return;
                }

                java.time.LocalDate nacimiento =
                        java.time.LocalDate.parse(fechaNacimiento);

                java.time.LocalDate vencimiento =
                        java.time.LocalDate.parse(vencimientoPasaporte);

                if (!nacimiento.isBefore(java.time.LocalDate.now())) {
                    enviarRespuesta(intercambio, 400,
                            "La fecha de nacimiento debe ser anterior a hoy.");
                    return;
                }

                if (!vencimiento.isAfter(java.time.LocalDate.now())) {
                    enviarRespuesta(intercambio, 400,
                            "El pasaporte debe tener una fecha de vencimiento futura.");
                    return;
                }

                if (RegistroUsuario.existeUsuario(usuario, email)) {
                    enviarRespuesta(intercambio, 409,
                            "Ese nombre de usuario o correo ya está registrado.");
                    return;
                }

                RegistroUsuario.registrarPasajero(
                        usuario, email, contrasena, pregunta, respuesta,
                        nombre, apellido, dni, telefono, fechaNacimiento,
                        pasaporte, paisEmision.toUpperCase(),
                        vencimientoPasaporte
                );

                enviarRespuesta(intercambio, 200,
                        "Cuenta creada correctamente. Ya podés iniciar sesión.");

            } catch (java.time.DateTimeException error) {

                enviarRespuesta(intercambio, 400,
                        "Revisá las fechas ingresadas.");

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "No se pudo completar el registro. Verificá los datos.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al registrar la cuenta.");
            }
        });

        servidor.createContext("/iniciarSesion", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);

                String usuario = datos.get("usuario");
                String contrasena = datos.get("contraseña");

                if (faltaDato(usuario) || faltaDato(contrasena)) {
                    enviarRespuesta(intercambio, 400,
                            "Completá el usuario y la contraseña.");
                    return;
                }

                String consulta =
                        "SELECT IDUsuario, privilegios_empleado FROM Usuario "
                        + "WHERE nombre_usuario = ? "
                        + "AND contraseña_usuario = ?";

                try (Connection conexion = ConexionSQL.conectar()) {

                    if (conexion == null) {
                        enviarRespuesta(intercambio, 500,
                                "No se pudo conectar con MySQL.");
                        return;
                    }

                    try (PreparedStatement sentencia =
                            conexion.prepareStatement(consulta)) {

                        sentencia.setString(1, usuario);
                        sentencia.setString(2, contrasena);

                        try (ResultSet resultado = sentencia.executeQuery()) {

                            if (!resultado.next()) {
                                enviarRespuesta(intercambio, 200, "incorrecto");
                                return;
                            }

                            int idUsuario = resultado.getInt("IDUsuario");

                            boolean empleado =
                                    resultado.getBoolean("privilegios_empleado");

                            String idSesion = UUID.randomUUID().toString();

                            sesiones.put(
                                    idSesion,
                                    new DatosSesion(idUsuario, empleado)
                            );

                            intercambio.getResponseHeaders().add(
                                    "Set-Cookie",
                                    "CHORIFLY_SESSION=" + idSesion
                                    + "; Path=/; HttpOnly; SameSite=Lax; Max-Age=1800");

                            enviarRespuesta(intercambio, 200,
                                    empleado ? "empleado" : "pasajero");
                        }
                    }
                }

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Error al consultar la base de datos.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al iniciar sesión.");
            }
        });

        servidor.createContext("/obtenerCorreoSesion", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("GET")) {
                enviarRespuestaJSON(intercambio, 405,
                        "{\"estado\":\"metodo_no_permitido\"}");
                return;
            }

            int idUsuario = obtenerIdUsuario(intercambio);

            if (idUsuario < 1) {
                enviarRespuestaJSON(intercambio, 401,
                        "{\"estado\":\"no_autorizado\"}");
                return;
            }

            String sql =
                    "SELECT email FROM Usuario WHERE IDUsuario = ?";

            try (Connection conexion = ConexionSQL.conectar()) {

                if (conexion == null) {
                    enviarRespuestaJSON(intercambio, 500,
                            "{\"estado\":\"error_conexion\"}");
                    return;
                }

                try (PreparedStatement consulta =
                        conexion.prepareStatement(sql)) {

                    consulta.setInt(1, idUsuario);

                    try (ResultSet resultado = consulta.executeQuery()) {

                        if (!resultado.next()) {
                            enviarRespuestaJSON(intercambio, 404,
                                    "{\"estado\":\"no_encontrado\"}");
                            return;
                        }

                        String correo = resultado.getString("email");

                        String json =
                                "{\"estado\":\"ok\",\"correo\":\""
                                + correo.replace("\\", "\\\\")
                                        .replace("\"", "\\\"")
                                + "\"}";

                        enviarRespuestaJSON(intercambio, 200, json);
                    }
                }

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuestaJSON(intercambio, 500,
                        "{\"estado\":\"error\"}");
            }
        });

        servidor.createContext("/comprarBoleto", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            int idUsuario = obtenerIdUsuario(intercambio);

            System.out.println("ID USUARIO RECIBIDO PARA COMPRAR: " + idUsuario);

            if (idUsuario < 1) {
                enviarRespuesta(intercambio, 401,
                        "Tenés que iniciar sesión como pasajero para comprar.");
                return;
            }

            try {
                Map<String, String> datos = leerParametros(intercambio);

                String vueloTexto = datos.get("vueloId");
                String asiento = datos.get("asiento");
                String nombre = datos.get("nombre");
                String apellido = datos.get("apellido");
                String documento = datos.get("documento");
                String correo = datos.get("correo");
                String serviciosTexto = datos.get("servicios");

                if (faltaDato(vueloTexto) || faltaDato(asiento)
                        || faltaDato(nombre) || faltaDato(apellido)
                        || faltaDato(documento) || faltaDato(correo)) {

                    enviarRespuesta(intercambio, 400,
                            "Completá todos los datos obligatorios.");
                    return;
                }

                if (!vueloTexto.matches("\\d+")) {
                    enviarRespuesta(intercambio, 400,
                            "El vuelo seleccionado no es válido.");
                    return;
                }

                int idVuelo = Integer.parseInt(vueloTexto);

                if (idVuelo < 1) {
                    enviarRespuesta(intercambio, 400,
                            "Seleccioná un vuelo válido.");
                    return;
                }

                List<Integer> servicios = new ArrayList<>();

                if (!faltaDato(serviciosTexto)) {

                    for (String id : serviciosTexto.split(",")) {

                        if (!id.trim().matches("\\d+")) {
                            enviarRespuesta(intercambio, 400,
                                    "La selección de servicios no es válida.");
                            return;
                        }

                        servicios.add(Integer.parseInt(id.trim()));
                    }
                }

                int idBoleto = RegistroBoleto.comprarBoleto(
                        idUsuario,
                        idVuelo,
                        asiento,
                        nombre,
                        apellido,
                        documento,
                        correo,
                        servicios
                );

                enviarRespuestaJSON(
                        intercambio,
                        200,
                        "{\"estado\":\"ok\",\"idBoleto\":"
                        + idBoleto + ",\"mensaje\":\"Boleto creado correctamente.\"}"
                );

            } catch (SQLException error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 400,
                        error.getMessage());

            } catch (NumberFormatException error) {

                enviarRespuesta(intercambio, 400,
                        "Los datos numéricos no son válidos.");

            } catch (Exception error) {

                error.printStackTrace();
                enviarRespuesta(intercambio, 500,
                        "Ocurrió un error al registrar el boleto.");
            }
        });

        servidor.createContext("/cerrarSesion", intercambio -> {

            if (!intercambio.getRequestMethod().equalsIgnoreCase("POST")) {
                enviarRespuesta(intercambio, 405,
                        "Este endpoint requiere POST.");
                return;
            }

            String idSesion = obtenerIdSesion(intercambio);

            if (idSesion != null) {
                sesiones.remove(idSesion);
            }

            intercambio.getResponseHeaders().add(
                    "Set-Cookie",
                    "CHORIFLY_SESSION=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0");

            intercambio.getResponseHeaders().set(
                    "Location", "/InicioSesion.html");

            intercambio.sendResponseHeaders(303, -1);
            intercambio.close();
        });

        servidor.createContext("/", intercambio -> {

            String ruta = intercambio.getRequestURI().getPath();

            if (ruta.equals("/")) {
                ruta = "/Chorifly.html";
            }

            if (ruta.equals("/Chorifly(EMPLEADO).html")
                    && !esEmpleado(intercambio)) {

                intercambio.getResponseHeaders().set(
                        "Location", "/InicioSesion.html");

                intercambio.sendResponseHeaders(303, -1);
                intercambio.close();
                return;
            }

            Path archivo;

            if (ruta.endsWith(".html")) {
                archivo = Paths.get("HTMLs", ruta.substring(1));

            } else if (ruta.startsWith("/CCSs/")) {
                archivo = Paths.get(
                        "CCSs", ruta.substring("/CCSs/".length()));

            } else if (ruta.startsWith("/JS/")) {
                archivo = Paths.get(
                        "JS", ruta.substring("/JS/".length()));

            } else if (ruta.startsWith("/ImagenesChorifly/")) {
                archivo = Paths.get(
                        "ImagenesChorifly",
                        ruta.substring("/ImagenesChorifly/".length()));

            } else {
                archivo = Paths.get("archivo-inexistente");
            }

            if (!Files.exists(archivo) || !Files.isRegularFile(archivo)) {
                enviarRespuesta(intercambio, 404,
                        "No se encontró el archivo: " + ruta);
                return;
            }

            String tipo = Files.probeContentType(archivo);

            if (ruta.endsWith(".html")) {
                tipo = "text/html; charset=UTF-8";
            } else if (ruta.endsWith(".css")) {
                tipo = "text/css; charset=UTF-8";
            } else if (ruta.endsWith(".js")) {
                tipo = "text/javascript; charset=UTF-8";
            } else if (ruta.endsWith(".png")) {
                tipo = "image/png";
            } else if (ruta.endsWith(".jpg") || ruta.endsWith(".jpeg")) {
                tipo = "image/jpeg";
            } else if (ruta.endsWith(".webp")) {
                tipo = "image/webp";
            } else if (ruta.endsWith(".svg")) {
                tipo = "image/svg+xml";
            } else if (ruta.endsWith(".ico")) {
                tipo = "image/x-icon";
            }

            if (tipo == null) {
                tipo = "application/octet-stream";
            }

            try {
                byte[] contenido = Files.readAllBytes(archivo);

                intercambio.getResponseHeaders().set("Content-Type", tipo);
                intercambio.sendResponseHeaders(200, contenido.length);
                intercambio.getResponseBody().write(contenido);
                intercambio.close();

            } catch (IOException error) {

                error.printStackTrace();

                try {
                    enviarRespuesta(intercambio, 500,
                            "No se pudo leer el archivo solicitado.");
                } catch (IOException ignorado) {
                }
            }
        });

        servidor.start();

        System.out.println(
                "Servidor iniciado en http://localhost:8080");
    }

    private static Map<String, String> leerParametros(
        HttpExchange intercambio) throws IOException {

        StringBuilder sb = new StringBuilder();
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(intercambio.getRequestBody(), StandardCharsets.UTF_8))) {
            
            String linea;
            while ((linea = reader.readLine()) != null) {
                sb.append(linea);
            }
        }

        return leerParametrosTexto(sb.toString());
    }

    private static Map<String, String> leerParametrosTexto(String texto) {

        Map<String, String> parametros = new HashMap<>();

        if (texto == null || texto.isEmpty()) {
            return parametros;
        }

        for (String parametro : texto.split("&")) {
            String[] partes = parametro.split("=", 2);

            // CORREGIDO: Se evalúa si el arreglo está vacío o si su primer elemento no tiene texto
            if (partes.length == 0 || partes[0].isEmpty()) {
                continue; 
            }

            try {
                String clave = URLDecoder.decode(partes[0], StandardCharsets.UTF_8.name());

                String valor = partes.length > 1
                        ? URLDecoder.decode(partes[1], StandardCharsets.UTF_8.name())
                        : "";

                parametros.put(clave, valor);

            } catch (Exception error) {
                // Ignora el parámetro si está corrupto
            }
        }

        return parametros;
    }

    private static boolean faltaDato(String valor) {
        return valor == null || valor.trim().isEmpty();
    }

    private static boolean estadoValido(String estado) {
        return java.util.Arrays.asList(
                "Completado", "Volando", "Programado",
                "A Tiempo", "Atrasado", "Cancelado",
                "Choco", "Exploto", "Perdido"
        ).contains(estado);
    }

    private static boolean esEmpleado(HttpExchange intercambio) {

        String idSesion = obtenerIdSesion(intercambio);

        if (idSesion == null) {
            return false;
        }

        DatosSesion sesion = sesiones.get(idSesion);

        return sesion != null && sesion.esEmpleado();
    }

    private static int obtenerIdUsuario(HttpExchange intercambio) {

        String idSesion = obtenerIdSesion(intercambio);

        if (idSesion == null) {
            return -1;
        }

        DatosSesion sesion = sesiones.get(idSesion);

        if (sesion == null || sesion.esEmpleado()) {
            return -1;
        }

        return sesion.getIdUsuario();
    }

    private static String obtenerIdSesion(HttpExchange intercambio) {

        String cookie = intercambio.getRequestHeaders().getFirst("Cookie");

        if (cookie == null) {
            return null;
        }

        for (String parte : cookie.split(";")) {
            String elemento = parte.trim();

            if (elemento.startsWith("CHORIFLY_SESSION=")) {
                String id = elemento.substring(
                        "CHORIFLY_SESSION=".length());

                return id.isEmpty() ? null : id;
            }
        }

        return null;
    }

    private static void enviarRespuesta(
            HttpExchange intercambio, int codigo, String mensaje)
            throws IOException {

        byte[] contenido = mensaje.getBytes(StandardCharsets.UTF_8);

        intercambio.getResponseHeaders().set(
                "Content-Type", "text/plain; charset=UTF-8");

        intercambio.sendResponseHeaders(codigo, contenido.length);
        intercambio.getResponseBody().write(contenido);
        intercambio.close();
    }

    private static void enviarRespuestaJSON(
            HttpExchange intercambio, int codigo, String mensaje)
            throws IOException {

        byte[] contenido = mensaje.getBytes(StandardCharsets.UTF_8);

        intercambio.getResponseHeaders().set(
                "Content-Type", "application/json; charset=UTF-8");

        intercambio.sendResponseHeaders(codigo, contenido.length);
        intercambio.getResponseBody().write(contenido);
        intercambio.close();
    }
}
