package chorifly;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.DateTimeException;
import java.text.SimpleDateFormat;

public class VentanaCrudBoletos extends javax.swing.JFrame {
    private boolean vieneDeAdmin;
    private ExtrasDAO edao = new ExtrasDAO();
    private Validaciones valid = new Validaciones();
    private PasajeroDAO pdao = new PasajeroDAO();
    private ArrayList<JCheckBox> listaChecksServicios = new ArrayList<>();
    private ArrayList<Servicio> listaServiciosBD = new ArrayList<>();

    SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
    
    public VentanaCrudBoletos(boolean vieneDeAdmin) {
        this.vieneDeAdmin = vieneDeAdmin;
        initComponents();
        
        // No editables
        txtPasajero.setText("Seleccionar Pasajero");
        txtVuelo.setText("Seleccionar Vuelo");
        txtAsiento.setText("Seleccionar Asiento");
        txtServicios.setText("Seleccionar Servicios");
        
        // Editables
        txtHora.putClientProperty("JTextField.placeholderText", "HH:MM:SS");
        txtBuscar.putClientProperty("JTextField.placeholderText", "ID Boleto");
        
        // Comodidad, evita la selección azul
        txtPasajero.setFocusable(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        dateFecha = new com.toedter.calendar.JDateChooser();
        txtHora = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaVuelos = new javax.swing.JTable();
        txtPasajero = new javax.swing.JTextField();
        txtVuelo = new javax.swing.JTextField();
        txtAsiento = new javax.swing.JTextField();
        txtServicios = new javax.swing.JTextField();
        btnVolver = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();
        txtPrecioBase = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Boletos");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Pasajero");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Vuelo");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Asiento");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Fecha");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Precio Base");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Servicios");

        txtHora.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        tablaVuelos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Boleto", "Pasajero_id", "Vuelo_id", "Asiento_id", "Fecha", "Precio Base", "Servicios"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaVuelos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaVuelosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaVuelos);
        if (tablaVuelos.getColumnModel().getColumnCount() > 0) {
            tablaVuelos.getColumnModel().getColumn(0).setResizable(false);
            tablaVuelos.getColumnModel().getColumn(1).setResizable(false);
            tablaVuelos.getColumnModel().getColumn(2).setResizable(false);
            tablaVuelos.getColumnModel().getColumn(3).setResizable(false);
            tablaVuelos.getColumnModel().getColumn(4).setResizable(false);
            tablaVuelos.getColumnModel().getColumn(5).setResizable(false);
            tablaVuelos.getColumnModel().getColumn(6).setResizable(false);
        }

        txtPasajero.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtPasajero.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPasajeroMouseClicked(evt);
            }
        });

        txtVuelo.setEditable(false);
        txtVuelo.setBackground(new java.awt.Color(255, 255, 255));
        txtVuelo.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtVuelo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtVueloMouseClicked(evt);
            }
        });
        txtVuelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtVueloActionPerformed(evt);
            }
        });

        txtAsiento.setEditable(false);
        txtAsiento.setBackground(new java.awt.Color(255, 255, 255));
        txtAsiento.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtAsiento.setText("Ahora arreglar boton");
        txtAsiento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtAsientoMouseClicked(evt);
            }
        });

        txtServicios.setEditable(false);
        txtServicios.setBackground(new java.awt.Color(255, 255, 255));
        txtServicios.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtServicios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtServiciosMouseClicked(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnMostrar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N

        txtPrecioBase.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtBuscar))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtServicios)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(dateFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtPasajero, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtVuelo, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtAsiento, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnMostrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(txtPrecioBase))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtPasajero)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtVuelo))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtAsiento))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtHora)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dateFecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtPrecioBase))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtServicios))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(25, 25, 25)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPasajeroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPasajeroMouseClicked
        ArrayList<String> listaPasajeros = edao.listarPasajeros();

        if (listaPasajeros == null || listaPasajeros.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay pasajeros registrados en la base de datos.", "Menú Pasajeros", JOptionPane.ERROR_MESSAGE);
            txtPasajero.setText("Seleccionar Pasajero");
            return;
        }
        
        String [] nuevaListaPasajeros = listaPasajeros.toArray(new String[0]);
        
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Pasajero:",
            "Menú Pasajeros",
            JOptionPane.DEFAULT_OPTION,
            null,
            nuevaListaPasajeros,
            nuevaListaPasajeros[0]
        );

        if (seleccion != null) {
            txtPasajero.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Pasajeros", JOptionPane.WARNING_MESSAGE);
            txtPasajero.setText("Seleccionar Pasajero");
        }
    }//GEN-LAST:event_txtPasajeroMouseClicked

    private void txtVueloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtVueloMouseClicked
        ArrayList<String> listaVuelos = edao.listarVuelos();

        // 2. Validación de seguridad en caso de que no existan registros
        if (listaVuelos == null || listaVuelos.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay vuelos registrados en la base de datos.", "Menú Vuelos", JOptionPane.ERROR_MESSAGE);
            txtVuelo.setText("Seleccionar Vuelo");
            return;
        }

        // 3. Convertir el ArrayList a un arreglo de Strings tradicional
        String[] nuevaListaVuelos = listaVuelos.toArray(new String[0]);

        // 4. Mostrar el menú de selección con el cuadro de diálogo
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Vuelo:",
            "Menú Vuelos",
            JOptionPane.DEFAULT_OPTION,
            null,
            nuevaListaVuelos,
            nuevaListaVuelos[0]
        );

        // 5. Procesar la selección del usuario
        if (seleccion != null) {
            txtVuelo.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Vuelos", JOptionPane.WARNING_MESSAGE);
            txtVuelo.setText("Seleccionar Vuelo");
        }

    }//GEN-LAST:event_txtVueloMouseClicked

    private void txtAsientoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtAsientoMouseClicked
        VentanaAsientos ventanaAsientos = new VentanaAsientos(1);
        ventanaAsientos.setVisible(true);
        ventanaAsientos.setLocationRelativeTo(null);
    }//GEN-LAST:event_txtAsientoMouseClicked

    private void txtServiciosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtServiciosMouseClicked
        listaServiciosBD = edao.listarServicios();

        // Container y elementos uno abajo de otro
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Lista con los checkbox marcados
        ArrayList<JCheckBox> nuevosChecks = new ArrayList<>();

        for (Servicio s : listaServiciosBD) {
            // Crea las Checkbox
            JCheckBox check = new JCheckBox(s.getNombreServicio() + " - $" + s.getPrecio());

            
            // Compara si hay datos viejos con los nuevos
            if (!listaChecksServicios.isEmpty()) {
                for (JCheckBox cbViejo : listaChecksServicios) {
                    if (cbViejo.getText().equals(check.getText()) && cbViejo.isSelected()) {
                        check.setSelected(true);
                        break;
                    }
                }
            }

            nuevosChecks.add(check);
            panel.add(check);
        }
        
        // Guarda los checks hechos en la variable global
        listaChecksServicios = nuevosChecks;

        JOptionPane.showMessageDialog(null, panel, "Seleccionar Servicios", JOptionPane.PLAIN_MESSAGE);

        int contadorServicios = 0;
        for (JCheckBox cb : listaChecksServicios) {
            if (cb.isSelected()) {
                contadorServicios++; 
            }
        }

        txtServicios.setText("Servicios seleccionados: " + contadorServicios);
    }//GEN-LAST:event_txtServiciosMouseClicked

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaMenuPrincipalAdmin menuPrincipalAdmin = new VentanaMenuPrincipalAdmin();
        VentanaMenuPrincipal menuPrincipal = new VentanaMenuPrincipal();
        if (vieneDeAdmin) {
            menuPrincipalAdmin.setVisible(true);
            menuPrincipalAdmin.setLocationRelativeTo(null);
            this.dispose();
        } else {
            menuPrincipal.setVisible(true);
            menuPrincipal.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        /*VueloDAO vdao = new VueloDAO();
        
        Avion avion = edao.buscarAvionPorId(txtPasajero.getText());
        Aeropuerto origen = edao.buscarAeropuertoPorNombre(txtVuelo.getText());
        Aeropuerto destino = edao.buscarAeropuertoPorNombre(txtAsiento.getText());
        
        try {
            String fechaSalida = formato.format(dateFecha.getDate()) + " " + txtHora.getText();
            
            String estado = txtServicios.getText();

            LocalDateTime fechaHoraSalida = LocalDateTime.parse(
                    fechaSalida,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            );

            LocalDateTime fechaHoraLlegada = LocalDateTime.parse(
                    fechaLlegada,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            );

            if (valid.validarFecha(fechaHoraSalida, fechaHoraLlegada)) {
                Vuelo v = new Vuelo(avion, origen, destino, fechaHoraSalida, fechaHoraLlegada, estado);
                vdao.agregarVuelo(v);
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(null, "La hora de salida no debe ser posterior a la hora de llegada", "Creación de Vuelo", JOptionPane.ERROR_MESSAGE);
            }
            
            
        } catch (DateTimeException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex, "Creación de Vuelo", JOptionPane.ERROR_MESSAGE);
        }*/
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        actualizarTabla();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void tablaVuelosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaVuelosMouseClicked
        /*int fila = tablaVuelos.getSelectedRow();
        int id = (int) tablaVuelos.getValueAt(fila, 0);

        // Normales
        String avion = tablaVuelos.getValueAt(fila, 1).toString();
        int origen = (int) tablaVuelos.getValueAt(fila, 2);
        int destino = (int) tablaVuelos.getValueAt(fila, 3);
        String estado = tablaVuelos.getValueAt(fila, 6).toString();
        
        // Para fecha y hora
        String fechaHoraSalidaTexto = tablaVuelos.getValueAt(fila, 4).toString();
        String fechaHoraLlegadaTexto = tablaVuelos.getValueAt(fila, 5).toString();

        // Poner Normales
        txtPasajero.setText(avion);
        txtVuelo.setText(edao.buscarAeropuertoPorId(origen).getNombre());
        txtAsiento.setText(edao.buscarAeropuertoPorId(destino).getNombre());
        txtServicios.setText(estado);
        
        // Formato fecha/hora
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        // Asignar las fechas/horas
        LocalDateTime fechaHoraSalida = LocalDateTime.parse(fechaHoraSalidaTexto, formato);
        LocalDateTime fechaHoraLlegada = LocalDateTime.parse(fechaHoraLlegadaTexto, formato);

        Date fechaSalida = java.sql.Timestamp.valueOf(fechaHoraSalida);
        Date fechaLlegada = java.sql.Timestamp.valueOf(fechaHoraLlegada);

        Calendar calendarioSalida = Calendar.getInstance();
        calendarioSalida.setTime(fechaSalida);

        Calendar calendarioLlegada = Calendar.getInstance();
        calendarioLlegada.setTime(fechaLlegada);

        dateFecha.setCalendar(calendarioSalida);
        dateLlegada.setCalendar(calendarioLlegada);

        txtHora.setText(fechaHoraSalida.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        txtHoraLlegada.setText(fechaHoraLlegada.format(DateTimeFormatter.ofPattern("HH:mm:ss")));*/
    }//GEN-LAST:event_tablaVuelosMouseClicked

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        /*int fila = tablaVuelos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un vuelo.",
                "Edición de Vuelo",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaVuelos.getValueAt(fila, 0);

        VueloDAO vdao = new VueloDAO();

        Avion avion = edao.buscarAvionPorId(txtPasajero.getText());
        Aeropuerto origen = edao.buscarAeropuertoPorNombre(txtVuelo.getText());
        Aeropuerto destino = edao.buscarAeropuertoPorNombre(txtAsiento.getText());
        String estado = txtServicios.getText();
        
        try {
            String fechaSalida = formato.format(dateFecha.getDate()) + " " + txtHora.getText();
            String fechaLlegada = formato.format(dateLlegada.getDate()) + " " + txtHoraLlegada.getText();

            LocalDateTime fechaHoraSalida = LocalDateTime.parse(
                    fechaSalida,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            );

            LocalDateTime fechaHoraLlegada = LocalDateTime.parse(
                    fechaLlegada,
                    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
            );

            // Agregamos la verificación de fechas antes de editar
            if (valid.validarFecha(fechaHoraSalida, fechaHoraLlegada)) {
                Vuelo v = new Vuelo(
                        avion,
                        origen,
                        destino,
                        fechaHoraSalida,
                        fechaHoraLlegada,
                        estado
                );

                v.setIdVuelo(id);
                vdao.editarVuelo(v);
                actualizarTabla();
            } else {
                JOptionPane.showMessageDialog(
                    null, 
                    "La hora de salida no debe ser posterior a la hora de llegada", 
                    "Edición de Vuelo", 
                    JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (DateTimeException ex) {
            JOptionPane.showMessageDialog(
                null, 
                "Error en el formato de las fechas: " + ex.getMessage(), 
                "Edición de Vuelo", 
                JOptionPane.ERROR_MESSAGE
            );
        }*/
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tablaVuelos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un vuelo.",
                "Eliminar Vuelo",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaVuelos.getValueAt(fila, 0);
        VueloDAO vdao = new VueloDAO();
        vdao.eliminarVuelo(id);
        actualizarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        VueloDAO vdao = new VueloDAO();
        if (txtBuscar.getText() != null && !txtBuscar.getText().trim().isEmpty()) {
            int id = Integer.parseInt(txtBuscar.getText().trim());

            ArrayList<Vuelo> vuelos = vdao.buscarVuelo(id);
            DefaultTableModel modelo = (DefaultTableModel) tablaVuelos.getModel();

            modelo.setRowCount(0);

            for (Vuelo v : vuelos) {

                modelo.addRow(new Object[]{
                    v.getId_vuelo(),
                    v.getAvionUsado().getIdAvion(),
                    v.getAeropuertoOrigen().getIdAeropuerto(),
                    v.getAeropuertoDestino().getIdAeropuerto(),
                    v.getFechaHoraSalida().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                    v.getFechaHoraLlegada().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")),
                    v.getEstado()
                });
            }
        } else {
            JOptionPane.showMessageDialog(null, "El campo de ID Vuelo no debe estar vacío", "Buscar Vuelo", JOptionPane.WARNING_MESSAGE);
        }
           
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtVueloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtVueloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVueloActionPerformed

    public void listarAeropuertos(javax.swing.JTextField txtAeropuerto, String textoAExcluir) {
        String[] todosLosAeropuertos = edao.listarAeropuertos();
        ArrayList<String> listaModificable = new ArrayList<>(Arrays.asList(todosLosAeropuertos));

        if (!textoAExcluir.equals("Seleccionar Aeropuerto")) {
            listaModificable.remove(textoAExcluir);
        }

        String[] opcionesDisponibles = listaModificable.toArray(new String[0]);
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Aeropuerto:",
            "Menú Aeropuertos",
            JOptionPane.DEFAULT_OPTION,
            null,
            opcionesDisponibles,
            opcionesDisponibles[0]
        );

        if (seleccion != null) {
            txtAeropuerto.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Aeropuertos", JOptionPane.WARNING_MESSAGE);
            txtAeropuerto.setText("Seleccionar Aeropuerto");
        }
    }
    
    public void actualizarTabla() {
        VueloDAO vdao = new VueloDAO();
        ArrayList<Vuelo> listaVuelos = vdao.mostrarVuelo();
        DefaultTableModel modelo = (DefaultTableModel)tablaVuelos.getModel();
        DateTimeFormatter formatoFechaHora = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        
        modelo.setRowCount(0);
        
        for (Vuelo v : listaVuelos) {
            modelo.addRow(new Object []{
                v.getId_vuelo(),
                v.getAvionUsado().getIdAvion(),
                v.getAeropuertoOrigen().getIdAeropuerto(),
                v.getAeropuertoDestino().getIdAeropuerto(),
                v.getFechaHoraSalida().format(formatoFechaHora),
                v.getFechaHoraLlegada().format(formatoFechaHora),
                v.getEstado()
            });
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private com.toedter.calendar.JDateChooser dateFecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaVuelos;
    private javax.swing.JTextField txtAsiento;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtHora;
    private javax.swing.JTextField txtPasajero;
    private javax.swing.JTextField txtPrecioBase;
    private javax.swing.JTextField txtServicios;
    private javax.swing.JTextField txtVuelo;
    // End of variables declaration//GEN-END:variables
}
