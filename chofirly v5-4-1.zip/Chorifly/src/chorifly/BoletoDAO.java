package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class BoletoDAO {
    public void insertar(Boleto b) {
        String insert_sql = "INSERT INTO Boleto (pasajero_id, vuelo_id, asiento_id, fecha, precio_base) VALUES (?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, b.getPasajero().getId_Pasajero());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Vuelo Guardado Exitosamente",
                    "Creación de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
