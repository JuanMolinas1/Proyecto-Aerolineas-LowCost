package chorifly;

import java.time.LocalDateTime;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Boleto {
    private int id_boleto;
    private Pasajero pasajero;
    private Vuelo vuelo;
    private Asiento asiento;
    private LocalDateTime fecha;
    private double precio_base;
    private ArrayList<Servicio> l_servicios = new ArrayList<>();

    public Boleto(Pasajero pasajero, Vuelo vuelo, Asiento asiento, double precio_base) {
        this.pasajero = pasajero;
        this.vuelo = vuelo;
        this.asiento = asiento;
        this.fecha = vuelo.getFechaHoraSalida();
        this.precio_base = precio_base;
    }

    public int getId_boleto() {
        return id_boleto;
    }

    public void setId_boleto(int id_boleto) {
        this.id_boleto = id_boleto;
    }

    public Persona getPasajero() {
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public Asiento getAsiento() {
        return asiento;
    }

    public void setAsiento(Asiento asiento) {
        this.asiento = asiento;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public double getPrecio_base() {
        return precio_base;
    }

    public void setPrecio_base(double precio_base) {
        this.precio_base = precio_base;
    }

    public ArrayList<Servicio> getServicios() {
        return l_servicios;
    }

    public void setServicios(ArrayList<Servicio> servicios) {
        this.l_servicios = servicios;
    }
    
    public double CalcularPrecioServicios() {
        double precio_total = 0;
        for (Servicio s : l_servicios) {
            precio_total += s.getPrecio();
        }
        return precio_total;
    }
    
    public double CalcularPrecioTotal() {
        return precio_base + CalcularPrecioServicios();
    }
    
    public void mostrarBoleto() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Boleto --"
                + "\nID Boleto: " + id_boleto
                + "\nVuelo: " + vuelo.getId_vuelo()
                + "\nAsiento: " + asiento.getId_asiento()
                + "\nFecha: " + fecha
                + "\nPrecio base: $" + precio_base
                + "\nPrecio servicios: $" + CalcularPrecioServicios()
                + "\nPrecio total: $" + CalcularPrecioTotal(),
                "Información del Boleto",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
    
    public void agregarServicio(Servicio s) {
        l_servicios.add(s);
    }
}
