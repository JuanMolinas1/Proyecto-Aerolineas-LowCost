package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class VueloDAO {
    public void insertarVuelo(Vuelo v) {
        String insert_sql = "INSERT INTO Vuelo (avion_id, origen_id, destino_id, fecha_hora_salida, fecha_hora_llegada, estado) VALUES (?, ?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setString(1, v.getAvionUsado().getId_avion());
            sentencia_sql.setInt(2, v.getAeropuertoOrigen().getId_aeropuerto());
            sentencia_sql.setInt(3, v.getAeropuertoDestino().getId_aeropuerto());
            sentencia_sql.setObject(4, v.getFechaHoraSalida());
            sentencia_sql.setObject(5, v.getFechaHoraLlegada());
            sentencia_sql.setString(6, v.getEstado());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Vuelo Guardado Exitosamente",
                    "Creación de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public void listarVuelo(){
        String consulta_sql = "SELECT * FROM Vuelo";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Vuelo --"
                + "\nID Vuelo: " + resultado.getInt("IDVuelo")
                + "\nAvión: " + resultado.getString("avion_id")
                + "\nOrigen: " + resultado.getInt("origen_id")
                + "\nDestino: " + resultado.getInt("destino_id")
                + "\nSalida: " + resultado.getObject("fecha_hora_salida")
                + "\nLlegada: " + resultado.getObject("fecha_hora_llegada")
                + "\nEstado: " + resultado.getString("estado"),
                "Información del Vuelo",
                JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Vuelo",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
