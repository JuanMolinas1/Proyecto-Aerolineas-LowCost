package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ExtrasDAO {

    public Avion buscarAvionPorId(String id) {
        Avion avion = null;
        String consulta_sql = "SELECT * FROM Avion WHERE IDAvion = ?"; 
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setString(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                avion = new Avion();
                avion.setIdAvion(resultado.getString("IDAvion"));
                avion.setModelo(resultado.getString("modelo"));
                avion.setCapacidad(resultado.getInt("capacidad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Avión): " + ex.getMessage(), 
                    "Error - Buscar Avión Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return avion;
    }

    public Aeropuerto buscarAeropuertoPorId(int id) {
        Aeropuerto aero = null;
        String consulta_sql = "SELECT * FROM Aeropuerto WHERE IDAeropuerto = ?";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                aero = new Aeropuerto();
                aero.setId_aeropuerto(resultado.getInt("IDAeropuerto"));
                aero.setNombre(resultado.getString("nombre"));
                aero.setPais(resultado.getString("pais"));
                aero.setCiudad(resultado.getString("ciudad"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Aeropuerto): " + ex.getMessage(), 
                    "Error - Buscar Aeropuerto Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return aero;
    }

    public Departamento buscarDepartamentoPorId(int id) {
        Departamento d = null;
        String consulta_sql = "SELECT * FROM Departamento WHERE IDDepartamento = ?";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                d = new Departamento();
                d.setIdDepartamento(resultado.getInt("IDDepartamento"));
                d.setNombre(resultado.getString("nombre"));
                d.setTipo(resultado.getString("tipo"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Departamento): " + ex.getMessage(), 
                    "Error - Buscar Departamento Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return d;
    }

    public Usuario buscarUsuarioPorId(int id) {
        Usuario u = null;
        String consulta_sql = "SELECT * FROM Usuario WHERE IDUsuario = ?";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                u = new Usuario();
                u.setIdUsuario(resultado.getInt("IDUsuario"));
                u.setUsuario(resultado.getString("nombre_usuario"));
                u.setEmail(resultado.getString("email"));
                u.setContraseña(resultado.getString("contraseña_usuario"));
                u.setPrivilegiosEmpleado(resultado.getBoolean("privilegios_empleado"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Usuario): " + ex.getMessage(), 
                    "Error - Buscar Usuario Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return u;
    }

    public Pasajero buscarPasajeroPorId(int id) {
        Pasajero p = null;
        String consulta_sql = "SELECT * FROM Pasajero WHERE IDPasajero = ?";
       try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                p = new Pasajero();
                p.setIdPasajero(resultado.getInt("IDPasajero"));
                p.setNombre(resultado.getString("nombre_pasajero"));
                p.setApellido(resultado.getString("apellido_pasajero"));
                p.setDni(resultado.getString("dni_pasajero"));
                p.setTelefono(resultado.getString("telefono"));
                p.setFechaNacimiento(resultado.getDate("fecha_nacimiento").toLocalDate());
                p.setNroPasaporte(resultado.getString("nro_pasaporte"));
                p.setPaisEmision(resultado.getString("pais_emision"));
                p.setVencimientoPasaporte(resultado.getDate("vencimiento_pasaporte").toLocalDate());
                
                int idUsuario = resultado.getInt("usuario_id");
                p.setUsuario(buscarUsuarioPorId(idUsuario));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Pasajero): " + ex.getMessage(), 
                    "Error - Buscar Pasajero Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return p;
    }

    public Boleto buscarBoletoPorId(int id) {
        Boleto b = null;
        String consulta_sql = "SELECT * FROM Boleto WHERE IDBoleto = ?";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                b = new Boleto();
                b.setIdBoleto(resultado.getInt("IDBoleto"));
                b.setFecha(resultado.getTimestamp("fecha").toLocalDateTime());
                b.setPrecioBase(resultado.getDouble("precio_base"));

                int idPasajero = resultado.getInt("pasajero_id");
                b.setPasajero(buscarPasajeroPorId(idPasajero));

                int idVuelo = resultado.getInt("vuelo_id");
                VueloDAO vDAO = new VueloDAO();
                b.setVuelo(vDAO.buscarVuelo(idVuelo).get(0)); 

                Asiento asiento = new Asiento();
                asiento.setIdAsiento(resultado.getString("asiento_id"));
                b.setAsiento(asiento);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Boleto): " + ex.getMessage(), 
                    "Error - Buscar Boleto Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return b;
    }
    
    public Pago buscarPagoPorId(int id) {
        Pago p = null;
        String consulta_sql = "SELECT * FROM Pago WHERE IDPago = ?";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();
            if (resultado.next()) {
                p = new Pago();
                p.setIdPago(resultado.getInt("IDPago"));
                p.setCostoServicios(resultado.getDouble("costo_servicios"));
                p.setCostoTotal(resultado.getDouble("costo_total"));
                p.setEstado(resultado.getString("estado"));

                int idPasajero = resultado.getInt("pasajero_id");
                p.setPasajero(buscarPasajeroPorId(idPasajero));

                int idBoleto = resultado.getInt("boleto_id");
                p.setBoleto(buscarBoletoPorId(idBoleto));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error en BD (Pago): " + ex.getMessage(), 
                    "Error - Buscar Pago Por ID", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return p;
    }
    
    // Hacemos una lista de IDAvione usando ArrayList y la convertimos a String[]
    public String[] listarAviones() {
        ArrayList<String> listaAviones = new ArrayList();
        String consulta_sql = "SELECT IDAvion FROM Avion";
        listaAviones.add("Default"); 
        
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                listaAviones.add(resultado.getString("IDAvion"));
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error: " + ex.getMessage(), 
                    "Error - Listar Aviones", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return listaAviones.toArray(new String[0]);
    }
    
    public String[] listarAeropuertos() {
        ArrayList<String> listaAeropuertos = new ArrayList();
        String consulta_sql = "SELECT nombre FROM Aeropuerto";
        listaAeropuertos.add("Default"); 
        
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                listaAeropuertos.add(resultado.getString("nombre"));
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null, 
                    "Error: " + ex.getMessage(), 
                    "Error - Listar Aeropuertos", 
                    JOptionPane.ERROR_MESSAGE);
        }
        return listaAeropuertos.toArray(new String[0]);
    }
    
    public String[] listarEstadosVuelos() {
        ArrayList<String> listaEstados = new ArrayList();
        listaEstados.add("Completado");
        listaEstados.add("Volando");
        listaEstados.add("A Tiempo");
        listaEstados.add("Atrasado");
        listaEstados.add("Cancelado");
        listaEstados.add("Choco");
        listaEstados.add("Exploto");
        listaEstados.add("Perdido");
        
        return listaEstados.toArray(new String[0]);
    }
}