
package chorifly;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RegistroBoleto {

    private static final BigDecimal PRECIO_BASE =
            new BigDecimal("40000.00");

    public static int comprarBoleto(
            int idUsuario,
            int idVuelo,
            String codigoAsiento,
            String nombre,
            String apellido,
            String documento,
            String correo,
            List<Integer> servicios) throws SQLException {

        if (idUsuario < 1 || idVuelo < 1
                || faltaDato(codigoAsiento)
                || faltaDato(nombre)
                || faltaDato(apellido)
                || faltaDato(documento)
                || faltaDato(correo)) {

            throw new SQLException(
                    "Completá todos los datos obligatorios.");
        }

        if (!correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new SQLException("El correo electrónico no es válido.");
        }

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new SQLException("No se pudo conectar con MySQL.");
        }

        boolean autoCommitAnterior = conexion.getAutoCommit();

        try {
            conexion.setAutoCommit(false);

            int idPasajero = obtenerPasajero(
                    conexion, idUsuario, nombre,
                    apellido, documento, correo);

            String avion;
            Timestamp fechaSalida;

            String sqlVuelo = "{CALL Obtener_Datos_Vuelo_Para_Actualizar(?)}";

            try (PreparedStatement consulta =
                    conexion.prepareStatement(sqlVuelo)) {

                consulta.setInt(1, idVuelo);

                try (ResultSet resultado = consulta.executeQuery()) {

                    if (!resultado.next()) {
                        throw new SQLException(
                                "El vuelo seleccionado no existe.");
                    }

                    avion = resultado.getString("avion_id");
                    fechaSalida = resultado.getTimestamp(
                            "fecha_hora_salida");

                    String estado = resultado.getString("estado");

                    if (!estado.equals("Programado")
                            && !estado.equals("A Tiempo")
                            && !estado.equals("Atrasado")) {

                        throw new SQLException(
                                "El vuelo no está disponible para comprar.");
                    }

                    if (!fechaSalida.toLocalDateTime()
                            .isAfter(LocalDateTime.now())) {

                        throw new SQLException(
                                "El vuelo ya salió.");
                    }
                }
            }

            String idAsiento;

            String sqlAsiento = "{CALL Obtener_IDAsiento_Para_Actualizar(?, ?)}";

            try (PreparedStatement consulta =
                    conexion.prepareStatement(sqlAsiento)) {

                consulta.setString(1, codigoAsiento.trim());
                consulta.setString(2, avion);

                try (ResultSet resultado = consulta.executeQuery()) {

                    if (!resultado.next()) {
                        throw new SQLException(
                                "El asiento no existe o ya no está disponible.");
                    }

                    idAsiento = resultado.getString("IDAsiento");
                }
            }

            String sqlInsertar =
                    "INSERT INTO Boleto "
                    + "(pasajero_id, vuelo_id, asiento_id, fecha, precio_base) "
                    + "VALUES (?, ?, ?, ?, ?)";

            int idBoleto;

            try (PreparedStatement consulta =
                    conexion.prepareStatement(
                            sqlInsertar,
                            PreparedStatement.RETURN_GENERATED_KEYS)) {

                consulta.setInt(1, idPasajero);
                consulta.setInt(2, idVuelo);
                consulta.setString(3, idAsiento);
                consulta.setTimestamp(4, fechaSalida);
                consulta.setBigDecimal(5, PRECIO_BASE);

                consulta.executeUpdate();

                try (ResultSet resultado = consulta.getGeneratedKeys()) {

                    if (!resultado.next()) {
                        throw new SQLException(
                                "No se pudo obtener el ID del boleto.");
                    }

                    idBoleto = resultado.getInt(1);
                }
            }

            String sqlActualizarAsiento =
                    "UPDATE Asiento SET disponible = FALSE "
                    + "WHERE IDAsiento = ? AND disponible = TRUE";

            try (PreparedStatement consulta =
                    conexion.prepareStatement(sqlActualizarAsiento)) {

                consulta.setString(1, idAsiento);

                if (consulta.executeUpdate() != 1) {
                    throw new SQLException(
                            "El asiento dejó de estar disponible.");
                }
            }

            insertarServicios(conexion, idBoleto, servicios);

            conexion.commit();

            return idBoleto;

        } catch (SQLException | RuntimeException error) {

            conexion.rollback();
            throw error;

        } finally {

            try {
                conexion.setAutoCommit(autoCommitAnterior);
            } finally {
                conexion.close();
            }
        }
    }

    private static int obtenerPasajero(
            Connection conexion,
            int idUsuario,
            String nombre,
            String apellido,
            String documento,
            String correo) throws SQLException {

       String sql = "{CALL Obtener_Datos_Pasajero_Por_Usuario(?)}";

        try (PreparedStatement consulta =
                conexion.prepareStatement(sql)) {

            consulta.setInt(1, idUsuario);

            try (ResultSet resultado = consulta.executeQuery()) {

                if (!resultado.next()) {
                    throw new SQLException(
                            "No se encontró el pasajero de esta cuenta.");
                }

                boolean coincideNombre =
                        resultado.getString("nombre_pasajero")
                                .equalsIgnoreCase(nombre.trim());

                boolean coincideApellido =
                        resultado.getString("apellido_pasajero")
                                .equalsIgnoreCase(apellido.trim());

                boolean coincideDocumento =
                        resultado.getString("dni_pasajero")
                                .equals(documento.trim());

                boolean coincideCorreo =
                        resultado.getString("email")
                                .equalsIgnoreCase(correo.trim());

                System.out.println("COINCIDE NOMBRE: " + coincideNombre);
                System.out.println("COINCIDE APELLIDO: " + coincideApellido);
                System.out.println("COINCIDE DOCUMENTO: " + coincideDocumento);
                System.out.println("COINCIDE CORREO: " + coincideCorreo);

                boolean datosCorrectos =
                        coincideNombre && coincideApellido
                        && coincideDocumento && coincideCorreo;

                if (!datosCorrectos) {
                    throw new SQLException(
                            "Los datos ingresados no coinciden con tu cuenta.");
                }

                return resultado.getInt("IDPasajero");
            }
        }
    }

    private static void insertarServicios(
            Connection conexion,
            int idBoleto,
            List<Integer> servicios) throws SQLException {

        if (servicios == null || servicios.isEmpty()) {
            return;
        }

        Set<Integer> idsUnicos = new HashSet<>(servicios);

        if (idsUnicos.size() != servicios.size()) {
            throw new SQLException(
                    "Hay servicios repetidos en la selección.");
        }

        String sql =
                "INSERT INTO Boleto_Servicio "
                + "(boleto_id, servicio_id) VALUES (?, ?)";

        try (PreparedStatement consulta =
                conexion.prepareStatement(sql)) {

            for (Integer idServicio : idsUnicos) {

                if (idServicio == null || idServicio < 1
                        || idServicio > 4) {

                    throw new SQLException(
                            "Se seleccionó un servicio no válido.");
                }

                consulta.setInt(1, idBoleto);
                consulta.setInt(2, idServicio);
                consulta.addBatch();
            }

            consulta.executeBatch();
        }
    }

    public static String listarAsientos(int idVuelo) throws SQLException {

        if (idVuelo < 1) {
            throw new SQLException("El vuelo seleccionado no es válido.");
        }

        String sql = "{CALL Obtener_Asientos_Por_Vuelo(?)}";

        StringBuilder json = new StringBuilder("[");
        boolean primero = true;

        Connection conexion = ConexionSQL.conectar();

        if (conexion == null) {
            throw new SQLException("No se pudo conectar con MySQL.");
        }

        try {
            try (PreparedStatement consulta =
                    conexion.prepareStatement(sql)) {

                consulta.setInt(1, idVuelo);

                try (ResultSet resultado = consulta.executeQuery()) {

                    while (resultado.next()) {

                        if (!primero) {
                            json.append(",");
                        }

                        json.append("{")
                                .append("\"codigo\":\"")
                                .append(resultado.getString("codigo"))
                                .append("\",")
                                .append("\"disponible\":")
                                .append(resultado.getBoolean("disponible"))
                                .append("}");

                        primero = false;
                    }
                }
            }

        } finally {
            conexion.close();
        }

        json.append("]");

        return json.toString();
    }

    private static boolean faltaDato(String valor) {
        return valor == null || valor.trim().isEmpty();
    }
}
