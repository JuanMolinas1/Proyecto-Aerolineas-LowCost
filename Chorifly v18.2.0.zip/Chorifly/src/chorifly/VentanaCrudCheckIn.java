package chorifly;

import java.util.Arrays;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import java.time.format.DateTimeFormatter;

public class VentanaCrudCheckIn extends javax.swing.JFrame {
    private boolean vieneDeAdmin;
    private boolean seleccionAsientoVuelo = false;
    private boolean seleccionAsientoServicio = false;
    private boolean editandoBoleto = false;

    private ExtrasDAO edao = new ExtrasDAO();
    private AsientoDAO adao = new AsientoDAO();
    private PasajeroDAO pdao = new PasajeroDAO();
    private VueloDAO vdao = new VueloDAO();

    private Validaciones valid = new Validaciones();
    private Utilidades uti = new Utilidades();

    private Asiento asientoSeleccionado = null;
    private Vuelo vueloSeleccionado = null;

    private ArrayList<JCheckBox> listaChecksServicios = new ArrayList<>();
    private ArrayList<Servicio> listaServiciosBD = new ArrayList<>();
    
    public VentanaCrudCheckIn(boolean vieneDeAdmin) {
        this.vieneDeAdmin = vieneDeAdmin;
        initComponents();
        
        // No editables
        txtBoleto.setText("Seleccionar Pasajero");
        
        // Editables
        txtBuscar.putClientProperty("JTextField.placeholderText", "ID Boleto");
        
        // Comodidad, evita la selección azul
        txtBoleto.setFocusable(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaBoletos = new javax.swing.JTable();
        txtBoleto = new javax.swing.JTextField();
        txtPuertaEmbarque = new javax.swing.JTextField();
        btnVolver = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chorifly - Menú Boletos");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Boletos");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Boleto");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Puerta Embarque");

        tablaBoletos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Check In", "Pasajero_id", "Boleto_id", "Vuelo_id", "Pago_id", "Puerta Embarque"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaBoletos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaBoletosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaBoletos);
        if (tablaBoletos.getColumnModel().getColumnCount() > 0) {
            tablaBoletos.getColumnModel().getColumn(0).setResizable(false);
            tablaBoletos.getColumnModel().getColumn(1).setResizable(false);
            tablaBoletos.getColumnModel().getColumn(2).setResizable(false);
            tablaBoletos.getColumnModel().getColumn(3).setResizable(false);
            tablaBoletos.getColumnModel().getColumn(4).setResizable(false);
            tablaBoletos.getColumnModel().getColumn(5).setResizable(false);
        }

        txtBoleto.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtBoleto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtBoletoMouseClicked(evt);
            }
        });

        txtPuertaEmbarque.setEditable(false);
        txtPuertaEmbarque.setBackground(new java.awt.Color(255, 255, 255));
        txtPuertaEmbarque.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtPuertaEmbarque.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtPuertaEmbarqueMouseClicked(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnMostrar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(txtBuscar))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtBoleto, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPuertaEmbarque, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnMostrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtBoleto)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtPuertaEmbarque))
                        .addGap(147, 147, 147)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(25, 25, 25)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            buscarAsiento();
        }
    }//GEN-LAST:event_txtBuscarKeyPressed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        buscarAsiento();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int fila = tablaBoletos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un boleto.",
                "Edición de Boleto",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaBoletos.getValueAt(fila, 0);

        BoletoDAO bdao = new BoletoDAO();
        ExtrasDAO edao = new ExtrasDAO();

        Pasajero pasajero = edao.buscarPasajeroPorId(
            Integer.parseInt(uti.borrarDesdeEspacio(txtBoleto.getText()))
        );

        Vuelo vuelo = new VueloDAO().buscarVuelo(
            Integer.parseInt(uti.borrarDesdeEspacio(txtPuertaEmbarque.getText()))
        ).get(0);

        String idAsiento = uti.borrarDesdeEspacio(txtAsiento.getText());
        double precioBase;

        try {
            precioBase = Double.parseDouble(txtPrecioBase.getText());

            AsientoDAO adao = new AsientoDAO();
            Asiento asiento = edao.buscarAsientoPorId(idAsiento);

            if (asiento == null) {
                JOptionPane.showMessageDialog(
                    null,
                    "El asiento seleccionado no existe en la base de datos.",
                    "Edición de Boleto",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            Boleto b = new Boleto(
                pasajero,
                vuelo,
                asiento,
                precioBase
            );

            b.setIdBoleto(id);

            // Agregamos los servicios seleccionados
            for (int i = 0; i < listaChecksServicios.size(); i++) {
                if (listaChecksServicios.get(i).isSelected()) {
                    b.agregarServicio(listaServiciosBD.get(i));
                }
            }

            bdao.editarBoletoServicio(b);
            actualizarTabla();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                null,
                "El precio base debe ser un número válido.",
                "Edición de Boleto",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        BoletoDAO bdao = new BoletoDAO();

        Pasajero pasajero = edao.buscarPasajeroPorId(Integer.parseInt(uti.borrarDesdeEspacio(txtBoleto.getText())));

        Vuelo vuelo = vdao.buscarVuelo(Integer.parseInt(uti.borrarDesdeEspacio(txtPuertaEmbarque.getText()))).get(0);

        AsientoDAO adao = new AsientoDAO();

        Asiento asiento = null;
        String textoAsiento = txtAsiento.getText().trim();

        if (textoAsiento.equals("Seleccionar Asiento (Bloqueado)")) {

            asiento = seleccionarAsientoAleatorio(vuelo.getAvionUsado().getIdAvion());

            if (asiento == null) {
                JOptionPane.showMessageDialog(
                    this,
                    "No hay asientos disponibles para este avión.",
                    "Creación de Boleto",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }
            // Actualizamos el asiento
            asiento.setDisponible(false);
            adao.editarAsiento(asiento);

        } else if (textoAsiento.equals("Seleccionar Asiento")) {

            JOptionPane.showMessageDialog(
                this,
                "Debes elegir un asiento antes de crear el boleto.",
                "Creación de Boleto",
                JOptionPane.ERROR_MESSAGE
            );
            return;

        } else {
            // Actualizamos el asiento
            asiento = new Asiento();
            asiento.setIdAsiento(textoAsiento);
            asiento.setDisponible(false);
            adao.editarAsiento(asiento);

        }
        try {
            // Creamos el Boleto
            double precioBase = Double.parseDouble(txtPrecioBase.getText());

            Boleto b = new Boleto(
                pasajero,
                vuelo,
                asiento,
                precioBase
            );

            bdao.agregarBoleto(b);

            // Creamos un pago pendiente
            if (b.getIdBoleto() != 0) {
                PagoDAO pdao = new PagoDAO();

                Pago pago = new Pago(
                    pasajero,
                    b,
                    "Pendiente"
                );

                pdao.agregarPago(pago);
            }

            actualizarTabla();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                this,
                "El precio base debe ser un número válido.",
                "Creación de Boleto",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tablaBoletos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un boleto.",
                "Eliminar Boleto",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaBoletos.getValueAt(fila, 0);

        BoletoDAO bdao = new BoletoDAO();
        bdao.eliminarBoleto(id);

        actualizarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        actualizarTabla();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaMenuPrincipalAdmin menuPrincipalAdmin = new VentanaMenuPrincipalAdmin();
        VentanaMenuPrincipal menuPrincipal = new VentanaMenuPrincipal();
        if (vieneDeAdmin) {
            menuPrincipalAdmin.setVisible(true);
            menuPrincipalAdmin.setLocationRelativeTo(null);
            this.dispose();
        } else {
            menuPrincipal.setVisible(true);
            menuPrincipal.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_btnVolverActionPerformed

    private void txtPuertaEmbarqueMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtPuertaEmbarqueMouseClicked
        ArrayList<String> listaVuelosTxt = edao.listarVuelos();

        // Validación de seguridad en caso de que no existan registros
        if (listaVuelosTxt == null || listaVuelosTxt.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay vuelos registrados en la base de datos.", "Menú Vuelos", JOptionPane.ERROR_MESSAGE);
            txtPuertaEmbarque.setText("Seleccionar Vuelo");
            return;
        }

        String[] nuevaListaVuelos = listaVuelosTxt.toArray(new String[0]);

        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Vuelo:",
            "Menú Vuelos",
            JOptionPane.DEFAULT_OPTION,
            null,
            nuevaListaVuelos,
            nuevaListaVuelos[0]
        );

        if (seleccion != null) {
            txtPuertaEmbarque.setText(seleccion);
            txtPuertaEmbarque.setCaretPosition(0);

            String idVuelo = uti.borrarDesdeEspacio(txtPuertaEmbarque.getText());
            ArrayList<Vuelo> vueloBuscado = vdao.buscarVuelo(Integer.parseInt(idVuelo));
            vueloSeleccionado = vueloBuscado.get(0);

            seleccionAsientoVuelo = true;

            if (!editandoBoleto || asientoSeleccionado == null) {
                if (seleccionAsientoServicio) {
                    txtAsiento.setText("Seleccionar Asiento");
                } else {
                    cancelarSeleccionAsiento();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Vuelos", JOptionPane.WARNING_MESSAGE);
            txtPuertaEmbarque.setText("Seleccionar Vuelo");
            cancelarSeleccionAsiento();
        }
    }//GEN-LAST:event_txtPuertaEmbarqueMouseClicked

    private void txtBoletoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtBoletoMouseClicked
        ArrayList<String> listaPasajeros = edao.listarPasajeros();

        if (listaPasajeros == null || listaPasajeros.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay pasajeros registrados en la base de datos.", "Menú Pasajeros", JOptionPane.ERROR_MESSAGE);
            txtBoleto.setText("Seleccionar Pasajero");
            return;
        }

        String [] nuevaListaPasajeros = listaPasajeros.toArray(new String[0]);

        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Pasajero:",
            "Menú Pasajeros",
            JOptionPane.DEFAULT_OPTION,
            null,
            nuevaListaPasajeros,
            nuevaListaPasajeros[0]
        );

        if (seleccion != null) {
            txtBoleto.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Pasajeros", JOptionPane.WARNING_MESSAGE);
            txtBoleto.setText("Seleccionar Pasajero");
        }
    }//GEN-LAST:event_txtBoletoMouseClicked

    private void tablaBoletosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaBoletosMouseClicked
        int fila = tablaBoletos.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un boleto.",
                "Editar Boleto",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaBoletos.getValueAt(fila, 0);
        int idPasajero = (int) tablaBoletos.getValueAt(fila, 1);
        int idVuelo = (int) tablaBoletos.getValueAt(fila, 2);
        String idAsiento = tablaBoletos.getValueAt(fila, 3).toString();
        String fechaTexto = tablaBoletos.getValueAt(fila, 4).toString();
        String precioBase = tablaBoletos.getValueAt(fila, 5).toString();

        // Buscar los objetos relacionados
        ExtrasDAO edao = new ExtrasDAO();
        Pasajero pasajero = edao.buscarPasajeroPorId(idPasajero);
        Vuelo vuelo = new VueloDAO().buscarVuelo(idVuelo).get(0);

        // Cargar los campos de texto
        txtBoleto.setText(
            pasajero.getIdPasajero() + " - " +
            pasajero.getNombre() + " " +
            pasajero.getApellido()
        );

        txtPuertaEmbarque.setText(
            vuelo.getId_vuelo() + " - " +
            vuelo.getAeropuertoOrigen().getNombre() + " - " +
            vuelo.getAeropuertoDestino().getNombre()
        );
        txtPuertaEmbarque.setCaretPosition(0);
        seleccionAsientoVuelo = true;

        txtAsiento.setText(idAsiento);
        txtPrecioBase.setText(precioBase);

        // Recuperamos el boleto completo, incluyendo sus servicios
        BoletoDAO bdao = new BoletoDAO();
        Boleto boleto = bdao.buscarBoleto(id).get(0);

        // Indicamos que estamos editando un boleto existente
        editandoBoleto = true;

        // Guardamos el asiento que ya tiene el boleto
        asientoSeleccionado = edao.buscarAsientoPorId(idAsiento);

        // Recuperamos los servicios disponibles
        listaServiciosBD = edao.listarServicios();
        listaChecksServicios = new ArrayList<>();

        boolean tieneServicioSeleccionAsiento = false;

        // Creamos los checkbox de los servicios
        for (Servicio s : listaServiciosBD) {
            JCheckBox check = new JCheckBox(
                s.getNombreServicio() + " - $" + s.getPrecio()
            );

            // Marcamos los servicios que ya tiene el boleto
            for (Servicio servicioBoleto : boleto.getServicios()) {
                if (s.getIdServicio() == servicioBoleto.getIdServicio()) {
                    check.setSelected(true);
                    break;
                }
            }

            // Detectamos si contrató la selección de asiento
            if (s.getNombreServicio().equals("Selección de Asiento")
                && check.isSelected()) {
                tieneServicioSeleccionAsiento = true;
            }

            listaChecksServicios.add(check);
        }

        // Mostramos el asiento según el servicio contratado
        if (tieneServicioSeleccionAsiento) {
            txtAsiento.setText(idAsiento);
        } else {
            txtAsiento.setText(idAsiento + " (Bloqueado)");
        }

        // Actualizamos el contador de servicios
        txtServicios.setText(
            "Servicios seleccionados: " + boleto.getServicios().size()
        );
    }//GEN-LAST:event_tablaBoletosMouseClicked

    public void listarAeropuertos(javax.swing.JTextField txtAeropuerto, String textoAExcluir) {
        String[] todosLosAeropuertos = edao.listarAeropuertos();
        ArrayList<String> listaModificable = new ArrayList<>(Arrays.asList(todosLosAeropuertos));

        if (!textoAExcluir.equals("Seleccionar Aeropuerto")) {
            listaModificable.remove(textoAExcluir);
        }

        String[] opcionesDisponibles = listaModificable.toArray(new String[0]);
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Aeropuerto:",
            "Menú Aeropuertos",
            JOptionPane.DEFAULT_OPTION,
            null,
            opcionesDisponibles,
            opcionesDisponibles[0]
        );

        if (seleccion != null) {
            txtAeropuerto.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Aeropuertos", JOptionPane.WARNING_MESSAGE);
            txtAeropuerto.setText("Seleccionar Aeropuerto");
        }
    }
    
    public void actualizarTabla() {
        BoletoDAO bdao = new BoletoDAO();
        ArrayList<Boleto> listaBoletos = bdao.mostrarBoleto();

        DefaultTableModel modelo = (DefaultTableModel) tablaBoletos.getModel();
        DateTimeFormatter formatoFechaHora = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        modelo.setRowCount(0);

        for (Boleto b : listaBoletos) {
            modelo.addRow(new Object[]{
                b.getIdBoleto(),
                b.getPasajero().getIdPasajero(),
                b.getVuelo().getId_vuelo(),
                b.getAsiento().getIdAsiento(),
                b.getFecha().format(formatoFechaHora),
                b.getPrecioBase(),
                b.getServicios().size()
            });
        }
    }
    
    public void actualizarAsiento(Asiento asiento) {
        asientoSeleccionado = asiento;
        txtAsiento.setText(asiento.getIdAsiento());
    }
    
    public void cancelarSeleccionAsiento() {
        asientoSeleccionado = null;
        txtAsiento.setText("Seleccionar Asiento (Bloqueado)");
    }
    
    public Asiento seleccionarAsientoAleatorio(String idAvion) {
        ArrayList<Asiento> asientosDisponibles = edao.buscarAsientosPorAvion(idAvion);

        if (asientosDisponibles.isEmpty()) {
            return null;
        }

        int indiceAleatorio = (int) (Math.random() * asientosDisponibles.size());

        return asientosDisponibles.get(indiceAleatorio);
    }
    
    public void buscarAsiento() {
        BoletoDAO bdao = new BoletoDAO();

        if (txtBuscar.getText() != null && !txtBuscar.getText().trim().isEmpty()) {
            try {
                int id = Integer.parseInt(txtBuscar.getText().trim());

                ArrayList<Boleto> boletos = bdao.buscarBoleto(id);
                DefaultTableModel modelo = (DefaultTableModel) tablaBoletos.getModel();

                modelo.setRowCount(0);

                for (Boleto b : boletos) {
                    int servicios = b.getServicios().size();

                    modelo.addRow(new Object[]{
                        b.getIdBoleto(),
                        b.getPasajero().getIdPasajero(),
                        b.getVuelo().getId_vuelo(),
                        b.getAsiento().getIdAsiento(),
                        b.getFecha().format(
                            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
                        ),
                        b.getPrecioBase(),
                        servicios
                    });
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(
                    null,
                    "El ID del boleto debe ser un número válido.",
                    "Buscar Boleto",
                    JOptionPane.WARNING_MESSAGE
                );
            }

        } else {
            JOptionPane.showMessageDialog(
                null,
                "El campo de ID Boleto no debe estar vacío.",
                "Buscar Boleto",
                JOptionPane.WARNING_MESSAGE
            );
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaBoletos;
    private javax.swing.JTextField txtBoleto;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtPuertaEmbarque;
    // End of variables declaration//GEN-END:variables
}
