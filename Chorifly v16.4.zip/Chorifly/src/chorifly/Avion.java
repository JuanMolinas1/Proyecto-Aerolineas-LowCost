package chorifly;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Avion {
    private String idAvion;
    private String modelo;
    private int capacidad;
    private ArrayList<Asiento> asientos = new ArrayList<>();

    public Avion() {
        
    }

    public String getIdAvion() {
        return idAvion;
    }

    public void setIdAvion(String idAvion) {
        this.idAvion = idAvion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public ArrayList<Asiento> getAsientos() {
        return asientos;
    }

    public void setAsientos(ArrayList<Asiento> asientos) {
        this.asientos = asientos;
    }
    
    public void mostrarAvion() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Avión --"
                + "\nID Avión: " + idAvion
                + "\nModelo: " + modelo
                + "\nCapacidad: " + capacidad,
                "Información del Avión",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
    
    public void agregarAsiento(Asiento a) {
        asientos.add(a);
    }
}
