package chorifly;

import javax.swing.JOptionPane;

public class Pago {
    private int idPago;
    private Pasajero pasajero;
    private Boleto boleto;
    private String estado;
    private double costoServicios;
    private double costoTotal;

    public Pago() {
        
    }
    
    public Pago(Pasajero pasajero, Boleto boleto, String estado) {
        this.pasajero = pasajero;
        this.boleto = boleto;
        this.estado = estado;
        this.costoServicios = boleto.CalcularPrecioServicios();
        this.costoTotal = boleto.CalcularPrecioTotal();
    }

    public int getIdPago() {
        return idPago;
    }

    public void setIdPago(int idPago) {
        this.idPago = idPago;
    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public Boleto getBoleto() {
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public double getCostoServicios() {
        return costoServicios;
    }

    public void setCostoServicios(double costoServicios) {
        this.costoServicios = costoServicios;
    }

    public double getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(double costoTotal) {
        this.costoTotal = costoTotal;
    }
    
    public void mostrarPago() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Pago --"
                + "\nID Pago: " + idPago
                + "\nEstado: " + estado
                + "\nCosto servicios: $" + costoServicios
                + "\nCosto total: $" + costoTotal,
                "Información del Pago",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
