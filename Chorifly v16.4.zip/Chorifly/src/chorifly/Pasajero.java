package chorifly;

import java.time.LocalDate;
import javax.swing.JOptionPane;

public class Pasajero extends Persona{
    private int idPasajero;
    private LocalDate fechaNacimiento;
    private String nroPasaporte;
    private String paisEmision;
    private LocalDate vencimientoPasaporte;

    public Pasajero() {
        
    }
    
    public Pasajero(LocalDate fechaNacimiento, String nroPasaporte, String paisEmision, LocalDate vencimientoPasaporte, String nombre, String apellido, String dni, String telefono) {
        super(nombre, apellido, dni, telefono);
        this.fechaNacimiento = fechaNacimiento;
        this.nroPasaporte = nroPasaporte;
        this.paisEmision = paisEmision;
        this.vencimientoPasaporte = vencimientoPasaporte;
    }

    public int getIdPasajero() {
        return idPasajero;
    }

    public void setIdPasajero(int idPasajero) {
        this.idPasajero = idPasajero;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getNroPasaporte() {
        return nroPasaporte;
    }

    public void setNroPasaporte(String nroPasaporte) {
        this.nroPasaporte = nroPasaporte;
    }

    public String getPaisEmision() {
        return paisEmision;
    }

    public void setPaisEmision(String paisEmision) {
        this.paisEmision = paisEmision;
    }

    public LocalDate getVencimientoPasaporte() {
        return vencimientoPasaporte;
    }

    public void setVencimientoPasaporte(LocalDate vencimientoPasaporte) {
        this.vencimientoPasaporte = vencimientoPasaporte;
    }
    
    @Override
        public void mostrarPersona() {
            JOptionPane.showMessageDialog(null,
                    "-- Mostrar : Pasajero --"
                    + "\nNombre: " + super.getNombre()
                    + "\nApellido: " + super.getApellido()
                    + "\nDNI: " + super.getDni()
                    + "\nTelefono: " + super.getTelefono()
                    + "\nID Pasajero: " + idPasajero
                    + "\nFecha de nacimiento: " + fechaNacimiento
                    + "\nNro. Pasaporte: " + nroPasaporte
                    + "\nPais de emisión: " + paisEmision
                    + "\nVencimiento del pasaporte: " + vencimientoPasaporte,
                    "Información del Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);
        }
}
