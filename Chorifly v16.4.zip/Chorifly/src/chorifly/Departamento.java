package chorifly;

import javax.swing.JOptionPane;

public class Departamento {
    private int idDepartamento;
    private String nombre;
    private String tipo;

    public Departamento() {
    }

    public int getIdDepartamento() {
        return idDepartamento;
    }

    public void setIdDepartamento(int idDepartamento) {
        this.idDepartamento = idDepartamento;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public void mostrarDepartamento() {
        JOptionPane.showMessageDialog(null, "-- Mostrar : Departamento --"
                + "\nID Departamento: " + idDepartamento
                + "\nNombre: " + nombre
                + "\nTipo: " + tipo,
                "Información del Departamento",
                JOptionPane.INFORMATION_MESSAGE);
    }
}