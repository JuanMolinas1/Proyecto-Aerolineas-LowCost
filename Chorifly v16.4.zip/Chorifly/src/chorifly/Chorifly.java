package chorifly;

import java.sql.Connection;

public class Chorifly {

    public static void main(String[] args) {
        com.formdev.flatlaf.FlatLightLaf.setup();
        
        Aerolinea chorifly = new Aerolinea("Chorily Airlines");
        Connection con = ConexionSQL.conectar();
        
        if (con != null) {
            System.out.println("Conexión Exitosa.");
        } else {
            System.out.println("Error de Conexión.");
        }
        
        VentanaInicioSesion ventana = new VentanaInicioSesion();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
}