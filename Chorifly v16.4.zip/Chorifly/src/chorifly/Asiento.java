package chorifly;

import javax.swing.JOptionPane;

public class Asiento {
    private String idAsiento;
    private String codigo;
    private Avion avion;
    private String tipo;
    private boolean disponible;

    public Asiento() {
        
    }

    public String getIdAsiento() {
        return idAsiento;
    }

    public void setIdAsiento(String idAsiento) {
        this.idAsiento = idAsiento;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Avion getAvion() {
        return avion;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
    
    public void mostrarAsiento() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Asiento --"
                + "\nID Asiento: " + idAsiento
                + "\nCódigo: " + codigo
                + "\nAvión: " + avion.getIdAvion()
                + "\nTipo: " + tipo
                + "\nDisponible: " + (disponible ? "Sí" : "No"),
                "Información del Asiento",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
