package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PagoDAO {

    public void insertPago(PreparedStatement sentencia_sql, Pago p) throws SQLException {
        sentencia_sql.setInt(1, p.getPasajero().getIdPasajero());
        sentencia_sql.setInt(2, p.getBoleto().getIdBoleto());
        sentencia_sql.setDouble(3, p.getCostoServicios());
        sentencia_sql.setDouble(4, p.getCostoTotal());
        sentencia_sql.setString(5, p.getEstado());
    }

    public Pago selectPago(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        Pago p = new Pago();

        p.setIdPago(resultado.getInt("IDPago"));
        p.setCostoServicios(resultado.getDouble("costo_servicios"));
        p.setCostoTotal(resultado.getDouble("costo_total"));
        p.setEstado(resultado.getString("estado"));

        int idPasajero = resultado.getInt("pasajero_id");
        Pasajero pasajero = exDAO.buscarPasajeroPorId(idPasajero);
        p.setPasajero(pasajero);

        int idBoleto = resultado.getInt("boleto_id");
        Boleto boleto = exDAO.buscarBoletoPorId(idBoleto);
        p.setBoleto(boleto);

        return p;
    }

    public void agregarPago(Pago p) {
        String consulta_sql = "INSERT INTO Pago (pasajero_id, boleto_id, costo_servicios, costo_total, estado) VALUES (?, ?, ?, ?, ?)";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            insertPago(sentencia_sql, p);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Pago Guardado Exitosamente",
                    "Creación de Pago",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Pago",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public ArrayList<Pago> mostrarPago() {
        ArrayList<Pago> pagos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Pago";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                pagos.add(selectPago(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Pagos",
                    JOptionPane.ERROR_MESSAGE);
        }
        return pagos;
    }

    public ArrayList<Pago> buscarPago(int id) {
        ArrayList<Pago> pagos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Pago WHERE IDPago = ?";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                pagos.add(selectPago(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un pago con el ID: " + id,
                    "Buscar Pago",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Pago",
                    JOptionPane.ERROR_MESSAGE);
        }
        return pagos;
    }

    public void editarPago(Pago p) {
        String consulta_sql = "UPDATE Pago SET pasajero_id = ?, boleto_id = ?, costo_servicios = ?, costo_total = ?, estado = ? WHERE IDPago = ?";

       try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            insertPago(sentencia_sql, p);
            sentencia_sql.setInt(6, p.getIdPago());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Pago Actualizado Exitosamente",
                    "Edición de Pago",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Pago",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void eliminarPago(int id) {
        String consulta_sql = "DELETE FROM Pago WHERE IDPago = ?";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Pago Eliminar Exitosamente",
                    "Eliminar Pago",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar Pago",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}