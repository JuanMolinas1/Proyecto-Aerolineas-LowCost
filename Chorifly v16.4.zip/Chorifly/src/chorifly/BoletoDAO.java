package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class BoletoDAO {

    public void insertBoleto(PreparedStatement sentencia_sql, Boleto b) throws SQLException {
        sentencia_sql.setInt(1, b.getPasajero().getIdPasajero());
        sentencia_sql.setInt(2, b.getVuelo().getId_vuelo());
        sentencia_sql.setString(3, b.getAsiento().getIdAsiento());
        sentencia_sql.setObject(4, b.getFecha());
        sentencia_sql.setDouble(5, b.getPrecioBase());
    }

    public Boleto selectBoleto(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        VueloDAO vDAO = new VueloDAO();
        Boleto b = new Boleto();

        b.setIdBoleto(resultado.getInt("IDBoleto"));
        b.setFecha(resultado.getTimestamp("fecha").toLocalDateTime());
        b.setPrecioBase(resultado.getDouble("precio_base"));

        int idPasajero = resultado.getInt("pasajero_id");
        b.setPasajero(exDAO.buscarPasajeroPorId(idPasajero));

        int idVuelo = resultado.getInt("vuelo_id");
        b.setVuelo(vDAO.buscarVuelo(idVuelo).get(0));

        Asiento asiento = new Asiento();
        asiento.setIdAsiento(resultado.getString("asiento_id"));
        b.setAsiento(asiento);

        return b;
    }

    public void agregarBoleto(Boleto b) {
        String consulta_sql = "INSERT INTO Boleto (pasajero_id, vuelo_id, asiento_id, fecha, precio_base) VALUES (?, ?, ?, ?, ?)";

       try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            insertBoleto(sentencia_sql, b);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Boleto Guardado Exitosamente",
                    "Creación de Boleto",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Boleto",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public ArrayList<Boleto> mostrarBoleto() {
        ArrayList<Boleto> boletos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Boleto";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                boletos.add(selectBoleto(resultado));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Boletos",
                    JOptionPane.ERROR_MESSAGE);
        }
        return boletos;
    }

    public ArrayList<Boleto> buscarBoleto(int id) {
        ArrayList<Boleto> boletos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Boleto WHERE IDBoleto = ?";

      try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()) {
                boletos.add(selectBoleto(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un boleto con el ID: " + id,
                    "Buscar Boleto",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Boleto",
                    JOptionPane.ERROR_MESSAGE);
        }
        return boletos;
    }

    public void editarBoleto(Boleto b) {
        String consulta_sql = "UPDATE Boleto SET pasajero_id = ?, vuelo_id = ?, asiento_id = ?, fecha = ?, precio_base = ? WHERE IDBoleto = ?";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            insertBoleto(sentencia_sql, b);
            sentencia_sql.setInt(6, b.getIdBoleto());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Boleto Actualizado Exitosamente",
                    "Edición de Boleto",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Boleto",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void eliminarBoleto(int id) {
        String consulta_sql = "DELETE FROM Boleto WHERE IDBoleto = ?";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Boleto Eliminado Exitosamente",
                    "Eliminar Boleto",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar Boleto",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}