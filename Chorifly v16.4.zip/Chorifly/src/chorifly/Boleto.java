package chorifly;

import java.time.LocalDateTime;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Boleto {
    private int idBoleto;
    private Pasajero pasajero;
    private Vuelo vuelo;
    private Asiento asiento;
    private LocalDateTime fecha;
    private double precioBase;
    private ArrayList<Servicio> servicios = new ArrayList<>();

    public Boleto(){
        
    }
    
    public Boleto(Pasajero pasajero, Vuelo vuelo, Asiento asiento, double precioBase) {
        this.pasajero = pasajero;
        this.vuelo = vuelo;
        this.asiento = asiento;
        this.fecha = vuelo.getFechaHoraSalida();
        this.precioBase = precioBase;
    }

    public int getIdBoleto() {
        return idBoleto;
    }

    public void setIdBoleto(int idBoleto) {
        this.idBoleto = idBoleto;
    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public Asiento getAsiento() {
        return asiento;
    }

    public void setAsiento(Asiento asiento) {
        this.asiento = asiento;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public ArrayList<Servicio> getServicios() {
        return servicios;
    }

    public void setServicios(ArrayList<Servicio> servicios) {
        this.servicios = servicios;
    }
    
    public double CalcularPrecioServicios() {
        double precio_total = 0;
        for (Servicio s : servicios) {
            precio_total += s.getPrecio();
        }
        return precio_total;
    }
    
    public double CalcularPrecioTotal() {
        return precioBase + CalcularPrecioServicios();
    }
    
    public void mostrarBoleto() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Boleto --"
                + "\nID Boleto: " + idBoleto
                + "\nVuelo: " + vuelo.getId_vuelo()
                + "\nAsiento: " + asiento.getIdAsiento()
                + "\nFecha: " + fecha
                + "\nPrecio base: $" + precioBase
                + "\nPrecio servicios: $" + CalcularPrecioServicios()
                + "\nPrecio total: $" + CalcularPrecioTotal(),
                "Información del Boleto",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
    
    public void agregarServicio(Servicio s) {
        servicios.add(s);
    }
}
