package chorifly;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class VentanaRecuperarCuenta extends javax.swing.JFrame {

    public VentanaRecuperarCuenta() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtEmailRecuperar = new javax.swing.JTextField();
        btnRecuperar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chorifly - Recuperar Cuenta");

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setBackground(new java.awt.Color(0, 184, 181));
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Recuperar Cuenta");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Email");

        txtEmailRecuperar.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        txtEmailRecuperar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEmailRecuperarKeyPressed(evt);
            }
        });

        btnRecuperar.setBackground(new java.awt.Color(0, 184, 181));
        btnRecuperar.setFont(new java.awt.Font("Tahoma", 1, 25)); // NOI18N
        btnRecuperar.setForeground(new java.awt.Color(255, 255, 255));
        btnRecuperar.setText("Recuperar");
        btnRecuperar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecuperarActionPerformed(evt);
            }
        });

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 25)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 20, Short.MAX_VALUE)
                        .addComponent(btnRecuperar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtEmailRecuperar)))
                .addGap(40, 40, 40))
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(txtEmailRecuperar))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRecuperar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaInicioSesion inicioSesion = new VentanaInicioSesion();
        inicioSesion.setVisible(true);
        inicioSesion.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnRecuperarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecuperarActionPerformed
        recuperarCuenta();
    }//GEN-LAST:event_btnRecuperarActionPerformed

    private void txtEmailRecuperarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEmailRecuperarKeyPressed
        if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
            recuperarCuenta();
        }
    }//GEN-LAST:event_txtEmailRecuperarKeyPressed

    private void recuperarCuenta() {
        UsuarioDAO udao = new UsuarioDAO();
        ArrayList<Usuario> empleados = udao.buscarUsuarioEmpleado();
        Usuario guardarUsuario = null;
        int intentosRestantes = 3;

        String emailIngresado = txtEmailRecuperar.getText().trim();

        for (Usuario u : empleados) {
            if (u.getEmail().equals(emailIngresado)) {
                guardarUsuario = u;
                break;
            }
        }

        if (guardarUsuario != null) {
            while (intentosRestantes > 0) {
                String respuesta = JOptionPane.showInputDialog(
                        null, 
                        guardarUsuario.getPreguntaSeguridad() + "\n(Intentos restantes: " + intentosRestantes + ")", 
                        "Recuperar Cuenta", 
                        JOptionPane.QUESTION_MESSAGE
                );

                if (respuesta == null) { 
                    return; 
                }

                if (respuesta.trim().equalsIgnoreCase(guardarUsuario.getRespuestaSeguridad().trim())) {
                    VentanaRecuperarContraseña recuperarContraseña = new VentanaRecuperarContraseña(guardarUsuario);
                    recuperarContraseña.setVisible(true);
                    recuperarContraseña.setLocationRelativeTo(null);
                    this.dispose();
                    return;

                } else {
                    intentosRestantes--;

                    if (intentosRestantes > 0) {
                        JOptionPane.showMessageDialog(
                                null,
                                "La respuesta de seguridad es incorrecta."
                                + "\nIntentos Restantes: " + intentosRestantes,
                                "Recuperar Cuenta",
                                JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
            JOptionPane.showMessageDialog(
                    null,
                    "Sin intentos restantes."
                    + "\nCerrando Programa...",
                    "Recuperar Cuenta",
                    JOptionPane.ERROR_MESSAGE);
            System.exit(0);

        } else {
            JOptionPane.showMessageDialog(
                    null,
                    "No se encontró ese email.",
                    "Recuperar Cuenta",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRecuperar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtEmailRecuperar;
    // End of variables declaration//GEN-END:variables
}
