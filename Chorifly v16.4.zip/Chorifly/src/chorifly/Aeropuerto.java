package chorifly;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Aeropuerto {
    private int idAeropuerto;
    private String nombre;
    private String pais;
    private String ciudad;
    private ArrayList<Empleado> empleados = new ArrayList<>();

    public Aeropuerto() {
        
    }

    public int getIdAeropuerto() {
        return idAeropuerto;
    }

    public void setId_aeropuerto(int idAeropuerto) {
        this.idAeropuerto = idAeropuerto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Empleado> empleados) {
        this.empleados = empleados;
    }
    
    public void mostrarAeropuerto() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Aeropuerto --"
                + "\nID Aeropuerto: " + idAeropuerto
                + "\nNombre: " + nombre
                + "\nPaís: " + pais
                + "\nCiudad: " + ciudad,
                "Información del Aeropuerto",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
    
    public void agregarEmpleado(Empleado e) {
        empleados.add(e);
    }
}
