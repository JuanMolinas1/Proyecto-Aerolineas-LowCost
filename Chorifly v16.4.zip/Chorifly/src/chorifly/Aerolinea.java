package chorifly;

import java.util.ArrayList;

public class Aerolinea {
    private String nombre;
    private ArrayList<Persona>      empleados     = new ArrayList<>();
    private ArrayList<Persona>      pasajeros     = new ArrayList<>();
    private ArrayList<Departamento> departamentos = new ArrayList<>();
    private ArrayList<Usuario>      usuarios      = new ArrayList<>();
    private ArrayList<Aeropuerto>   aeropuertos   = new ArrayList<>();
    private ArrayList<Avion>        aviones       = new ArrayList<>();
    private ArrayList<Asiento>      asientos      = new ArrayList<>();
    private ArrayList<Boleto>       boletos       = new ArrayList<>();
    private ArrayList<Servicio>     servicios     = new ArrayList<>();
    private ArrayList<Pago>         pagos         = new ArrayList<>();
    private ArrayList<CheckIn>      checkins      = new ArrayList<>();

    public Aerolinea(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Persona> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(ArrayList<Persona> empleados) {
        this.empleados = empleados;
    }

    public ArrayList<Persona> getPasajeros() {
        return pasajeros;
    }

    public void setPasajeros(ArrayList<Persona> pasajeros) {
        this.pasajeros = pasajeros;
    }

    public ArrayList<Departamento> getDepartamentos() {
        return departamentos;
    }

    public void setDepartamentos(ArrayList<Departamento> departamentos) {
        this.departamentos = departamentos;
    }

    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(ArrayList<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    public ArrayList<Aeropuerto> getAeropuertos() {
        return aeropuertos;
    }

    public void setAeropuertos(ArrayList<Aeropuerto> aeropuertos) {
        this.aeropuertos = aeropuertos;
    }

    public ArrayList<Avion> getAviones() {
        return aviones;
    }

    public void setAviones(ArrayList<Avion> aviones) {
        this.aviones = aviones;
    }

    public ArrayList<Asiento> getAsientos() {
        return asientos;
    }

    public void setAsientos(ArrayList<Asiento> asientos) {
        this.asientos = asientos;
    }

    public ArrayList<Boleto> getBoletos() {
        return boletos;
    }

    public void setBoletos(ArrayList<Boleto> boletos) {
        this.boletos = boletos;
    }

    public ArrayList<Servicio> getServicios() {
        return servicios;
    }

    public void setServicios(ArrayList<Servicio> servicios) {
        this.servicios = servicios;
    }

    public ArrayList<Pago> getPagos() {
        return pagos;
    }

    public void setPagos(ArrayList<Pago> pagos) {
        this.pagos = pagos;
    }

    public ArrayList<CheckIn> getCheckins() {
        return checkins;
    }

    public void setCheckins(ArrayList<CheckIn> checkins) {
        this.checkins = checkins;
    }

    public void agregarEmpleado(Persona p) {
        empleados.add(p);
    }

    public void agregarPasajero(Persona p) {
        pasajeros.add(p);
    }

    public void agregarDepartamento(Departamento d) {
        departamentos.add(d);
    }

    public void agregarUsuario(Usuario u) {
        usuarios.add(u);
    }

    public void agregarAeropuerto(Aeropuerto a) {
        aeropuertos.add(a);
    }

    public void agregarAvion(Avion a) {
        aviones.add(a);
    }

    public void agregarAsiento(Asiento a) {
        asientos.add(a);
    }

    public void agregarBoleto(Boleto b) {
        boletos.add(b);
    }

    public void agregarServicio(Servicio s) {
        servicios.add(s);
    }

    public void agregarPago(Pago p) {
        pagos.add(p);
    }

    public void agregarCheckIn(CheckIn c) {
        checkins.add(c);
    }
}
