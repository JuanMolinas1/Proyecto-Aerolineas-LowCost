package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AsientoDAO {

    public Asiento selectAsiento(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        Asiento a = new Asiento();

        a.setIdAsiento(resultado.getString("IDAsiento"));
        a.setCodigo(resultado.getString("codigo"));
        a.setTipo(resultado.getString("tipo"));
        a.setDisponible(resultado.getBoolean("disponible"));

        String idAvion = resultado.getString("avion_id");
        a.setAvion(exDAO.buscarAvionPorId(idAvion));

        return a;
    }

    public ArrayList<Asiento> mostrarAsiento() {
        ArrayList<Asiento> asientos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Asientos()}";

       try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                asientos.add(selectAsiento(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Asientos",
                    JOptionPane.ERROR_MESSAGE);
        }
        return asientos;
    }

    public ArrayList<Asiento> buscarAsiento(boolean disponible) {
        ArrayList<Asiento> asientos = new ArrayList<>();
        String consulta_sql = "{CALL Buscar_Asientos_Por_Disponibilidad(?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            sentencia_sql.setBoolean(1, disponible);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                asientos.add(selectAsiento(resultado));
            }

            if (asientos.isEmpty()) {
                JOptionPane.showMessageDialog(
                    null,
                    "No existen asientos con disponibilidad: " + disponible,
                    "Buscar Asientos",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Asientos",
                    JOptionPane.ERROR_MESSAGE);
        }
        return asientos;
    }

    public void editarAsiento(Asiento a) {
        String consulta_sql = "{CALL Editar_Asiento(?, ?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setBoolean(1, a.isDisponible());
            sentencia_sql.setString(2, a.getIdAsiento());

            sentencia_sql.executeUpdate();

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Asiento",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void ocuparAsiento(Asiento a) {
        String consulta_sql = "{CALL Ocupar_Asiento(?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setString(1, a.getIdAsiento());

            sentencia_sql.executeUpdate();

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Asiento",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void liberarAsiento(Asiento a) {
        String consulta_sql = "{CALL Liberar_Asiento(?)}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);) {

            sentencia_sql.setString(1, a.getIdAsiento());

            sentencia_sql.executeUpdate();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Asiento",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}