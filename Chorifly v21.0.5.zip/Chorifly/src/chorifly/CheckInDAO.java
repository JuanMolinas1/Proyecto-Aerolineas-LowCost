package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CheckInDAO {

    public void insertCheckIn(PreparedStatement sentencia_sql, CheckIn c) throws SQLException {
        sentencia_sql.setInt(1, c.getPasajero().getIdPasajero());
        sentencia_sql.setInt(2, c.getBoleto().getIdBoleto());
        sentencia_sql.setInt(3, c.getVuelo().getIdVuelo());
        sentencia_sql.setInt(4, c.getPago().getIdPago());
        sentencia_sql.setString(5, c.getPuertaEmbarque());
    }

    public CheckIn selectCheckIn(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        VueloDAO vDAO = new VueloDAO();
        PasajeroDAO pjdao = new PasajeroDAO();
        BoletoDAO bdao = new BoletoDAO();
        PagoDAO pdao = new PagoDAO();
        CheckIn c = new CheckIn();

        c.setIdCheckin(resultado.getInt("IDCheckin"));
        c.setPuertaEmbarque(resultado.getString("puerta_embarque"));

        int idPasajero = resultado.getInt("pasajero_id");
        c.setPasajero(pjdao.buscarPasajero(idPasajero).get(0));

        int idBoleto = resultado.getInt("boleto_id");
        c.setBoleto(bdao.buscarBoleto(idBoleto).get(0));

        int idVuelo = resultado.getInt("vuelo_id");
        c.setVuelo(vDAO.buscarVuelo(idVuelo).get(0));

        int idPago = resultado.getInt("pago_id");
        c.setPago(pdao.buscarPago(idPago).get(0));

        return c;
    }

    public void agregarCheckIn(CheckIn c) {
        String consulta_sql = "{CALL Agregar_CheckIn(?, ?, ?, ?, ?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            insertCheckIn(sentencia_sql, c);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "CheckIn Guardado Exitosamente",
                    "Creación de CheckIn",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public ArrayList<CheckIn> mostrarCheckIn() {
        ArrayList<CheckIn> checkins = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_CheckIns()}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                checkins.add(selectCheckIn(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de CheckIns",
                    JOptionPane.ERROR_MESSAGE);
        }
        return checkins;
    }

    public ArrayList<CheckIn> buscarCheckIn(int id) {
        ArrayList<CheckIn> checkins = new ArrayList<>();
        String consulta_sql = "{CALL Buscar_CheckIn_Por_Id(?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                checkins.add(selectCheckIn(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un CheckIn con el ID: " + id,
                    "Buscar CheckIn",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
        return checkins;
    }

    public void editarCheckIn(CheckIn c) {
        String consulta_sql = "{CALL Editar_CheckIn(?, ?, ?, ?, ?, ?)}";

        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){
            insertCheckIn(sentencia_sql, c);
            sentencia_sql.setInt(6, c.getIdCheckin());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "CheckIn Actualizado Exitosamente",
                    "Edición de CheckIn",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void eliminarCheckIn(int id) {
        String consulta_sql = "{CALL Eliminar_CheckIn(?)}";
        try (Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);){

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "CheckIn Eliminado Exitosamente",
                    "Eliminar CheckIn",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}