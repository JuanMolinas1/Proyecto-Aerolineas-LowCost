package chorifly;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ConexionSQL {
    private static final String URL      = "jdbc:mysql://localhost:3306/Chorifly";
    private static final String USER     = "root";
    private static final String PASSWORD = "";

    public static Connection conectar(){
        try {
            Connection conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            return conexion;
        } catch (SQLException ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }
}
