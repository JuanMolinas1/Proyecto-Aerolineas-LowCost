package chorifly;

import java.time.LocalDateTime;
import javax.swing.JOptionPane;

public class Vuelo {
    private int id_vuelo;
    private Avion avionUsado;
    private Aeropuerto aeropuertoOrigen;
    private Aeropuerto aeropuertoDestino;
    private LocalDateTime fechaHoraSalida;
    private LocalDateTime fechaHoraLlegada;
    private String estado;

    public Vuelo(Avion avionUsado, Aeropuerto aeropuertoOrigen, Aeropuerto aeropuertoDestino, LocalDateTime fechaHoraSalida, LocalDateTime fechaHoraLlegada, String estado) {
        this.avionUsado = avionUsado;
        this.aeropuertoOrigen = aeropuertoOrigen;
        this.aeropuertoDestino = aeropuertoDestino;
        this.fechaHoraSalida = fechaHoraSalida;
        this.fechaHoraLlegada = fechaHoraLlegada;
        this.estado = estado;
    }

    public int getId_vuelo() {
        return id_vuelo;
    }

    public void setId_vuelo(int id_vuelo) {
        this.id_vuelo = id_vuelo;
    }

    public Avion getAvionUsado() {
        return avionUsado;
    }

    public void setAvionUsado(Avion avionUsado) {
        this.avionUsado = avionUsado;
    }

    public Aeropuerto getAeropuertoOrigen() {
        return aeropuertoOrigen;
    }

    public void setAeropuertoOrigen(Aeropuerto aeropuertoOrigen) {
        this.aeropuertoOrigen = aeropuertoOrigen;
    }

    public Aeropuerto getAeropuertoDestino() {
        return aeropuertoDestino;
    }

    public void setAeropuertoDestino(Aeropuerto aeropuertoDestino) {
        this.aeropuertoDestino = aeropuertoDestino;
    }

    public LocalDateTime getFechaHoraSalida() {
        return fechaHoraSalida;
    }

    public void setFechaHoraSalida(LocalDateTime fechaHoraSalida) {
        this.fechaHoraSalida = fechaHoraSalida;
    }

    public LocalDateTime getFechaHoraLlegada() {
        return fechaHoraLlegada;
    }

    public void setFechaHoraLlegada(LocalDateTime fechaHoraLlegada) {
        this.fechaHoraLlegada = fechaHoraLlegada;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public void mostrarVuelo() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Vuelo --"
                + "\nID Vuelo: " + id_vuelo
                + "\nAvión: " + avionUsado.getId_avion()
                + "\nOrigen: " + aeropuertoOrigen.getCiudad()
                + "\nDestino: " + aeropuertoDestino.getCiudad()
                + "\nSalida: " + fechaHoraSalida
                + "\nLlegada: " + fechaHoraLlegada
                + "\nEstado: " + estado,
                "Información del Vuelo",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
