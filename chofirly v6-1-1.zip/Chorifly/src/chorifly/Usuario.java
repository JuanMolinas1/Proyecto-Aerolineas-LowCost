package chorifly;

import javax.swing.JOptionPane;

public class Usuario {
    private int id_usuario;
    private String usuario;
    private String email;
    private String contraseña;
    private boolean privilegios_empleado;

    public Usuario(String usuario, String email, String contraseña, boolean privilegios_empleado) {
        this.usuario = usuario;
        this.email = email;
        this.contraseña = contraseña;
        this.privilegios_empleado = privilegios_empleado;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public boolean isPrivilegios_empleado() {
        return privilegios_empleado;
    }

    public void setPrivilegios_empleado(boolean privilegios_empleado) {
        this.privilegios_empleado = privilegios_empleado;
    }
    
    public void mostrarUsuario() {
        JOptionPane.showMessageDialog(null, "-- Mostrar : Usuario --"
                + "\nID Usuario: " + id_usuario
                + "\nUsuario: " + usuario
                + "\nEmail: " + email
                + "\nContraseña: " + contraseña
                + "\nPrivilegios: " + privilegios_empleado);
    }
}
