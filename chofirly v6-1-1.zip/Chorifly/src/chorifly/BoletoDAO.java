package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class BoletoDAO {
    public void insertarBoleto(Boleto b) {
        String insert_sql = "INSERT INTO Boleto (pasajero_id, vuelo_id, asiento_id, fecha, precio_base) VALUES (?, ?, ?, ?, ?)";
        
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement (insert_sql);
            
            sentencia_sql.setInt(1, b.getPasajero().getId_pasajero());
            sentencia_sql.setInt(2, b.getVuelo().getId_vuelo());
            sentencia_sql.setString(3, b.getAsiento().getId_asiento());
            sentencia_sql.setObject(4, b.getFecha());
            sentencia_sql.setDouble(5, b.getPrecio_base());
            
            sentencia_sql.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    "Boleto Guardado Exitosamente",
                    "Creación de Boleto",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Boleto",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
