package chorifly;

import javax.swing.JOptionPane;

public class Empleado extends Persona{
    private int id_empleado;
    private double sueldo;
    private Departamento departamento;
    private Aeropuerto aeropuertoTrabajo;

    public Empleado(double sueldo, Departamento departamento, String nombre, String apellido, String dni, String telefono) {
        super(nombre, apellido, dni, telefono);
        this.sueldo = sueldo;
        this.departamento = departamento;
    }

    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public Aeropuerto getAeropuertoTrabajo() {
        return aeropuertoTrabajo;
    }

    public void setAeropuertoTrabajo(Aeropuerto aeropuertoTrabajo) {
        this.aeropuertoTrabajo = aeropuertoTrabajo;
    }
    
    @Override
    public void mostrarPersona(){
        JOptionPane.showMessageDialog(null, "-- Mostrar : Empleado --"
                + "\nNombre: " + super.getNombre()
                + "\nApellido: " + super.getApellido()
                + "\nDNI: " + super.getDni()
                + "\nTelefono: " + super.getTelefono()
                + "\nID Empleado: " + id_empleado
                + "\nSueldo: " + sueldo,
                "Información del Empleado",
                JOptionPane.INFORMATION_MESSAGE);
    }
}
