package chorifly;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Avion {
    private String id_avion;
    private String modelo;
    private int capacidad;
    private ArrayList<Asiento> l_asientos = new ArrayList<>();

    public Avion(String modelo, int capacidad) {
        this.modelo = modelo;
        this.capacidad = capacidad;
    }

    public String getId_avion() {
        return id_avion;
    }

    public void setId_avion(String id_avion) {
        this.id_avion = id_avion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public ArrayList<Asiento> getL_asientos() {
        return l_asientos;
    }

    public void setL_asientos(ArrayList<Asiento> l_asientos) {
        this.l_asientos = l_asientos;
    }
    
    public void mostrarAvion() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Avión --"
                + "\nID Avión: " + id_avion
                + "\nModelo: " + modelo
                + "\nCapacidad: " + capacidad,
                "Información del Avión",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
    
    public void agregarAsiento(Asiento a) {
        l_asientos.add(a);
    }
}
