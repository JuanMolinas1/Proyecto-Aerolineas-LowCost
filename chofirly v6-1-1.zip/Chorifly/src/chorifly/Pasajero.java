package chorifly;

import java.time.LocalDate;
import javax.swing.JOptionPane;

public class Pasajero extends Persona{
    private int id_pasajero;
    private LocalDate fecha_nacimiento;
    private String nroPasaporte;
    private String paisEmision;
    private LocalDate vencimientoPasaporte;

    public Pasajero(LocalDate fecha_nacimiento, String nroPasaporte, String paisEmision, LocalDate vencimientoPasaporte, String nombre, String apellido, String dni, String telefono) {
        super(nombre, apellido, dni, telefono);
        this.fecha_nacimiento = fecha_nacimiento;
        this.nroPasaporte = nroPasaporte;
        this.paisEmision = paisEmision;
        this.vencimientoPasaporte = vencimientoPasaporte;
    }

    public int getId_pasajero() {
        return id_pasajero;
    }

    public void setId_pasajero(int id_pasajero) {
        this.id_pasajero = id_pasajero;
    }

    public LocalDate getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(LocalDate fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getNroPasaporte() {
        return nroPasaporte;
    }

    public void setNroPasaporte(String nroPasaporte) {
        this.nroPasaporte = nroPasaporte;
    }

    public String getPaisEmision() {
        return paisEmision;
    }

    public void setPaisEmision(String paisEmision) {
        this.paisEmision = paisEmision;
    }

    public LocalDate getFechaVencimientoPasaporte() {
        return vencimientoPasaporte;
    }

    public void setFechaVencimientoPasaporte(LocalDate vencimientoPasaporte) {
        this.vencimientoPasaporte = vencimientoPasaporte;
    }
    
    @Override
        public void mostrarPersona() {
            JOptionPane.showMessageDialog(null,
                    "-- Mostrar : Pasajero --"
                    + "\nNombre: " + super.getNombre()
                    + "\nApellido: " + super.getApellido()
                    + "\nDNI: " + super.getDni()
                    + "\nTelefono: " + super.getTelefono()
                    + "\nID Pasajero: " + id_pasajero
                    + "\nFecha de nacimiento: " + fecha_nacimiento
                    + "\nNro. Pasaporte: " + nroPasaporte
                    + "\nPais de emisión: " + paisEmision
                    + "\nVencimiento del pasaporte: " + vencimientoPasaporte,
                    "Información del Pasajero",
                    JOptionPane.INFORMATION_MESSAGE);
        }
}
