package chorifly;

import java.util.ArrayList;

public class Aerolinea {
    private String nombre;
    private ArrayList<Persona>      l_empleados     = new ArrayList<>();
    private ArrayList<Persona>      l_pasajeros     = new ArrayList<>();
    private ArrayList<Departamento> l_departamentos = new ArrayList<>();
    private ArrayList<Usuario>      l_usuario       = new ArrayList<>();
    private ArrayList<Aeropuerto>   l_aeropuertos   = new ArrayList<>();
    private ArrayList<Avion>        l_aviones       = new ArrayList<>();
    private ArrayList<Asiento>      l_asiento       = new ArrayList<>();
    private ArrayList<Boleto>       l_boletos       = new ArrayList<>();
    private ArrayList<Servicio>     l_servicios     = new ArrayList<>();
    private ArrayList<Pago>         l_pagos         = new ArrayList<>();
    private ArrayList<CheckIn>      l_checkins      = new ArrayList<>();

    public Aerolinea(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Persona> getL_empleados() {
        return l_empleados;
    }

    public void setL_empleados(ArrayList<Persona> l_empleados) {
        this.l_empleados = l_empleados;
    }

    public ArrayList<Persona> getL_pasajeros() {
        return l_pasajeros;
    }

    public void setL_pasajeros(ArrayList<Persona> l_pasajeros) {
        this.l_pasajeros = l_pasajeros;
    }

    public ArrayList<Departamento> getL_departamentos() {
        return l_departamentos;
    }

    public void setL_departamentos(ArrayList<Departamento> l_departamentos) {
        this.l_departamentos = l_departamentos;
    }

    public ArrayList<Usuario> getL_usuario() {
        return l_usuario;
    }

    public void setL_usuario(ArrayList<Usuario> l_usuario) {
        this.l_usuario = l_usuario;
    }

    public ArrayList<Aeropuerto> getL_aeropuertos() {
        return l_aeropuertos;
    }

    public void setL_aeropuertos(ArrayList<Aeropuerto> l_aeropuertos) {
        this.l_aeropuertos = l_aeropuertos;
    }

    public ArrayList<Avion> getL_aviones() {
        return l_aviones;
    }

    public void setL_aviones(ArrayList<Avion> l_aviones) {
        this.l_aviones = l_aviones;
    }

    public ArrayList<Asiento> getL_asiento() {
        return l_asiento;
    }

    public void setL_asiento(ArrayList<Asiento> l_asiento) {
        this.l_asiento = l_asiento;
    }

    public ArrayList<Boleto> getL_boletos() {
        return l_boletos;
    }

    public void setL_boletos(ArrayList<Boleto> l_boletos) {
        this.l_boletos = l_boletos;
    }

    public ArrayList<Servicio> getL_servicios() {
        return l_servicios;
    }

    public void setL_servicios(ArrayList<Servicio> l_servicios) {
        this.l_servicios = l_servicios;
    }

    public ArrayList<Pago> getL_pagos() {
        return l_pagos;
    }

    public void setL_pagos(ArrayList<Pago> l_pagos) {
        this.l_pagos = l_pagos;
    }

    public ArrayList<CheckIn> getL_checkins() {
        return l_checkins;
    }

    public void setL_checkins(ArrayList<CheckIn> l_checkins) {
        this.l_checkins = l_checkins;
    }
    
    public void agregarEmpleado(Persona p) {
        l_empleados.add(p);
    }

    public void agregarPasajero(Persona p) {
        l_pasajeros.add(p);
    }

    public void agregarDepartamento(Departamento d) {
        l_departamentos.add(d);
    }

    public void agregarUsuario(Usuario u) {
        l_usuario.add(u);
    }

    public void agregarAeropuerto(Aeropuerto a) {
        l_aeropuertos.add(a);
    }

    public void agregarAvion(Avion a) {
        l_aviones.add(a);
    }

    public void agregarAsiento(Asiento a) {
        l_asiento.add(a);
    }

    public void agregarBoleto(Boleto b) {
        l_boletos.add(b);
    }

    public void agregarServicio(Servicio s) {
        l_servicios.add(s);
    }

    public void agregarPago(Pago p) {
        l_pagos.add(p);
    }

    public void agregarCheckIn(CheckIn c) {
        l_checkins.add(c);
    }
}
