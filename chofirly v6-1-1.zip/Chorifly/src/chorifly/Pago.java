package chorifly;

import javax.swing.JOptionPane;

public class Pago {
    private int id_pago;
    private Pasajero pasajero;
    private Boleto boleto;
    private String estado;
    private double costo_servicios;
    private double costo_total;

    public Pago(Pasajero pasajero, Boleto boleto, String estado) {
        this.pasajero = pasajero;
        this.boleto = boleto;
        this.estado = estado;
        this.costo_servicios = boleto.CalcularPrecioServicios();
        this.costo_total = boleto.CalcularPrecioTotal();
    }

    public int getId_pago() {
        return id_pago;
    }

    public void setId_pago(int id_pago) {
        this.id_pago = id_pago;
    }

    public Pasajero getPasajero() {
        return pasajero;
    }

    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public Boleto getBoleto() {
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public double getCosto_servicios() {
        return costo_servicios;
    }

    public void setCosto_servicios(double costo_servicios) {
        this.costo_servicios = costo_servicios;
    }

    public double getCosto_total() {
        return costo_total;
    }

    public void setCosto_total(double costo_total) {
        this.costo_total = costo_total;
    }
    
    public void mostrarPago() {
        JOptionPane.showMessageDialog(
                null,
                "-- Mostrar : Pago --"
                + "\nID Pago: " + id_pago
                + "\nEstado: " + estado
                + "\nCosto servicios: $" + costo_servicios
                + "\nCosto total: $" + costo_total,
                "Información del Pago",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
