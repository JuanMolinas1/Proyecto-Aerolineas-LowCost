package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class BoletoDAO {

    public void insertBoleto(PreparedStatement sentencia_sql, Boleto b) throws SQLException {
        sentencia_sql.setInt(1, b.getPasajero().getIdPasajero());
        sentencia_sql.setInt(2, b.getVuelo().getIdVuelo());
        sentencia_sql.setString(3, b.getAsiento().getIdAsiento());
        sentencia_sql.setTimestamp(4, Timestamp.valueOf(b.getFecha()));
        sentencia_sql.setDouble(5, b.getPrecioBase());
    }

    public Boleto selectBoleto(ResultSet resultado) throws SQLException {
        try (Connection conexion = ConexionSQL.conectar()) {
            return selectBoleto(resultado, conexion);
        }
    }

    private Boleto selectBoleto(ResultSet resultado, Connection conexion) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        VueloDAO vDAO = new VueloDAO();
        PasajeroDAO pdao = new PasajeroDAO();

        Boleto b = new Boleto();

        b.setIdBoleto(resultado.getInt("IDBoleto"));
        b.setFecha(resultado.getTimestamp("fecha").toLocalDateTime());
        b.setPrecioBase(resultado.getDouble("precio_base"));

        int idPasajero = resultado.getInt("pasajero_id");
        b.setPasajero(pdao.buscarPasajero(idPasajero).get(0));

        int idVuelo = resultado.getInt("vuelo_id");
        b.setVuelo(vDAO.buscarVuelo(idVuelo).get(0));

        Asiento asiento = new Asiento();
        asiento.setIdAsiento(resultado.getString("asiento_id"));
        b.setAsiento(asiento);

        cargarBoletoServicio(conexion, b);

        return b;
    }

    private void cargarBoletoServicio(Connection conexion, Boleto b) throws SQLException {
        String consulta_sql = "{CALL Buscar_Servicios_Por_Boleto(?)}";

        try (PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            sentencia_sql.setInt(1, b.getIdBoleto());

            try (ResultSet resultado = sentencia_sql.executeQuery()) {
                while (resultado.next()) {
                    Servicio s = new Servicio();

                    s.setIdServicio(resultado.getInt("IDServicio"));
                    s.setNombreServicio(resultado.getString("nombre_servicio"));
                    s.setPrecio(resultado.getDouble("precio"));
                    s.setDescripcion(resultado.getString("descripcion"));

                    b.agregarServicio(s);
                }
            }
        }
    }

    private void insertarBoletoServicio(Connection conexion, Boleto b) throws SQLException {
        String consulta_sql = "{CALL Insertar_Boleto_Servicio(?, ?)}";

        try (PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
            if (b.getServicios() != null) {
                for (Servicio s : b.getServicios()) {
                    sentencia_sql.setInt(1, b.getIdBoleto());
                    sentencia_sql.setInt(2, s.getIdServicio());
                    sentencia_sql.executeUpdate();
                }
            }
        }
    }

    public void agregarBoleto(Boleto b) {
        String consulta_sql = "{CALL Agregar_Boleto(?, ?, ?, ?, ?, ?)}";

        try (Connection conexion = ConexionSQL.conectar()) {
            conexion.setAutoCommit(false);

            try (PreparedStatement sentencia_sql =
                    conexion.prepareStatement(consulta_sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

                insertBoleto(sentencia_sql, b);
                sentencia_sql.executeUpdate();

                try (ResultSet claves = sentencia_sql.getGeneratedKeys()) {
                    if (claves.next()) {
                        b.setIdBoleto(claves.getInt(6));
                    } else {
                        throw new SQLException("No se pudo obtener el ID del boleto creado.");
                    }
                }

                insertarBoletoServicio(conexion, b);

                conexion.commit();

                JOptionPane.showMessageDialog(
                        null,
                        "Boleto Guardado Exitosamente",
                        "Creación de Boleto",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (SQLException ex) {
                conexion.rollback();
                throw ex;
            } finally {
                conexion.setAutoCommit(true);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error " + ex.getMessage(),
                    "Creación de Boleto",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public ArrayList<Boleto> mostrarBoleto() {
        ArrayList<Boleto> boletos = new ArrayList<>();
        String consulta_sql = "{CALL Mostrar_Boletos()}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
             ResultSet resultado = sentencia_sql.executeQuery()) {

            while (resultado.next()) {
                boletos.add(selectBoleto(resultado, conexion));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error " + ex.getMessage(),
                    "Listado de Boletos",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        return boletos;
    }

    public ArrayList<Boleto> buscarBoleto(int id) {
        ArrayList<Boleto> boletos = new ArrayList<>();
        String consulta_sql = "{CALL Buscar_Boleto_Por_Id(?)}";

        try (Connection conexion = ConexionSQL.conectar();
             PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {

            sentencia_sql.setInt(1, id);

            try (ResultSet resultado = sentencia_sql.executeQuery()) {
                if (resultado.next()) {
                    boletos.add(selectBoleto(resultado, conexion));
                } else {
                    JOptionPane.showMessageDialog(
                            null,
                            "No existe un boleto con el ID: " + id,
                            "Buscar Boleto",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error " + ex.getMessage(),
                    "Buscar Boleto",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        return boletos;
    }

    public void editarBoleto(Boleto b) {
        String consulta_sql = "{CALL Editar_Boleto(?, ?, ?, ?, ?, ?)}";

        try (Connection conexion = ConexionSQL.conectar()) {
            conexion.setAutoCommit(false);

            try (PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql)) {
                insertBoleto(sentencia_sql, b);
                sentencia_sql.setInt(6, b.getIdBoleto());

                int filasActualizadas = sentencia_sql.executeUpdate();

                if (filasActualizadas == 0) {
                    throw new SQLException("No existe un boleto con el ID: " + b.getIdBoleto());
                }

                String eliminar_relaciones = "{CALL Eliminar_Servicios_De_Boleto(?)}";

                try (PreparedStatement sentenciaEliminar =
                        conexion.prepareStatement(eliminar_relaciones)) {
                    sentenciaEliminar.setInt(1, b.getIdBoleto());
                    sentenciaEliminar.executeUpdate();
                }

                insertarBoletoServicio(conexion, b);

                conexion.commit();

                JOptionPane.showMessageDialog(
                        null,
                        "Boleto Actualizado Exitosamente",
                        "Edición de Boleto",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (SQLException ex) {
                conexion.rollback();
                throw ex;
            } finally {
                conexion.setAutoCommit(true);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error " + ex.getMessage(),
                    "Edición de Boleto",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public void eliminarBoleto(int id) {
        String eliminar_relaciones = "{CALL Eliminar_Servicios_De_Boleto(?)}";
        String eliminar_boleto = "{CALL Eliminar_Boleto(?)}";

        try (Connection conexion = ConexionSQL.conectar()) {
            conexion.setAutoCommit(false);

            try {
                try (PreparedStatement sentencia_sql =
                        conexion.prepareStatement(eliminar_relaciones)) {
                    sentencia_sql.setInt(1, id);
                    sentencia_sql.executeUpdate();
                }

                try (PreparedStatement sentencia_sql =
                        conexion.prepareStatement(eliminar_boleto)) {
                    sentencia_sql.setInt(1, id);

                    int filasEliminadas = sentencia_sql.executeUpdate();

                    if (filasEliminadas == 0) {
                        throw new SQLException("No existe un boleto con el ID: " + id);
                    }
                }

                conexion.commit();

                JOptionPane.showMessageDialog(
                        null,
                        "Boleto Eliminado Exitosamente",
                        "Eliminar Boleto",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (SQLException ex) {
                conexion.rollback();
                throw ex;
            } finally {
                conexion.setAutoCommit(true);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error " + ex.getMessage(),
                    "Eliminar Boleto",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    public void editarBoletoServicio(Boleto b) {
        String eliminar_relaciones = "{CALL Eliminar_Servicios_De_Boleto(?)}";

        try (Connection conexion = ConexionSQL.conectar()) {
            conexion.setAutoCommit(false);

            try (PreparedStatement sentenciaEliminar =
                    conexion.prepareStatement(eliminar_relaciones)) {

                sentenciaEliminar.setInt(1, b.getIdBoleto());
                sentenciaEliminar.executeUpdate();

                insertarBoletoServicio(conexion, b);

                conexion.commit();

                JOptionPane.showMessageDialog(
                        null,
                        "Servicios del boleto actualizados correctamente.",
                        "Edición de Servicios",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (SQLException ex) {
                conexion.rollback();
                throw ex;
            } finally {
                conexion.setAutoCommit(true);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error " + ex.getMessage(),
                    "Edición de Servicios",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}