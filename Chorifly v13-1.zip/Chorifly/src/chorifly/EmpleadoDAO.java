package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class EmpleadoDAO {

    public void insertEmpleado(PreparedStatement sentencia_sql, Empleado e) throws SQLException {
        sentencia_sql.setString(1, e.getNombre());
        sentencia_sql.setString(2, e.getApellido());
        sentencia_sql.setString(3, e.getDni());
        sentencia_sql.setDouble(4, e.getSueldo());
        sentencia_sql.setInt(5, e.getDepartamento().getId_departamento());
        sentencia_sql.setInt(6, e.getAeropuertoTrabajo().getId_aeropuerto());
        sentencia_sql.setInt(7, e.getUsuario().getId_usuario());
    }

    public Empleado selectEmpleado(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        Empleado e = new Empleado();

        e.setId_empleado(resultado.getInt("IDEmpleado"));
        e.setNombre(resultado.getString("nombre_empleado"));
        e.setApellido(resultado.getString("apellido_empleado"));
        e.setDni(resultado.getString("dni_empleado"));
        e.setSueldo(resultado.getDouble("sueldo"));

        int idDepartamento = resultado.getInt("departamento_id");
        e.setDepartamento(exDAO.buscarDepartamentoPorId(idDepartamento));

        int idAeropuerto = resultado.getInt("aeropuerto_id");
        e.setAeropuertoTrabajo(exDAO.buscarAeropuertoPorId(idAeropuerto));

        int idUsuario = resultado.getInt("usuario_id");
        e.setUsuario(exDAO.buscarUsuarioPorId(idUsuario));

        return e;
    }

    public void agregarEmpleado(Empleado e) {
        String consulta_sql = "INSERT INTO Empleado (nombre_empleado, apellido_empleado, dni_empleado, sueldo, departamento_id, aeropuerto_id, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertEmpleado(sentencia_sql, e);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Empleado Guardado Exitosamente",
                    "Creación de Empleado",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public ArrayList<Empleado> mostrarEmpleado() {
        ArrayList<Empleado> l_empleados = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Empleado";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                l_empleados.add(selectEmpleado(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Empleados",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_empleados;
    }

    public ArrayList<Empleado> buscarEmpleado(int id) {
        ArrayList<Empleado> l_empleados = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Empleado WHERE IDEmpleado = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                l_empleados.add(selectEmpleado(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un empleado con el ID: " + id,
                    "Buscar Empleado",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_empleados;
    }

    public void editarEmpleado(Empleado e) {
        String consulta_sql = "UPDATE Empleado SET nombre_empleado = ?, apellido_empleado = ?, dni_empleado = ?, sueldo = ?, departamento_id = ?, aeropuerto_id = ?, usuario_id = ? WHERE IDEmpleado = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertEmpleado(sentencia_sql, e);
            sentencia_sql.setInt(8, e.getId_empleado());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Empleado Actualizado Exitosamente",
                    "Edición de Empleado",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void eliminarEmpleado(int id) {
        String consulta_sql = "DELETE FROM Empleado WHERE IDEmpleado = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Empleado Eliminado Exitosamente",
                    "Eliminar Empleado",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar Empleado",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}