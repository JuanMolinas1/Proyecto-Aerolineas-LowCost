package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class CheckInDAO {

    public void insertCheckIn(PreparedStatement sentencia_sql, CheckIn c) throws SQLException {
        sentencia_sql.setInt(1, c.getPasajero().getId_pasajero());
        sentencia_sql.setInt(2, c.getBoleto().getId_boleto());
        sentencia_sql.setInt(3, c.getVuelo().getId_vuelo());
        sentencia_sql.setInt(4, c.getPago().getId_pago());
        sentencia_sql.setString(5, c.getPuertaEmbarque());
    }

    public CheckIn selectCheckIn(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        VueloDAO vDAO = new VueloDAO();
        CheckIn c = new CheckIn();

        c.setId_checkin(resultado.getInt("IDCheckin"));
        c.setPuertaEmbarque(resultado.getString("puerta_embarque"));

        int idPasajero = resultado.getInt("pasajero_id");
        c.setPasajero(exDAO.buscarPasajeroPorId(idPasajero));

        int idBoleto = resultado.getInt("boleto_id");
        c.setBoleto(exDAO.buscarBoletoPorId(idBoleto));

        int idVuelo = resultado.getInt("vuelo_id");
        c.setVuelo(vDAO.buscarVuelo(idVuelo).get(0));

        int idPago = resultado.getInt("pago_id");
        c.setPago(exDAO.buscarPagoPorId(idPago));

        return c;
    }

    public void agregarCheckIn(CheckIn c) {
        String consulta_sql = "INSERT INTO CheckIn (pasajero_id, boleto_id, vuelo_id, pago_id, puerta_embarque) VALUES (?, ?, ?, ?, ?)";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertCheckIn(sentencia_sql, c);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "CheckIn Guardado Exitosamente",
                    "Creación de CheckIn",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Creación de CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public ArrayList<CheckIn> mostrarCheckIn() {
        ArrayList<CheckIn> l_checkins = new ArrayList<>();
        String consulta_sql = "SELECT * FROM CheckIn";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                l_checkins.add(selectCheckIn(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de CheckIns",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_checkins;
    }

    public ArrayList<CheckIn> buscarCheckIn(int id) {
        ArrayList<CheckIn> l_checkins = new ArrayList<>();
        String consulta_sql = "SELECT * FROM CheckIn WHERE IDCheckin = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            ResultSet resultado = sentencia_sql.executeQuery();

            if (resultado.next()){
                l_checkins.add(selectCheckIn(resultado));
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "No existe un CheckIn con el ID: " + id,
                    "Buscar CheckIn",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_checkins;
    }

    public void editarCheckIn(CheckIn c) {
        String consulta_sql = "UPDATE CheckIn SET pasajero_id = ?, boleto_id = ?, vuelo_id = ?, pago_id = ?, puerta_embarque = ? WHERE IDCheckin = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            insertCheckIn(sentencia_sql, c);
            sentencia_sql.setInt(6, c.getId_checkin());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "CheckIn Actualizado Exitosamente",
                    "Edición de CheckIn",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void eliminarCheckIn(int id) {
        String consulta_sql = "DELETE FROM CheckIn WHERE IDCheckin = ?";
        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "CheckIn Eliminado Exitosamente",
                    "Eliminar CheckIn",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Eliminar CheckIn",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}