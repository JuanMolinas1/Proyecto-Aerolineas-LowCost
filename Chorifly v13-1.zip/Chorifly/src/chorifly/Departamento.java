package chorifly;

import javax.swing.JOptionPane;

public class Departamento {
    private int id_departamento;
    private String nombre;
    private String tipo;

    public Departamento() {
    }

    public int getId_departamento() {
        return id_departamento;
    }

    public void setId_departamento(int id_departamento) {
        this.id_departamento = id_departamento;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public void mostrarDepartamento() {
        JOptionPane.showMessageDialog(null, "-- Mostrar : Departamento --"
                + "\nID Departamento: " + id_departamento
                + "\nNombre: " + nombre
                + "\nTipo: " + tipo,
                "Información del Departamento",
                JOptionPane.INFORMATION_MESSAGE);
    }
}