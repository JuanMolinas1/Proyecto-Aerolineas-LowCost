package chorifly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AsientoDAO {

    public Asiento selectAsiento(ResultSet resultado) throws SQLException {
        ExtrasDAO exDAO = new ExtrasDAO();
        Asiento a = new Asiento();

        a.setId_asiento(resultado.getString("IDAsiento"));
        a.setCodigo(resultado.getString("codigo"));
        a.setTipo(resultado.getString("tipo"));
        a.setDisponible(resultado.getBoolean("disponible"));

        String idAvion = resultado.getString("avion_id");
        a.setAvion(exDAO.buscarAvionPorId(idAvion));

        return a;
    }

    public ArrayList<Asiento> mostrarAsiento() {
        ArrayList<Asiento> l_asientos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Asiento";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                l_asientos.add(selectAsiento(resultado));
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Listado de Asientos",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_asientos;
    }

    public ArrayList<Asiento> buscarAsiento(boolean disponible) {
        ArrayList<Asiento> l_asientos = new ArrayList<>();
        String consulta_sql = "SELECT * FROM Asiento WHERE disponible = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setBoolean(1, disponible);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()){
                l_asientos.add(selectAsiento(resultado));
            }

            if (l_asientos.isEmpty()) {
                JOptionPane.showMessageDialog(
                    null,
                    "No existen asientos con disponibilidad: " + disponible,
                    "Buscar Asientos",
                    JOptionPane.ERROR_MESSAGE);
            }

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Buscar Asientos",
                    JOptionPane.ERROR_MESSAGE);
        }
        return l_asientos;
    }

    public void editarAsiento(Asiento a) {
        String consulta_sql = "UPDATE Asiento SET disponible = ? WHERE IDAsiento = ?";

        try {
            Connection conexion = ConexionSQL.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setBoolean(1, a.isDisponible());
            sentencia_sql.setString(2, a.getId_asiento());

            sentencia_sql.executeUpdate();

            JOptionPane.showMessageDialog(null,
                    "Disponibilidad del Asiento Actualizada Exitosamente",
                    "Edición de Asiento",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex){
            JOptionPane.showMessageDialog(null,
                    "Error " + ex.getMessage(),
                    "Edición de Asiento",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}