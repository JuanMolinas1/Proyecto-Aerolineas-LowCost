package chorifly;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.DateTimeException;
import java.text.SimpleDateFormat;

public class VentanaCrudEmpleados extends javax.swing.JFrame {
    private ExtrasDAO edao = new ExtrasDAO();
    private Utilidades uti = new Utilidades();
    private Validaciones valid = new Validaciones();
    
    SimpleDateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
    
    public VentanaCrudEmpleados(boolean vieneDeAdmin) {
        
        // No editables
        txtUsuario.setText("Seleccionar Usuario");
        txtDepartamento.setText("Seleccionar País de Origen");
        
        // Editables
        txtNombre.putClientProperty("JTextField.placeholderText", "Ingresar Nombre");
        txtApellido.putClientProperty("JTextField.placeholderText", "Ingresar Apellido");
        txtDni.putClientProperty("JTextField.placeholderText", "Ingresar DNI (Sin Puntos)");
        txtTelefono.putClientProperty("JTextField.placeholderText", "Ingresar Nro. de Teléfono");
        txtSueldo.putClientProperty("JTextField.placeholderText", "Ingresar Nro. de Pasaporte");
        
        txtBuscar.putClientProperty("JTextField.placeholderText", "ID Pasajero");
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaEmpleados = new javax.swing.JTable();
        txtApellido = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        txtSueldo = new javax.swing.JTextField();
        btnVolver = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        txtBuscar = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtDepartamento = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtAeropuerto = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chorifly - Menú Pasajeros");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(0, 94, 184));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CHORIFLY");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Vuelos");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Apellido");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("DNI");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Teléfono");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Sueldo");

        tablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Empleado", "Nombre", "Apellido", "Dni", "Teléfono", "Sueldo", "Departameto_id", "Aeropuerto_id", "Usuario"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaEmpleados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaEmpleadosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaEmpleados);
        if (tablaEmpleados.getColumnModel().getColumnCount() > 0) {
            tablaEmpleados.getColumnModel().getColumn(0).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(1).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(2).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(3).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(4).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(5).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(6).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(7).setResizable(false);
            tablaEmpleados.getColumnModel().getColumn(8).setResizable(false);
        }

        txtApellido.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        txtDni.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        txtSueldo.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        btnVolver.setBackground(new java.awt.Color(0, 184, 181));
        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        btnVolver.setForeground(new java.awt.Color(255, 255, 255));
        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnMostrar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnAgregar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEditar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N

        txtTelefono.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Departamento");

        txtDepartamento.setEditable(false);
        txtDepartamento.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtDepartamento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtDepartamentoMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Aeropuerto");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Usuario");

        txtUsuario.setEditable(false);
        txtUsuario.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtUsuarioMouseClicked(evt);
            }
        });

        txtNombre.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N

        txtAeropuerto.setEditable(false);
        txtAeropuerto.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtAeropuerto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtAeropuertoMouseClicked(evt);
            }
        });
        txtAeropuerto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAeropuertoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                            .addComponent(txtBuscar)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtSueldo)
                            .addComponent(txtApellido, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDni, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnAgregar, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE)
                                    .addComponent(btnEditar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnMostrar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(txtDepartamento, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefono)
                            .addComponent(txtUsuario, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtAeropuerto, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(txtNombre))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtApellido))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtDni))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtSueldo))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtDepartamento)
                            .addComponent(jLabel9))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(txtAeropuerto))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(txtUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1))
                .addGap(24, 24, 24)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        VentanaMenuPrincipalAdmin menuPrincipalAdmin = new VentanaMenuPrincipalAdmin();
        menuPrincipalAdmin.setVisible(true);
        menuPrincipalAdmin.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnVolverActionPerformed

    private void tablaEmpleadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaEmpleadosMouseClicked
        int fila = tablaEmpleados.getSelectedRow();

        String idPasajero = tablaEmpleados.getValueAt(fila, 0).toString();
        String nombre = tablaEmpleados.getValueAt(fila, 1).toString();
        String apellido = tablaEmpleados.getValueAt(fila, 2).toString();
        String dni = tablaEmpleados.getValueAt(fila, 3).toString();
        String telefono = tablaEmpleados.getValueAt(fila, 4).toString();
        String nroPasaporte = tablaEmpleados.getValueAt(fila, 6).toString();
        String paisEmision = tablaEmpleados.getValueAt(fila, 7).toString();
        String usuario = tablaEmpleados.getValueAt(fila, 9).toString();
            
        txtNombre.setText(nombre);
        txtApellido.setText(apellido);
        txtDni.setText(dni);
        txtTelefono.setText(telefono);
        txtSueldo.setText(nroPasaporte);
        txtDepartamento.setText(paisEmision);
        txtUsuario.setText(usuario);
    }//GEN-LAST:event_tablaEmpleadosMouseClicked

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        PasajeroDAO pdao = new PasajeroDAO();
        
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String dni = txtDni.getText();
        String telefono = txtTelefono.getText();
        String nroPasaporte = txtSueldo.getText().trim().toUpperCase();
        String paisEmision = txtDepartamento.getText();
        
        if (!valid.validarPasajero(nombre, apellido, dni, telefono, txtSueldo.getText().trim().toUpperCase(), paisEmision, txtUsuario.getText(), dateNacimiento.getDate(), dateVencimiento.getDate())) {
            return;
        }

        if (!valid.validarPasaporte(paisEmision, nroPasaporte)) {
            return;
        }

        Usuario usuario;

        try {
            usuario = edao.buscarUsuarioPorId(
                    Integer.parseInt(uti.borrarDesdeEspacio(txtUsuario.getText()))
            );

            if (usuario == null) {
                JOptionPane.showMessageDialog(
                        null,
                        "Debe seleccionar un usuario válido.",
                        "Gestión de Pasajeros",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    null,
                    "Debe seleccionar un usuario válido.",
                    "Gestión de Pasajeros",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        
       
            
            Pasajero p = new Pasajero(
                    nombre,
                    apellido,
                    dni,
                    telefono,
                    nroPasaporte,
                    paisEmision
            );
            
            p.setUsuario(usuario);
            
            pdao.agregarPasajero(p);
            actualizarTabla();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        actualizarTabla();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        int fila = tablaEmpleados.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un pasajero.",
                "Edición de Pasajero",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaEmpleados.getValueAt(fila, 0);

        PasajeroDAO pdao = new PasajeroDAO();

        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String dni = txtDni.getText();
        String telefono = txtTelefono.getText();
        String nroPasaporte = txtSueldo.getText().trim().toUpperCase();
        String paisEmision = txtDepartamento.getText();
        
        if (!valid.validarPasajero(nombre, apellido, dni, telefono, txtSueldo.getText().trim().toUpperCase(), paisEmision, txtUsuario.getText(), dateNacimiento.getDate(), dateVencimiento.getDate())) {
            return;
        }

        if (!valid.validarPasaporte(paisEmision, nroPasaporte)) {
            return;
        }
        
        Usuario usuario;
        
            usuario = edao.buscarUsuarioPorId(Integer.parseInt(uti.borrarDesdeEspacio(txtUsuario.getText())));
            
            if (usuario == null) {
                JOptionPane.showMessageDialog(
                        null,
                        "Debe seleccionar un usuario válido.",
                        "Gestión de Pasajeros",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }
       	

        

            
            Pasajero p = new Pasajero(
                    nombre,
                    apellido,
                    dni,
                    telefono,
                    nroPasaporte,
                    paisEmision
            );

            p.setIdPasajero(id);
            p.setUsuario(usuario);
            pdao.editarPasajero(p);
            actualizarTabla();
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = tablaEmpleados.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(
                null,
                "Debe seleccionar un pasajero.",
                "Eliminar Pasajero",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int id = (int) tablaEmpleados.getValueAt(fila, 0);
        PasajeroDAO pdao = new PasajeroDAO();
        pdao.eliminarPasajero(id);
        actualizarTabla();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
    PasajeroDAO pdao = new PasajeroDAO();
    if (txtBuscar.getText() != null && !txtBuscar.getText().trim().isEmpty()) {
        int id = Integer.parseInt(txtBuscar.getText().trim());

        ArrayList<Pasajero> pasajeros = pdao.buscarPasajero(id);
        DefaultTableModel modelo = (DefaultTableModel) tablaEmpleados.getModel();

        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        modelo.setRowCount(0);

        for (Pasajero p : pasajeros) {
            modelo.addRow(new Object[]{
                p.getIdPasajero(),
                p.getNombre(),
                p.getApellido(),
                p.getDni(),
                p.getTelefono(),
                p.getFechaNacimiento().format(formatoFecha),
                p.getNroPasaporte(),
                p.getPaisEmision(),
                p.getVencimientoPasaporte().format(formatoFecha),
                p.getUsuario().getIdUsuario()
            });
        }
    } else {
        JOptionPane.showMessageDialog(null, "El campo de ID Pasajero no debe estar vacío", "Buscar Pasajero", JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtUsuarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtUsuarioMouseClicked
        String[] listaUsuariosPasajero = edao.listarUsuariosSinPermisos().toArray(new String[0]);

        if (listaUsuariosPasajero.length == 0) {
            JOptionPane.showMessageDialog(
                null,
                "No hay usuarios disponibles.",
                "Menú Usuarios",
                JOptionPane.WARNING_MESSAGE
            );
            return;
}
        String seleccion = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona un Usuario:",
            "Menú Usuarios",
            JOptionPane.DEFAULT_OPTION,
            null,
            listaUsuariosPasajero,
            listaUsuariosPasajero[0]
        );

        if (seleccion != null) {
            txtUsuario.setText(seleccion);
        } else {
            JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Usuarios", JOptionPane.WARNING_MESSAGE);
            txtUsuario.setText("Seleccionar Usuario");
        }
    }//GEN-LAST:event_txtUsuarioMouseClicked

    private void txtDepartamentoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtDepartamentoMouseClicked
	String[] listaPaisEmision = edao.listarPaisEmision();

	String seleccion = (String) JOptionPane.showInputDialog(
		null,
		"Selecciona un País de Emisión:",
		"Menú Países de Emisión",
		JOptionPane.DEFAULT_OPTION,
		null,
		listaPaisEmision,
		listaPaisEmision[0]
	);

	if (seleccion != null) {
		txtDepartamento.setText(seleccion);
	} else {
		JOptionPane.showMessageDialog(null, "Cancelaste la Operación", "Menú Países de Emisión", JOptionPane.WARNING_MESSAGE);
		txtDepartamento.setText("Seleccionar País de Emisión");
	}
    }//GEN-LAST:event_txtDepartamentoMouseClicked

    private void txtAeropuertoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtAeropuertoMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAeropuertoMouseClicked

    private void txtAeropuertoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAeropuertoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAeropuertoActionPerformed

    public void actualizarTabla() {
        PasajeroDAO pdao = new PasajeroDAO();
        ArrayList<Pasajero> listaPasajeros = pdao.mostrarPasajero();
        DefaultTableModel modelo = (DefaultTableModel)tablaEmpleados.getModel();
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        
        modelo.setRowCount(0);
        
        for (Pasajero p : listaPasajeros) {
            modelo.addRow(new Object []{
                p.getIdPasajero(),
                p.getNombre(),
                p.getApellido(),
                p.getDni(),
                p.getTelefono(),
                p.getFechaNacimiento().format(formatoFecha),
                p.getNroPasaporte(),
                p.getPaisEmision(),
                p.getVencimientoPasaporte().format(formatoFecha),
                p.getUsuario().getIdUsuario()
            });
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaEmpleados;
    private javax.swing.JTextField txtAeropuerto;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDepartamento;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtSueldo;
    private javax.swing.JTextField txtTelefono;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
